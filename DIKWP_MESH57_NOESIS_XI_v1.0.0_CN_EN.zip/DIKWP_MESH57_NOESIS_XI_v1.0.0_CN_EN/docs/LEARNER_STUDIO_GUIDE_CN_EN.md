# NOESIS Ξ 离线学习者工作台 / Offline Learner Studio

`studio/index.html` 是无服务器、无外部依赖的本地会话记录器。它支持：

- 学习者化名、复数目的、负担上限与否决权；
- BASELINE、TRAINING、TRANSFER、EXTERIOR、COLLECTIVE、DELAYED 六阶段记录；
- 作答前置信区间、预先预测、未知项与外部性约束；
- `REFUSAL` 载体的内容保护；
- 被推翻主张、阻碍和开放问题；
- 本地 JSON 预览与导出。

它**不包含答案键、不自动评分、不向网络发送数据、不产生人格诊断、不生成总体理解力分数**。刷新页面会清空未导出的内存数据。真实实验必须由独立保管者持有隐藏迁移和延迟表单，并执行适用的伦理、隐私和知情同意程序。

`pilot/session_template57.json` 是与工作台输出相对应的研究模板；`noesis57 pilot-validate` 可以检查其最小结构，但不能判定理解。

---

The offline studio records a six-phase, learner-controlled evidence session and exports local JSON. It contains no scoring key, performs no automatic assessment, sends no network traffic, and must not be used for global ranking or diagnosis. A real study requires independently held hidden forms and applicable ethics, privacy, and consent procedures.
