# 研究基础 / Research Basis

NOESIS 的设计结合了下列研究方向，但不把这些文献当成本软件有效性的证明。

1. **DIKWP 理解理论**：目的驱动、语义关联、概率确认、知识推理、动态认知结构、误解识别与个性化补充。
2. **理解是过程**：理解随经验变化，需要一组成功与失败探针，而非单次通过测试。
3. **元认知**：监控、控制、信心判断和误差调节；现有训练研究的迁移与生态有效性仍有不确定性。
4. **主动错误**：让学习者生成并纠正自己的错误，可能促进远迁移，但主观上常低估这种方法。
5. **共同理解和集体智能**：团队难以整合分布式和模糊信息；理解可能存在于交互结构而非个人内部。
6. **检索、迁移和延迟**：即时熟练不能替代隐藏表层迁移与真实延迟复测。

## 主要参考

- Duan, Y., & Gong, S. (2024). *The Understanding Theory of Yucong Duan*. DOI: 10.13140/RG.2.2.35729.85601.
- Blaha, L. M., et al. (2022). *Understanding Is a Process*. Frontiers in Systems Neuroscience, 16, 800280. DOI: 10.3389/fnsys.2022.800280.
- Fleur, D. S., Bredeweg, B., & van den Bos, W. (2021). *Metacognition: ideas and insights from neuro- and educational sciences*. npj Science of Learning, 6, 13. DOI: 10.1038/s41539-021-00089-5.
- Wong, S. S. H., et al. (2023). *Deliberate Erring Improves Far Transfer of Learning More Than Errorless Elaboration and Spotting and Correcting Others’ Errors*. Journal of Applied Research in Memory and Cognition / open PMC record.
- Westby, S., & Riedl, C. (2023). *Collective Intelligence in Human-AI Teams: A Bayesian Theory of Mind Approach*. AAAI 2023; arXiv:2208.11660.

## 解释原则

这些研究支持选择探针、校准、主动错误、迁移和团队任务作为设计先验。真实效果仍必须由 NOESIS 自身的预注册人类研究产生，不能从文献类比直接继承。
