# 误解拓扑 / Misunderstanding Topology

## 1. 误解不是一条距离

传统系统常把接收者表达与目标表达的差异压缩成相似度。NOESIS 认为误解至少可能位于十个不同位置：

1. `purpose_gaps`：学习者、发送者和受影响方优化的不是同一对象；
2. `semantic_address_gaps`：相同符号被放入不同命名空间；
3. `process_gaps`：事件、参与者或因果边缺失；
4. `effect_kernel_gaps`：方向正确但大小、分布或不确定性错误；
5. `boundary_gaps`：把多孔、涌现或未决边界封死；
6. `temporal_gaps`：把循环、并发或分支过程线性化；
7. `grammar_gaps`：现有规则根本不能表达新对象；
8. `calibration_gaps`：信心与证据覆盖不相称；
9. `opacity_violations`：把拒绝、不透明或不可访问内容强制解释；
10. `gluing_status`：把不能拼合的局部世界强制统一。

## 2. 合法多元性

差异并不总是误解。制度运营者、受影响者、未来维护者和环境过程可能具有不可约的成功定义。`legitimate_plurality_handles` 明确保存这类差异，防止系统把“不同意”自动标成“没听懂”。

## 3. 修复模式

| 缺口 | 默认修复 |
|---|---|
| purpose | PURPOSE-RECONTRACT |
| semantic address | CROSS-CARRIER-REMAP |
| process/effect | PROCESS-COUNTERWORLD |
| boundary/time | BOUNDARY-TIME-ROTATION |
| grammar | REVERSIBLE-METAGRAMMAR-MUTATION |
| calibration | PREDICT-BEFORE-FEEDBACK-AND-REVISE |
| opacity | STOP-ASSIMILATION-RESTORE-EXTERIORITY |
| gluing | GLUING-REVIEW or preserve obstruction |

修复只是建议的可逆操作，不是系统对学习者的强制命令。

## 4. 为什么不能总和

目的缺口和不透明侵犯不能用预测正确率抵消；侵犯拒绝的系统即使预测精确，也不能获得“总体理解高”的结论。NOESIS 因此禁止加权总分和补偿性排名。
