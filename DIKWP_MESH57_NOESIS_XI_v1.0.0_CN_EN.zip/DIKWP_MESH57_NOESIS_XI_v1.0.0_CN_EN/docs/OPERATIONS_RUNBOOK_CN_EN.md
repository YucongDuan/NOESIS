# 运维与恢复手册 / Operations Runbook

## 安装

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install dist/dikwp_mesh57-5.7.0-py3-none-any.whl
python -m pip install dist/dikwp_mesh57_noesis-1.0.0-py3-none-any.whl
```

## 自检

```bash
noesis57 --version
noesis57 conformance --out outputs/conformance57.json
```

任何失败都应阻止发布，不得只检查最后一行状态而忽略失败项目。

## 运行参考事件

```bash
noesis57 demo --out outputs/reference-local
noesis57 artifacts-validate --root outputs/reference-local
```

## 数据库复核

输出目录中的 `noesis57.sqlite` 可由 `EpistemicEpisodeStore57.verify()` 检查。若 `valid=false`：

1. 停止追加新事件；
2. 保存数据库只读副本；
3. 比对 `episode_bundle57.json`、receipt 和 Manifest；
4. 定位对象体、bundle、event 或 receipt 哪一层失效；
5. 从最后一个已验证备份恢复；
6. 不允许直接修改哈希以“修复”链。

## 幂等与重试

相同 idempotency key 和相同 bundle 返回原回执；相同 key 与不同 bundle 被拒绝。客户端超时后应安全重试原 bundle，不得生成不同内容复用旧 key。

## 崩溃恢复

参考 store 使用事务。故障注入 `crash_after_event=True` 会回滚 objects、bundle、event 和 receipt。生产迁移必须重新验证目标数据库的事务语义。

## 密钥与身份

本版本没有生产身份或外部签名基础设施。解释复核者 ID 是可审计声明，不是密码学证明。真实部署应增加组织身份、密钥轮换、撤销和独立关系披露。

## 备份

使用 SQLite 在线备份 API 或在停止写入后复制数据库与对应 JSON 制品。只备份数据库而不备份协议、Schema 和源代码版本不足以复现证据。
