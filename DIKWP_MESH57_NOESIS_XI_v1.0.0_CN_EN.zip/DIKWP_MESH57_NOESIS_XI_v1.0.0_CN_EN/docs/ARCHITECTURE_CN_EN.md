# NOESIS Ξ 系统架构 / System Architecture

## 1. 七层运行栈

### L0 — Encounter / 遭遇载体层

使用 MESH 5.7 `ExpressionCarrier57` 接收文字、沉默、动作、音频、图像、传感、身体事件、拒绝、不可访问和不透明引用。载体保留来源、同意范围、表示声明和转换链。

关键不变量：

- `REFUSAL` 不得被转换为解释性文字；
- `INACCESSIBLE` 不得宣称完整表示；
- 非文字载体不因评测便利而被强制文本化；
- 一个载体的内容完整性与其解释正确性是两件不同的事。

### L1 — Covenant / 学习者宪约层

`UnderstandingCovenant57` 固定学习目的、允许探针、载体范围、禁止推断、受保护外部、数据范围、负担预算、有效期和学习者否决权。

没有学习者否决权的宪约不能创建。退出不被解释为低能力。

### L2 — Local Process Worlds / 局部过程世界层

回答不被压缩为一句结论，而是连接到 MESH 5.7 的：

- participation sites；
- events and process patterns；
- temporal and boundary topologies；
- semantic addresses；
- n-ary hyperrelations；
- calibrated effect kernels；
- local sections。

观察者可以存在，也可以不存在；过程先于稳定实体。

### L3 — Probes and Evidence / 探针与证据层

`UnderstandingProbe57` 预注册阶段、探针类型、结构家族、表层家族、目标能力、预期契约、证伪条件和负担。

`UnderstandingResponse57` 保存原始载体引用、局部世界、主张、预测、置信、未知和修订父节点。

开放表达必须经过 `InterpretationAttestation57`。系统默认不把语言模型的自动抽取当作真值；AI 辅助抽取必须有人类签署并披露分歧和限制。

### L4 — Misunderstanding Topology / 误解拓扑层

评估器输出十类局部缺口、合法多元性和修复模式。它不生成全局理解分数。

`UnderstandingEvidence57` 保存每项能力的局部分数与证据状态，但分数只用于能力内部的透明检查覆盖，不用于跨人排名。

### L5 — Gluing, Obstruction and Exteriority / 拼合、阻碍与外部性层

多个局部节通过 MESH 5.7 gluing engines 进行拼合：

- 可兼容时产生非唯一的局部全局候选；
- 不兼容时产生 `ObstructionCertificate57`；
- 阻碍不是外部真理声明，只说明当前覆盖与规则下没有全局节；
- `OpacityCovenant57` 和 `ExteriorityEnvelope57` 允许不公开内容的对象直接约束行动。

### L6 — Frontier, Intervention and Action / 前沿、干预与行动层

`UnderstandingFrontier57` 是动态证据边界，不是人格档案。它保存能力状态、证据链、活跃阻碍、受保护外部、开放问题和已失效主张。

调度器编译最小、可逆、非劝服型干预租约。最终只生成 `ActionWarrant57`：范围有限、时间有限、有回滚、有重新开放触发器，不允许不可逆行动。

### L7 — Atomic Evidence Store / 原子证据层

所有 NOESIS 与 MESH 5.7 对象进入同一个 `EpistemicEpisodeBundle57`：

```text
COMMIT(
  carriers + covenant + probes + responses + attestations
  + misunderstanding topologies + evidence + frontiers
  + local worlds + obstruction + exteriority + judgment
  + action warrant + open exterior surface
) OR COMMIT NOTHING
```

SQLite WAL 提供单机参考原子性、幂等键、哈希链事件、完整对象体校验和崩溃回滚。它不构成分布式共识或拜占庭容错。

## 2. 六阶段状态机

```text
BASELINE
  识别流畅伪理解、目的封闭、过度信心和语义同化

TRAINING
  预测在反馈前作出；主动生成错误模型；观察差异；保留修订轨迹

TRANSFER
  在词汇和表层领域变化后检验结构不变量

EXTERIOR
  检验拒绝、不透明和不可访问是否被正确保留

COLLECTIVE
  构造多个局部节；运行拼合；进行不可约删除测试

DELAYED
  在真实延迟后复测；新失败可把既有支持降为保留矛盾
```

阶段不是线性毕业制度。任何阶段都可以因新证据重新打开先前世界。

## 3. 对象关系

```text
Covenant
  └─ authorizes Probe
       ├─ references Encounter Carriers
       └─ receives Response
            ├─ interpreted by Attestation
            ├─ linked to Local Sections / Worlds
            └─ assessed into MisunderstandingTopology + Evidence

Evidence timeline
  └─ evolves UnderstandingFrontier
       └─ compiles reversible InterventionPlan + Leases

Local Sections
  └─ federated gluing
       ├─ GlobalSection candidate
       └─ ObstructionCertificate

Obstruction + Exteriority + irreducible components
  └─ TransindividualJudgment
       └─ ActionWarrant
            └─ OpenExteriorSurface
```

## 4. 安全设计

- 内容地址防止对象被静默重写；
- 幂等键防止同一事件重复提交；
- 同键异体被拒绝；
- 崩溃注入证明事务不会部分提交；
- 对象体篡改会使 store verification 失败；
- 规则变异必须保留父语法、外部句柄和可逆性；
- 任何全局理解、总分排名、完成或不可逆行动请求在构建器层被拒绝。

## 5. English summary

NOESIS is a seven-layer runtime that couples learner-governed covenants, carrier-neutral encounters, local process worlds, falsifiable probes, misunderstanding topology, gluing/obstruction, exteriority constraints, transindividual judgment, reversible action warrants, and an atomic evidence store. It is designed to make the failure, boundary and non-assimilable exterior of an understanding claim as auditable as its success.
