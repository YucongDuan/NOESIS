# Python 与 CLI 参考 / API Reference

## Python

```python
from dikwp_mesh57_noesis.demo import build_reference_noesis_episode57
from dikwp_mesh57_noesis.conformance import run_conformance_noesis57
from dikwp_mesh57_noesis.artifacts import validate_output_dir57

run = build_reference_noesis_episode57()
report = run_conformance_noesis57()
```

### 主要构建器

- `build_understanding_covenant57`
- `build_understanding_probe57`
- `build_interpretation_attestation57`
- `build_understanding_response57`
- `build_deliberate_error_episode57`
- `build_misunderstanding_topology57`
- `build_understanding_evidence57`
- `build_understanding_frontier57`
- `build_intervention_lease57`
- `build_intervention_plan57`

### 评估

```python
from dikwp_mesh57_noesis.assessment import assess_understanding57

result = assess_understanding57(
    probe,
    response,
    covenant,
    attestation=attestation,
    deliberate_error=deliberate_error,
)

result.topology
result.evidence
result.diagnostics
```

### 前沿演化

```python
from dikwp_mesh57_noesis.frontier import advance_frontier57

frontier = advance_frontier57(
    learner_id,
    domain_id,
    [evidence],
    previous=prior_frontier,
    active_obstruction_ids=[...],
    protected_exterior_handles=[...],
    open_questions=[...],
)
```

### 干预编译

```python
from dikwp_mesh57_noesis.scheduler import compile_intervention_plan57

plan, leases = compile_intervention_plan57(
    frontier,
    covenant,
    candidate_probe_ids=[...],
    issued_at=..., valid_until=...,
)
```

## CLI

```text
noesis57 --version
noesis57 definition
noesis57 conformance [--out FILE]
noesis57 demo --out DIRECTORY
noesis57 artifacts-validate --root DIRECTORY
noesis57 dashboard --root DIRECTORY [--out FILE]
```

CLI 返回 0 表示成功，2 表示验证失败或输入错误。错误以 JSON 写入 stderr。
