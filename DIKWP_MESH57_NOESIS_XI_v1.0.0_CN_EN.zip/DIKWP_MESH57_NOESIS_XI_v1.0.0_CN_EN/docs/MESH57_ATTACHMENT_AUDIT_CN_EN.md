# MESH 5.7 附件审计 / Attachment Audit

## 被审计制品

- 文件：`DIKWP_MESH_5_7(3).zip`
- SHA-256：`2ccfab0ebcfa0a11074397b8fc5b9b735b35a6c26bf67e1e67d8076a590ffe71`
- 上游版本：`dikwp-mesh57 5.7.0`
- 本次重新执行：上游 pytest **73/73 PASS**；上游 conformance **60/60 PASS**。

## NOESIS 继承的关键能力

附件把 MESH 从以语义对象为默认中心，推进到外部性保持的过程—超世界运行时。NOESIS 直接继承并用于理解系统的对象包括：

- 载体中立的 TEXT、SILENCE、GESTURE、SENSOR、REFUSAL、INACCESSIBLE 与 OPAQUE_REFERENCE；
- 观察者可选、过程优先和局部时间；
- 内、外、二者、皆非、多孔、未决、涌现等边界状态；
- n 元超关系、局部 section、拼合候选与 obstruction；
- protected opacity 与 open exterior surface；
- reversible metagrammar mutation；
- 无单一所有者的 transindividual judgment；
- 有限、可逆、可复核的 action warrant；
- SQLite 原子 episode bundle、事件和幂等回执。

## 上游仍未直接解决的任务

MESH 5.7 提供了表达和运行基础，但没有自动给出“人类理解提升”的操作定义、证据状态机、探针设计、误解拓扑、适应性干预、人类试验预注册或学习者工作台。NOESIS 因而不是简单封装，而是增加了理解领域的专用宪约层。

## 集成边界

NOESIS 依赖上游 `dikwp-mesh57==5.7.0`。发行包在 `dist/` 中附带原始上游 wheel 以便复现安装；上游代码与 NOESIS 代码仍保持独立包边界。任何未来上游版本迁移都必须重新执行本审计、全部 conformance 和决定性实验。
