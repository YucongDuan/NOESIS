#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE_NAMES = {"MANIFEST.json", "SHA256SUMS.txt"}
EXCLUDE_PARTS = {"__pycache__", ".pytest_cache", ".git"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def included_files() -> list[Path]:
    paths = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if path.name in EXCLUDE_NAMES or any(part in EXCLUDE_PARTS for part in rel.parts) or path.suffix == ".pyc":
            continue
        paths.append(path)
    return sorted(paths, key=lambda p: p.relative_to(ROOT).as_posix())


def build() -> dict:
    records = [
        {
            "path": path.relative_to(ROOT).as_posix(),
            "sha256": sha256_file(path),
            "size": path.stat().st_size,
        }
        for path in included_files()
    ]
    tree_material = "".join(f"{r['sha256']}  {r['size']}  {r['path']}\n" for r in records).encode("utf-8")
    manifest = {
        "manifest_version": "1.0",
        "system": "DIKWP-MESH 5.7 NOESIS Ξ",
        "version": "1.0.0",
        "root_name": ROOT.name,
        "hash_algorithm": "SHA-256",
        "file_count": len(records),
        "total_size": sum(r["size"] for r in records),
        "tree_hash": sha256_bytes(tree_material),
        "excluded_from_manifest": ["MANIFEST.json", "SHA256SUMS.txt"],
        "files": records,
    }
    (ROOT / "MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    sum_paths = included_files() + [ROOT / "MANIFEST.json"]
    lines = [f"{sha256_file(path)}  {path.relative_to(ROOT).as_posix()}" for path in sorted(sum_paths, key=lambda p: p.relative_to(ROOT).as_posix())]
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return manifest


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, indent=2, sort_keys=True))
