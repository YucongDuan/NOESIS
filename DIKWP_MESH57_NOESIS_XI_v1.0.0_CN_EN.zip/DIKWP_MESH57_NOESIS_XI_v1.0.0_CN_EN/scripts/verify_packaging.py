#!/usr/bin/env python3
from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WHEEL = ROOT / "dist" / "dikwp_mesh57_noesis-1.0.0-py3-none-any.whl"
SDIST = ROOT / "dist" / "dikwp_mesh57_noesis-1.0.0.tar.gz"
UPSTREAM_SRC = Path("/mnt/data/mesh57_audit/source/DIKWP_MESH_5_7_EXTERIORITY_PRESERVING_PROCESS_HYPERWORLD_RUNTIME_v1.0.0_CN_EN/src")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def record_digest(data: bytes) -> str:
    return "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode("ascii")


def main() -> int:
    checks: list[dict[str, object]] = []

    def add(name: str, passed: bool, detail=None) -> None:
        checks.append({"name": name, "passed": bool(passed), "detail": detail})

    add("wheel exists", WHEEL.is_file(), str(WHEEL))
    add("sdist exists", SDIST.is_file(), str(SDIST))

    with zipfile.ZipFile(WHEEL) as zf:
        names = zf.namelist()
        add("wheel zip test", zf.testzip() is None)
        add("wheel has one dist-info", len({name.split('/')[0] for name in names if '.dist-info/' in name}) == 1)
        add("wheel has console entry point", any(name.endswith(".dist-info/entry_points.txt") for name in names))
        add("wheel embeds 19 schemas", len([n for n in names if n.startswith("dikwp_mesh57_noesis/resources/schemas/") and n.endswith(".json")]) == 19)
        record_name = next(name for name in names if name.endswith(".dist-info/RECORD"))
        rows = list(csv.reader(io.StringIO(zf.read(record_name).decode("utf-8"))))
        row_map = {row[0]: row[1:] for row in rows}
        record_errors = []
        for name in names:
            if name == record_name:
                continue
            data = zf.read(name)
            expected = row_map.get(name)
            if expected is None or expected[0] != record_digest(data) or expected[1] != str(len(data)):
                record_errors.append(name)
        add("wheel RECORD covers every member", not record_errors and set(row_map) == set(names), record_errors[:10])
        metadata_name = next(name for name in names if name.endswith(".dist-info/METADATA"))
        metadata = zf.read(metadata_name).decode("utf-8")
        add("wheel pins MESH57 dependency", "Requires-Dist: dikwp-mesh57==5.7.0" in metadata)
        add("wheel has no mandatory jsonschema dependency", "Requires-Dist: jsonschema" not in metadata)
        add("wheel contains no cache files", not any("__pycache__" in n or n.endswith(".pyc") for n in names))
        add("wheel path-safe", all(not n.startswith("/") and ".." not in Path(n).parts for n in names))
        wheel_member_count = len(names)

    with tarfile.open(SDIST, "r:gz") as tf:
        members = tf.getmembers()
        roots = {Path(member.name).parts[0] for member in members if Path(member.name).parts}
        add("sdist has one root", len(roots) == 1, sorted(roots))
        add("sdist contains pyproject", any(member.name.endswith("/pyproject.toml") for member in members))
        add("sdist contains source", any("/src/dikwp_mesh57_noesis/cli.py" in member.name for member in members))
        add("sdist contains pilot and studio", any("/pilot/preregistration57.json" in member.name for member in members) and any("/studio/index.html" in member.name for member in members))
        add("sdist contains no cache files", not any("__pycache__" in member.name or member.name.endswith(".pyc") or ".pytest_cache" in member.name for member in members))
        add("sdist path-safe", all(not member.name.startswith("/") and ".." not in Path(member.name).parts for member in members))
        sdist_member_count = len(members)
        with tempfile.TemporaryDirectory(prefix="noesis57-sdist-") as tmp:
            tf.extractall(tmp, filter="data")
            root = Path(tmp) / next(iter(roots))
            env = os.environ.copy()
            env["PYTHONPATH"] = os.pathsep.join([str(root / "src"), str(UPSTREAM_SRC)])
            definition = subprocess.run(
                [sys.executable, "-m", "dikwp_mesh57_noesis", "definition"],
                cwd=tmp,
                env=env,
                capture_output=True,
                text=True,
                timeout=60,
            )
            add("sdist source CLI runs", definition.returncode == 0 and "definition_cn" in definition.stdout, definition.stderr[-500:])
            conformance = subprocess.run(
                [sys.executable, "-m", "dikwp_mesh57_noesis", "conformance"],
                cwd=tmp,
                env=env,
                capture_output=True,
                text=True,
                timeout=180,
            )
            try:
                cdata = json.loads(conformance.stdout)
            except json.JSONDecodeError:
                cdata = {}
            add("sdist source conformance 81/81", conformance.returncode == 0 and cdata.get("passed") == 81 and cdata.get("failed") == 0, conformance.stderr[-500:])

    passed = sum(int(item["passed"]) for item in checks)
    report = {
        "system": "DIKWP-MESH 5.7 NOESIS Ξ",
        "version": "1.0.0",
        "status": "PASS" if passed == len(checks) else "FAIL",
        "passed": passed,
        "failed": len(checks) - passed,
        "wheel_sha256": sha256(WHEEL),
        "sdist_sha256": sha256(SDIST),
        "wheel_member_count": wheel_member_count,
        "sdist_member_count": sdist_member_count,
        "checks": checks,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
