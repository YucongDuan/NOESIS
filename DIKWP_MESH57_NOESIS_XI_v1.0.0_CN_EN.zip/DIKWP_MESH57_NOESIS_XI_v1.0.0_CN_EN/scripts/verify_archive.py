#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_archive(path: Path) -> dict:
    checks = []

    def add(name: str, passed: bool, detail=None) -> None:
        checks.append({"name": name, "passed": bool(passed), "detail": detail})

    add("archive exists", path.is_file(), str(path))
    if not path.is_file():
        return {"status": "FAIL", "checks": checks}
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        add("ZIP CRC", zf.testzip() is None)
        roots = {Path(name).parts[0] for name in names if Path(name).parts}
        add("single root", len(roots) == 1, sorted(roots))
        add("path safe", all(not name.startswith("/") and ".." not in Path(name).parts for name in names))
        add("no cache members", not any("__pycache__" in name or ".pytest_cache" in name or name.endswith(".pyc") for name in names))
        with tempfile.TemporaryDirectory(prefix="noesis57-archive-") as tmp:
            zf.extractall(tmp)
            if len(roots) == 1:
                root = Path(tmp) / next(iter(roots))
                proc = subprocess.run([sys.executable, str(root / "scripts/verify_release.py"), str(root)], capture_output=True, text=True, timeout=180)
                try:
                    release = json.loads(proc.stdout)
                except json.JSONDecodeError:
                    release = {"status": "FAIL", "stdout": proc.stdout[-1000:], "stderr": proc.stderr[-1000:]}
                add("extracted release verifies", proc.returncode == 0 and release.get("status") == "PASS", release)
                add("extracted CLI source starts", (root / "src/dikwp_mesh57_noesis/cli.py").is_file())
    passed = sum(int(item["passed"]) for item in checks)
    return {
        "archive": str(path),
        "sha256": sha256(path),
        "size": path.stat().st_size,
        "status": "PASS" if passed == len(checks) else "FAIL",
        "passed": passed,
        "failed": len(checks) - passed,
        "checks": checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive")
    args = parser.parse_args()
    report = verify_archive(Path(args.archive).resolve())
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
