#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

EXCLUDE_PARTS = {"__pycache__", ".pytest_cache", ".git"}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify(root: Path) -> dict:
    checks = []

    def add(name: str, passed: bool, detail=None) -> None:
        checks.append({"name": name, "passed": bool(passed), "detail": detail})

    manifest_path = root / "MANIFEST.json"
    sums_path = root / "SHA256SUMS.txt"
    add("manifest exists", manifest_path.is_file())
    add("sha256 sums exists", sums_path.is_file())
    if not manifest_path.is_file() or not sums_path.is_file():
        return {"status": "FAIL", "passed": sum(int(x["passed"]) for x in checks), "failed": sum(int(not x["passed"]) for x in checks), "checks": checks}

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    records = manifest.get("files", [])
    listed = {record["path"] for record in records}
    errors = []
    for record in records:
        path = root / record["path"]
        if not path.is_file():
            errors.append({"path": record["path"], "error": "missing"})
            continue
        actual = sha256_file(path)
        if actual != record["sha256"] or path.stat().st_size != record["size"]:
            errors.append({"path": record["path"], "error": "hash-or-size-mismatch", "actual": actual})
    add("all manifest records verify", not errors, errors[:10])
    add("manifest file count", manifest.get("file_count") == len(records), {"declared": manifest.get("file_count"), "actual": len(records)})
    material = "".join(f"{r['sha256']}  {r['size']}  {r['path']}\n" for r in records).encode("utf-8")
    add("manifest tree hash", hashlib.sha256(material).hexdigest() == manifest.get("tree_hash"))

    actual_files = set()
    cache_files = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part in EXCLUDE_PARTS for part in rel.parts) or path.suffix == ".pyc":
            cache_files.append(rel.as_posix())
            continue
        actual_files.add(rel.as_posix())
    allowed_extra = {"MANIFEST.json", "SHA256SUMS.txt"}
    add("no unlisted release files", actual_files == listed | allowed_extra, {"extra": sorted(actual_files - listed - allowed_extra)[:20], "missing": sorted(listed - actual_files)[:20]})
    add("no cache files", not cache_files, cache_files[:20])

    sum_errors = []
    sum_entries = {}
    for line in sums_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            digest, rel = line.split("  ", 1)
        except ValueError:
            sum_errors.append({"line": line, "error": "format"})
            continue
        sum_entries[rel] = digest
        path = root / rel
        if not path.is_file() or sha256_file(path) != digest:
            sum_errors.append({"path": rel, "error": "mismatch-or-missing"})
    add("SHA256SUMS verifies", not sum_errors, sum_errors[:10])
    add("SHA256SUMS covers manifest and listed files", set(sum_entries) == listed | {"MANIFEST.json"}, {"entry_count": len(sum_entries)})

    expected_pass_reports = [
        "VALIDATION_REPORT.json",
        "outputs/NOESIS57_CONFORMANCE_REPORT.json",
        "outputs/NOESIS57_ARTIFACT_VALIDATION.json",
        "outputs/NOESIS57_SCHEMA_BACKEND_VALIDATION.json",
        "outputs/NOESIS57_CLEAN_WHEEL_VALIDATION.json",
        "outputs/NOESIS57_PACKAGING_VALIDATION.json",
        "outputs/NOESIS57_DETERMINISTIC_BUILD_VALIDATION.json",
        "outputs/NOESIS57_BROWSER_VALIDATION.json",
        "outputs/NOESIS57_STUDIO_INTERACTION_VALIDATION.json",
    ]
    report_errors = []
    for rel in expected_pass_reports:
        path = root / rel
        if not path.is_file():
            report_errors.append({"path": rel, "error": "missing"})
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        status = data.get("overall_status", data.get("status"))
        if status != "PASS":
            report_errors.append({"path": rel, "status": status})
    add("load-bearing reports PASS", not report_errors, report_errors)
    add("dashboard exists", (root / "dashboard/index.html").is_file())
    add("learner studio exists", (root / "studio/index.html").is_file())
    add("both wheels exist", (root / "dist/dikwp_mesh57_noesis-1.0.0-py3-none-any.whl").is_file() and (root / "dist/dikwp_mesh57-5.7.0-py3-none-any.whl").is_file())
    add("nineteen schemas", len(list((root / "schemas").glob("*.json"))) == 19)
    add("human pilot kit", len(list((root / "pilot").glob("*.json"))) == 7 and (root / "pilot/README_CN_EN.md").is_file())

    passed = sum(int(item["passed"]) for item in checks)
    return {
        "system": "DIKWP-MESH 5.7 NOESIS Ξ",
        "version": "1.0.0",
        "status": "PASS" if passed == len(checks) else "FAIL",
        "passed": passed,
        "failed": len(checks) - passed,
        "manifest_file_count": manifest.get("file_count"),
        "manifest_tree_hash": manifest.get("tree_hash"),
        "checks": checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    report = verify(Path(args.root).resolve())
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
