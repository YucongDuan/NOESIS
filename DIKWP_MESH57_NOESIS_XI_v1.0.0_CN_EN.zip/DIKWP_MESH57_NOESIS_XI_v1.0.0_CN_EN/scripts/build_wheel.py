#!/usr/bin/env python3
from __future__ import annotations

import base64
import csv
import hashlib
import io
import os
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
NAME = "dikwp_mesh57_noesis"
VERSION = "1.0.0"
DIST_INFO = f"{NAME}-{VERSION}.dist-info"
FIXED_ZIP_TIME = (2026, 7, 25, 0, 0, 0)
FIXED_MTIME = 1784937600


def _digest(data: bytes) -> str:
    return "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode("ascii")


def _wheel_files() -> dict[str, bytes]:
    files: dict[str, bytes] = {}
    package_root = ROOT / "src" / NAME
    for path in sorted(package_root.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        arc = path.relative_to(ROOT / "src").as_posix()
        files[arc] = path.read_bytes()
    metadata = f"""Metadata-Version: 2.4
Name: dikwp-mesh57-noesis
Version: {VERSION}
Summary: Exteriority-preserving human understanding world-generation and transindividual uplift runtime
License-Expression: Apache-2.0
Requires-Python: >=3.10
Requires-Dist: dikwp-mesh57==5.7.0
Description-Content-Type: text/markdown

{(ROOT / 'README.md').read_text(encoding='utf-8')}
""".encode("utf-8")
    files[f"{DIST_INFO}/METADATA"] = metadata
    files[f"{DIST_INFO}/WHEEL"] = (
        "Wheel-Version: 1.0\nGenerator: noesis57 deterministic builder 1.0\nRoot-Is-Purelib: true\nTag: py3-none-any\n"
    ).encode("utf-8")
    files[f"{DIST_INFO}/entry_points.txt"] = b"[console_scripts]\nnoesis57 = dikwp_mesh57_noesis.cli:main\n"
    files[f"{DIST_INFO}/top_level.txt"] = b"dikwp_mesh57_noesis\n"
    license_text = (ROOT / "LICENSE").read_bytes()
    files[f"{DIST_INFO}/licenses/LICENSE"] = license_text
    return files


def build_wheel() -> Path:
    DIST.mkdir(parents=True, exist_ok=True)
    target = DIST / f"{NAME}-{VERSION}-py3-none-any.whl"
    files = _wheel_files()
    rows = []
    for arc, data in sorted(files.items()):
        rows.append([arc, _digest(data), str(len(data))])
    rows.append([f"{DIST_INFO}/RECORD", "", ""])
    buf = io.StringIO(newline="")
    csv.writer(buf, lineterminator="\n").writerows(rows)
    files[f"{DIST_INFO}/RECORD"] = buf.getvalue().encode("utf-8")
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc, data in sorted(files.items()):
            info = zipfile.ZipInfo(arc, date_time=FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return target


def _tar_filter(ti: tarfile.TarInfo) -> tarfile.TarInfo:
    ti.mtime = FIXED_MTIME
    ti.uid = ti.gid = 0
    ti.uname = ti.gname = "root"
    if ti.isdir():
        ti.mode = 0o755
    else:
        ti.mode = 0o644
    return ti


def build_sdist() -> Path:
    DIST.mkdir(parents=True, exist_ok=True)
    target = DIST / f"{NAME}-{VERSION}.tar.gz"
    prefix = Path(f"{NAME}-{VERSION}")
    include_roots = ["src", "tests", "schemas", "docs", "protocols", "pilot", "studio", "dashboard", "examples"]
    include_files = [
        "README.md", "LICENSE", "NOTICE", "pyproject.toml", "setup.py", "MANIFEST.in", "CITATION.cff", "CHANGELOG.md", "SECURITY.md", "CONTRIBUTING.md", "GOVERNANCE.md"
    ]
    with target.open("wb") as raw:
        import gzip
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=FIXED_MTIME, compresslevel=9) as gz:
            with tarfile.open(fileobj=gz, mode="w") as tf:
                for name in include_files:
                    path = ROOT / name
                    tf.add(path, arcname=(prefix / name).as_posix(), filter=_tar_filter)
                for root_name in include_roots:
                    root = ROOT / root_name
                    if not root.exists():
                        continue
                    for path in sorted(root.rglob("*")):
                        if "__pycache__" in path.parts or path.suffix in {".pyc"} or ".pytest_cache" in path.parts:
                            continue
                        tf.add(path, arcname=(prefix / path.relative_to(ROOT)).as_posix(), recursive=False, filter=_tar_filter)
    return target


if __name__ == "__main__":
    w = build_wheel()
    s = build_sdist()
    print(w)
    print(s)
