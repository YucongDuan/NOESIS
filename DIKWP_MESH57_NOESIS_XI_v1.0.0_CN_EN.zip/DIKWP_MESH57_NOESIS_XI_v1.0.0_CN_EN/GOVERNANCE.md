# Governance

This is an E2 author-side reference release. A future production or research-certified release requires separate roles for:

- runtime maintainer;
- human-study custodian holding hidden forms;
- blinded assessor lead;
- affected-party or learner-rights representative;
- security/privacy reviewer;
- independent reproducer.

No single role may both expose hidden forms and certify transfer outcomes. Policy amendments must be versioned, content-addressed and reported with their effective date. Adverse, null and contradictory evidence remains part of the public research record unless privacy law requires restricted access.
