# NOESIS 5.7 人类试验工具包 / Human Pilot Kit

本目录是预注册和数据结构模板，不是伦理审批、临床认证或现成的人类有效性证据。真实试验必须使用独立保管的隐藏迁移/延迟表单，并执行当地适用的知情同意、隐私与伦理程序。

This directory is a preregistration and data-structure scaffold, not ethics approval, certification, or evidence of human effectiveness. A real study requires independently held hidden transfer/delayed forms and applicable consent, privacy, and ethics procedures.
