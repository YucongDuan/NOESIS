# Security and Safety Policy

Report software vulnerabilities privately to the maintainer responsible for the deployment. Do not include personal learner data in public reports.

## Supported version

Only 1.0.x is supported by this reference release.

## Non-negotiable deployment constraints

- Do not expose the reference SQLite store directly to an untrusted network.
- Do not use synthetic demonstration keys, prompts or visible transfer forms as hidden human-study instruments.
- Do not infer motive, loyalty, identity, diagnosis or refused content.
- Do not collapse local evidence into an employment, admission, education-exclusion, legal, credit, clinical or insurance ranking.
- Execute learner veto and withdrawal procedures immediately.
- Encrypt identifiable human data at rest and in transit in any real deployment; this reference package does not provide that infrastructure.
- Require independent ethics, privacy, security and domain review before human deployment.

A conformance PASS proves only that the reference implementation satisfies its executable invariants in the tested environment.
