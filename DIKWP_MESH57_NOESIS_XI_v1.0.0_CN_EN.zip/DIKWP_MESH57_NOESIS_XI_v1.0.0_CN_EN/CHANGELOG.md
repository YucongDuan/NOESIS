# Changelog

## 1.0.0 — 2026-07-25

- Reframed understanding as an open, purpose-bound process-world generation capability rather than a scalar state.
- Added 12 non-totalizing capability coordinates and six evidence phases.
- Added misunderstanding topology, gluing/obstruction literacy, exteriority integrity, reversible metagrammar mutation, and transindividual deletion tests.
- Added MESH 5.7 atomic episode commits, idempotent receipts, crash rollback and tamper verification.
- Added a deterministic reference episode, offline dashboard, offline learner studio, human-pilot preregistration kit, 19 JSON Schemas, and executable conformance checks.

### Offline schema path

- Added a deterministic validator for the exact JSON Schema subset emitted by NOESIS, allowing clean offline operation without third-party packages.
- The release remains cross-checked with the optional `jsonschema` Draft 2020-12 implementation.
