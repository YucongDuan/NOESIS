from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest

from dikwp_mesh57.store import EpistemicEpisodeStore57
from dikwp_mesh57_noesis.artifacts import validate_output_dir57
from dikwp_mesh57_noesis.cli import main
from dikwp_mesh57_noesis.conformance import run_conformance_noesis57
from dikwp_mesh57_noesis.demo import write_reference_noesis_episode57
from dikwp_mesh57_noesis.reports import write_dashboard57


def test_reference_bundle_is_large_and_content_addressed(run57):
    assert len(run57["bundle"].object_records) >= 150
    assert run57["bundle"].bundle_id.startswith("EB57-")


def test_reference_warrant_is_reversible(run57):
    assert run57["warrant"].status == "SHADOW-REVERSIBLE-ONLY"
    assert not run57["warrant"].irreversible_action_allowed


def test_reference_surface_is_open(run57):
    surface = run57["surface"]
    assert not surface.global_closure_claimed
    assert not surface.completion_claimed
    assert surface.unregistered_exterior_remains_possible


def test_store_idempotency(run57, tmp_path):
    store = EpistemicEpisodeStore57(tmp_path / "x.sqlite")
    a = store.commit(run57["bundle"])
    b = store.commit(run57["bundle"])
    assert a == b
    assert store.verify()["event_count"] == 1


def test_store_crash_rollback(run57, tmp_path):
    store = EpistemicEpisodeStore57(tmp_path / "x.sqlite")
    with pytest.raises(RuntimeError):
        store.commit(run57["bundle"], crash_after_event=True)
    verification = store.verify()
    assert verification["object_count"] == 0
    assert verification["event_count"] == 0


def test_store_detects_tamper(run57, tmp_path):
    path = tmp_path / "x.sqlite"
    store = EpistemicEpisodeStore57(path)
    store.commit(run57["bundle"])
    with sqlite3.connect(path) as db:
        row = db.execute("select object_hash,body_json from objects limit 1").fetchone()
        body = json.loads(row[1]); body["tamper"] = True
        db.execute("update objects set body_json=? where object_hash=?", (json.dumps(body), row[0]))
        db.commit()
    assert not store.verify()["valid"]


def test_write_demo_and_validate(tmp_path):
    summary = write_reference_noesis_episode57(tmp_path)
    assert summary["store_verification"]["valid"]
    report = validate_output_dir57(tmp_path)
    assert report["status"] == "PASS"
    assert report["failed"] == 0


def test_dashboard_is_offline_single_file(tmp_path):
    write_reference_noesis_episode57(tmp_path)
    path = write_dashboard57(tmp_path)
    text = path.read_text(encoding="utf-8")
    assert "DIKWP-MESH 5.7 NOESIS" in text
    assert "<script src=" not in text
    assert "https://" not in text


def test_cli_version(capsys):
    assert main(["--version"]) == 0
    assert "1.0.0" in capsys.readouterr().out


def test_cli_definition(capsys):
    assert main(["definition"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert "局部过程世界" in payload["definition_cn"]


def test_cli_demo_and_validate(tmp_path, capsys):
    assert main(["demo", "--out", str(tmp_path)]) == 0
    capsys.readouterr()
    assert main(["artifacts-validate", "--root", str(tmp_path)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["status"] == "PASS"


def test_conformance_passes():
    report = run_conformance_noesis57()
    assert report["status"] == "PASS"
    assert report["failed"] == 0
    assert report["upstream_mesh57"]["failed"] == 0
