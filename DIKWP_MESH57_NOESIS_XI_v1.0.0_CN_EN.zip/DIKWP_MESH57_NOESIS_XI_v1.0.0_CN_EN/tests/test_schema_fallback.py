from __future__ import annotations

import json

from dikwp_mesh57_noesis.schema_export import build_all_schemas57
from dikwp_mesh57_noesis.schema_validate import validate_instance57, validate_schemas57


def test_fallback_validates_reference_outputs(reference_dir):
    report = validate_schemas57(reference_dir, force_fallback=True)
    assert report["status"] == "PASS"
    assert report["passed"] == 11
    assert report["backend"] == "noesis-deterministic-subset"


def test_fallback_rejects_global_understanding_claim(reference_dir):
    schemas = build_all_schemas57()
    payload = json.loads((reference_dir / "understanding_evidence57.json").read_text())
    payload[0]["global_understanding_claimed"] = True
    errors, backend = validate_instance57(payload, schemas["understanding_evidence57.collection.schema.json"], force_fallback=True)
    assert backend == "noesis-deterministic-subset"
    assert errors


def test_fallback_rejects_unknown_frontier_capability(reference_dir):
    schemas = build_all_schemas57()
    payload = json.loads((reference_dir / "understanding_frontiers57.json").read_text())
    payload[-1]["capability_states"]["invented_capability"] = "RETENTION-SUPPORTED"
    errors, _ = validate_instance57(payload, schemas["understanding_frontiers57.collection.schema.json"], force_fallback=True)
    assert any("unexpected property" in error or "enum" in error for error in errors)
