from __future__ import annotations

from dataclasses import replace

import pytest

from dikwp_mesh57_noesis.assessment import assess_understanding57


def test_baseline_detects_opacity_violation(run57):
    assert run57["topologies"][0].opacity_violations


def test_baseline_detects_forced_consensus(run57):
    assert run57["topologies"][0].gluing_status == "FORCED-CONSENSUS"
    assert not run57["evidences"][0].obstruction_preserved


def test_baseline_is_overconfident(run57):
    assert "calibration.interval" in run57["evidences"][0].failed_handles


def test_training_supports_deliberate_error(run57):
    assert run57["evidences"][1].capability_scores["counterworld_generation"] == 1.0
    assert run57["deliberate_errors"][0].correction_handles


def test_training_requires_revision_trace(run57):
    assert run57["responses"][1].revision_parent_id == run57["responses"][0].response_id
    assert "revision.trace" in run57["evidences"][1].passed_handles


def test_transfer_is_surface_shifted(run57):
    probe = run57["probes"][2]
    assert probe.surface_family != probe.expected_contract["source_surface_family"]
    assert run57["evidences"][2].transfer_valid


def test_transfer_tracks_cyclic_temporality(run57):
    assert "temporal.modes" in run57["evidences"][2].passed_handles


def test_refusal_has_causal_force_without_decoding(run57):
    evidence = run57["evidences"][3]
    assert evidence.exteriority_preserved
    assert "no-content-extracted-from-refusal" in evidence.held_handles


def test_collective_has_no_single_owner(run57):
    assert run57["responses"][4].assignment_claims["no_single_owner"] is True
    assert run57["evidences"][4].capability_scores["transindividual_participation"] == 1.0


def test_delayed_integrated_probe_has_no_failed_checks(run57):
    assert run57["diagnostics"][-1]["failed_check_count"] == 0


def test_delayed_purpose_is_held_contradiction(run57):
    assert run57["evidences"][-1].capability_states["purpose_recontracting"] == "HELD-CONTRADICTION"


def test_delayed_retention_is_local_not_global(run57):
    evidence = run57["evidences"][-1]
    assert evidence.retention_valid
    assert not evidence.global_understanding_claimed


def test_response_probe_mismatch_rejected(run57):
    response = replace(run57["responses"][0], probe_id="other")
    with pytest.raises(ValueError):
        assess_understanding57(run57["probes"][0], response, run57["covenant"], attestation=run57["attestations"][0])


def test_response_learner_mismatch_rejected(run57):
    response = replace(run57["responses"][0], learner_id="other")
    with pytest.raises(ValueError):
        assess_understanding57(run57["probes"][0], response, run57["covenant"], attestation=run57["attestations"][0])


def test_attestation_must_cover_response_carrier(run57):
    attestation = replace(run57["attestations"][0], response_carrier_ids=[])
    with pytest.raises(ValueError):
        assess_understanding57(run57["probes"][0], run57["responses"][0], run57["covenant"], attestation=attestation)


def test_response_outside_covenant_rejected(run57):
    response = replace(run57["responses"][0], submitted_at=run57["covenant"].valid_until + 1)
    with pytest.raises(ValueError):
        assess_understanding57(run57["probes"][0], response, run57["covenant"], attestation=run57["attestations"][0])
