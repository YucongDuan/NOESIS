from __future__ import annotations

import pytest

from dikwp_mesh57_noesis.builders import (
    build_interpretation_attestation57,
    build_intervention_lease57,
    build_intervention_plan57,
    build_misunderstanding_topology57,
    build_understanding_covenant57,
    build_understanding_evidence57,
    build_understanding_frontier57,
    build_understanding_probe57,
    build_understanding_response57,
)
from dikwp_mesh57_noesis.models import UNDERSTANDING_CAPABILITIES


def test_covenant_content_address_is_deterministic():
    a = build_understanding_covenant57("l", "d", purpose_handles=["p"], valid_from=1, valid_until=2)
    b = build_understanding_covenant57("l", "d", purpose_handles=["p"], valid_from=1, valid_until=2)
    assert a == b


def test_covenant_requires_veto():
    with pytest.raises(ValueError):
        build_understanding_covenant57("l", "d", purpose_handles=["p"], learner_veto=False, valid_from=1, valid_until=2)


def test_covenant_rejects_invalid_interval():
    with pytest.raises(ValueError):
        build_understanding_covenant57("l", "d", purpose_handles=["p"], valid_from=2, valid_until=2)


def test_covenant_rejects_negative_budget():
    with pytest.raises(ValueError):
        build_understanding_covenant57("l", "d", purpose_handles=["p"], burden_budget={"max_probe_count": -1}, valid_from=1, valid_until=2)


def test_probe_rejects_unknown_phase():
    with pytest.raises(ValueError):
        build_understanding_probe57("OTHER", "RECONSTRUCT", "c", carrier_ids=[], target_capabilities=[UNDERSTANDING_CAPABILITIES[0]], structure_family="s", surface_family="x", expected_contract={}, falsification_conditions=["f"])


def test_probe_rejects_unknown_kind():
    with pytest.raises(ValueError):
        build_understanding_probe57("BASELINE", "OTHER", "c", carrier_ids=[], target_capabilities=[UNDERSTANDING_CAPABILITIES[0]], structure_family="s", surface_family="x", expected_contract={}, falsification_conditions=["f"])


def test_probe_rejects_empty_targets():
    with pytest.raises(ValueError):
        build_understanding_probe57("BASELINE", "RECONSTRUCT", "c", carrier_ids=[], target_capabilities=[], structure_family="s", surface_family="x", expected_contract={}, falsification_conditions=["f"])


def test_response_rejects_bad_confidence():
    with pytest.raises(ValueError):
        build_understanding_response57("p", "l", response_carrier_ids=[], local_section_ids=[], world_ids=[], assignment_claims={}, prediction_claims={}, confidence_interval=[-0.1, 0.5], submitted_at=1)


def test_response_rejects_boolean_time():
    with pytest.raises(TypeError):
        build_understanding_response57("p", "l", response_carrier_ids=[], local_section_ids=[], world_ids=[], assignment_claims={}, prediction_claims={}, confidence_interval=[0.1, 0.5], submitted_at=True)


def test_attestation_rejects_unknown_method():
    with pytest.raises(ValueError):
        build_interpretation_attestation57(response_carrier_ids=[], reviewer_id="r", reviewer_role="x", extraction_method="MAGIC", assignment_claims={}, prediction_claims={}, issued_at=1)


def test_attestation_requires_reviewer():
    with pytest.raises(ValueError):
        build_interpretation_attestation57(response_carrier_ids=[], reviewer_id="", reviewer_role="x", extraction_method="HUMAN_RUBRIC", assignment_claims={}, prediction_claims={}, issued_at=1)


def test_topology_rejects_scalar_distance():
    with pytest.raises(ValueError):
        build_misunderstanding_topology57("p", "r", scalar_distance_claimed=True)


def test_evidence_rejects_global_claim():
    with pytest.raises(ValueError):
        build_understanding_evidence57("p", "r", capability_scores={}, capability_states={}, global_understanding_claimed=True)


def test_evidence_rejects_unknown_capability():
    with pytest.raises(ValueError):
        build_understanding_evidence57("p", "r", capability_scores={"alien": 1}, capability_states={"alien": "LOCAL-CANDIDATE"})


def test_frontier_populates_all_capabilities():
    f = build_understanding_frontier57("l", "d")
    assert set(f.capability_states) == set(UNDERSTANDING_CAPABILITIES)
    assert all(x == "UNOBSERVED" for x in f.capability_states.values())


def test_frontier_rejects_scalar_rank():
    with pytest.raises(ValueError):
        build_understanding_frontier57("l", "d", scalar_rank_claimed=True)


def test_frontier_rejects_completion():
    with pytest.raises(ValueError):
        build_understanding_frontier57("l", "d", completion_claimed=True)


def test_lease_requires_reversibility():
    with pytest.raises(ValueError):
        build_intervention_lease57("c", "l", probe_ids=[], operator_uris=["u"], target_capabilities=[UNDERSTANDING_CAPABILITIES[0]], max_uses=1, valid_from=1, valid_until=2, reversible=False)


def test_lease_requires_positive_uses():
    with pytest.raises(ValueError):
        build_intervention_lease57("c", "l", probe_ids=[], operator_uris=["u"], target_capabilities=[UNDERSTANDING_CAPABILITIES[0]], max_uses=0, valid_from=1, valid_until=2)


def test_plan_rejects_persuasion_claim():
    with pytest.raises(ValueError):
        build_intervention_plan57("l", "c", "f", lease_ids=[], priority_records=[], no_persuasion_claimed=False)
