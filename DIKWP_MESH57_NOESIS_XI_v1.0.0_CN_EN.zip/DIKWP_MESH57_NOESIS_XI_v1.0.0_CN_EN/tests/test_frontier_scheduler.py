from __future__ import annotations

import pytest

from dikwp_mesh57_noesis.builders import build_understanding_evidence57, build_understanding_frontier57
from dikwp_mesh57_noesis.frontier import advance_frontier57
from dikwp_mesh57_noesis.models import UNDERSTANDING_CAPABILITIES
from dikwp_mesh57_noesis.scheduler import OPERATOR_BY_CAPABILITY, compile_intervention_plan57


def test_frontier_evolves_to_retention_and_contradiction(run57):
    final = run57["frontiers"][-1]
    assert sum(s == "RETENTION-SUPPORTED" for s in final.capability_states.values()) == 11
    assert sum(s == "HELD-CONTRADICTION" for s in final.capability_states.values()) == 1


def test_frontier_preserves_obstruction(run57):
    assert run57["frontiers"][-1].active_obstruction_ids


def test_frontier_preserves_exteriority(run57):
    assert set(run57["covenant"].protected_exterior_handles).issubset(run57["frontiers"][-1].protected_exterior_handles)


def test_frontier_is_never_complete(run57):
    assert all(not f.completion_claimed for f in run57["frontiers"])


def test_late_failure_holds_prior_support():
    prior = build_understanding_frontier57("l", "d", capability_states={"transfer_invariance": "TRANSFER-SUPPORTED"})
    evidence = build_understanding_evidence57("p", "r", capability_scores={"transfer_invariance": 0.2}, capability_states={"transfer_invariance": "UNOBSERVED"})
    new = advance_frontier57("l", "d", [evidence], previous=prior)
    assert new.capability_states["transfer_invariance"] == "HELD-CONTRADICTION"
    assert new.invalidated_claims


def test_contradiction_reopens_only_with_strong_transfer():
    prior = build_understanding_frontier57("l", "d", capability_states={"transfer_invariance": "HELD-CONTRADICTION"})
    weak = build_understanding_evidence57("p", "r", capability_scores={"transfer_invariance": 0.8}, capability_states={"transfer_invariance": "TRANSFER-SUPPORTED"})
    assert advance_frontier57("l", "d", [weak], previous=prior).capability_states["transfer_invariance"] == "HELD-CONTRADICTION"
    strong = build_understanding_evidence57("p2", "r2", capability_scores={"transfer_invariance": 0.9}, capability_states={"transfer_invariance": "TRANSFER-SUPPORTED"})
    assert advance_frontier57("l", "d", [strong], previous=prior).capability_states["transfer_invariance"] == "TRANSFER-SUPPORTED"


def test_scheduler_has_operator_for_every_capability():
    assert set(OPERATOR_BY_CAPABILITY) == set(UNDERSTANDING_CAPABILITIES)


def test_scheduler_respects_max_interventions(run57):
    plan, leases = compile_intervention_plan57(run57["frontiers"][0], run57["covenant"], candidate_probe_ids=[], issued_at=run57["covenant"].valid_from + 1, valid_until=run57["covenant"].valid_from + 100, max_interventions=2)
    assert len(leases) == 2
    assert len(plan.priority_records) == 2


def test_scheduler_produces_reversible_leases(run57):
    assert all(x.reversible for x in run57["baseline_leases"] + run57["final_leases"])


def test_scheduler_plan_is_nonpersuasive(run57):
    assert run57["baseline_plan"].no_persuasion_claimed
    assert run57["final_plan"].no_persuasion_claimed


def test_scheduler_rejects_interval_outside_covenant(run57):
    with pytest.raises(ValueError):
        compile_intervention_plan57(run57["frontiers"][0], run57["covenant"], candidate_probe_ids=[], issued_at=0, valid_until=1)
