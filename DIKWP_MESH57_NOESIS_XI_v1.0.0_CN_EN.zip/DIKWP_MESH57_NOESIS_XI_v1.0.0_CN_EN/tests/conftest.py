from __future__ import annotations

from pathlib import Path

import pytest

from dikwp_mesh57_noesis.demo import build_reference_noesis_episode57


@pytest.fixture(scope="session")
def run57():
    return build_reference_noesis_episode57()


@pytest.fixture
def reference_dir():
    return Path(__file__).resolve().parents[1] / "outputs" / "reference"
