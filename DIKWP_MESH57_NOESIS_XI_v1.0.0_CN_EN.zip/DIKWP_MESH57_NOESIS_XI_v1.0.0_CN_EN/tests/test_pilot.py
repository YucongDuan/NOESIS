from __future__ import annotations

import json

from dikwp_mesh57_noesis.pilot import build_pilot_kit57, validate_session_template57, write_pilot_kit57


def test_pilot_kit_has_required_files_and_no_global_rank():
    kit = build_pilot_kit57()
    assert len(kit) == 7
    assert kit["reviewer_rubric57.json"]["no_total_person_score"] is True
    assert kit["session_template57.json"]["global_rank"] is None
    assert kit["session_template57.json"]["automatic_score"] is None


def test_pilot_preregistration_has_refutation_and_stops():
    pre = build_pilot_kit57()["preregistration57.json"]
    assert pre["minimum_decisive_pattern"]["refutes_strong_noesis_claim"]
    assert len(pre["stop_rules"]) >= 4
    assert "global intelligence score" in pre["prohibited_outcomes"]


def test_session_template_validation_passes():
    session = build_pilot_kit57()["session_template57.json"]
    report = validate_session_template57(session)
    assert report["status"] == "PASS"
    assert report["failed"] == 0


def test_session_template_validation_catches_rank_and_veto():
    session = build_pilot_kit57()["session_template57.json"]
    session["global_rank"] = 1
    session["learner_veto_available"] = False
    report = validate_session_template57(session)
    assert report["status"] == "FAIL"
    assert report["failed"] >= 2


def test_write_pilot_kit(tmp_path):
    paths = write_pilot_kit57(tmp_path)
    assert len(paths) == 8
    payload = json.loads((tmp_path / "session_template57.json").read_text())
    assert validate_session_template57(payload)["status"] == "PASS"
