"""DIKWP-MESH 5.7 NOESIS: exteriority-preserving human understanding runtime."""

__version__ = "1.0.0"
EVIDENCE_GRADE = "E2 — author-side deterministic reference"
SYSTEM_NAME = "DIKWP-MESH 5.7 NOESIS Ξ"
