from __future__ import annotations

from dataclasses import replace
from typing import Any, Mapping, Sequence

from .canonical import bounded, content_id, sha256_obj
from .models import (
    EVIDENCE_STATES,
    PHASES,
    PROBE_KINDS,
    UNDERSTANDING_CAPABILITIES,
    DeliberateErrorEpisode57,
    EpisodeSummary57,
    InterpretationAttestation57,
    InterventionLease57,
    InterventionPlan57,
    MisunderstandingTopology57,
    UnderstandingCovenant57,
    UnderstandingEvidence57,
    UnderstandingFrontier57,
    UnderstandingProbe57,
    UnderstandingResponse57,
)


def _strings(values: Sequence[Any]) -> list[str]:
    return sorted(set(str(x) for x in values if str(x)))


def _interval(value: Sequence[float], name: str = "interval") -> list[float]:
    values = list(value)
    if len(values) != 2 or any(isinstance(x, bool) or not isinstance(x, (int, float)) for x in values):
        raise TypeError(f"{name} must be [lower, upper]")
    lo, hi = float(values[0]), float(values[1])
    if not 0.0 <= lo <= hi <= 1.0:
        raise ValueError(f"{name} must be ordered within [0,1]")
    return [lo, hi]


def _strict_int(value: int, name: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise TypeError(f"{name} must be int")
    return value


def _build(prefix: str, cls: type, body: dict[str, Any], id_field: str, hash_field: str):
    object_id, digest = content_id(prefix, body)
    return cls(**{id_field: object_id, **body, hash_field: digest})


def build_understanding_covenant57(
    learner_id: str,
    domain_id: str,
    *,
    purpose_handles: Sequence[str],
    allowed_probe_kinds: Sequence[str] = PROBE_KINDS,
    allowed_carrier_kinds: Sequence[str] = ("TEXT", "SILENCE", "GESTURE", "SENSOR", "EMBODIED_EVENT", "REFUSAL", "INACCESSIBLE", "OPAQUE_REFERENCE"),
    prohibited_inferences: Sequence[str] = ("infer_motive", "infer_loyalty", "diagnose_identity", "fill_refused_content", "rank_person_globally"),
    protected_exterior_handles: Sequence[str] = (),
    burden_budget: Mapping[str, int] | None = None,
    data_scope: Sequence[str] = ("LOCAL_EPISODE",),
    learner_veto: bool = True,
    valid_from: int,
    valid_until: int,
    status: str = "ACTIVE",
) -> UnderstandingCovenant57:
    if not str(learner_id).strip() or not str(domain_id).strip():
        raise ValueError("learner_id and domain_id are required")
    if not learner_veto:
        raise ValueError("MESH 5.7 NOESIS requires learner veto")
    allowed = _strings(allowed_probe_kinds)
    unknown = set(allowed) - set(PROBE_KINDS)
    if unknown:
        raise ValueError(f"unknown probe kinds: {sorted(unknown)}")
    start, end = _strict_int(valid_from, "valid_from"), _strict_int(valid_until, "valid_until")
    if start >= end:
        raise ValueError("valid_from must precede valid_until")
    budget = {str(k): int(v) for k, v in dict(burden_budget or {"max_probe_count": 24, "max_burden_units": 100, "max_minutes": 120}).items()}
    if any(v < 0 for v in budget.values()):
        raise ValueError("burden budgets must be non-negative")
    body = {
        "learner_id": str(learner_id),
        "domain_id": str(domain_id),
        "purpose_handles": _strings(purpose_handles),
        "allowed_probe_kinds": allowed,
        "allowed_carrier_kinds": _strings(allowed_carrier_kinds),
        "prohibited_inferences": _strings(prohibited_inferences),
        "protected_exterior_handles": _strings(protected_exterior_handles),
        "burden_budget": budget,
        "data_scope": _strings(data_scope),
        "learner_veto": True,
        "valid_from": start,
        "valid_until": end,
        "status": str(status),
    }
    return _build("UC57", UnderstandingCovenant57, body, "covenant_id", "covenant_hash")


def build_understanding_probe57(
    phase: str,
    probe_kind: str,
    context_id: str,
    *,
    carrier_ids: Sequence[str],
    target_capabilities: Sequence[str],
    structure_family: str,
    surface_family: str,
    expected_contract: Mapping[str, Any],
    falsification_conditions: Sequence[str],
    burden_units: int = 1,
) -> UnderstandingProbe57:
    phase, probe_kind = str(phase).upper(), str(probe_kind).upper()
    if phase not in PHASES:
        raise ValueError(f"unsupported phase: {phase}")
    if probe_kind not in PROBE_KINDS:
        raise ValueError(f"unsupported probe kind: {probe_kind}")
    targets = _strings(target_capabilities)
    unknown = set(targets) - set(UNDERSTANDING_CAPABILITIES)
    if unknown:
        raise ValueError(f"unknown capabilities: {sorted(unknown)}")
    if not targets:
        raise ValueError("at least one target capability is required")
    burden = _strict_int(burden_units, "burden_units")
    if burden < 0:
        raise ValueError("burden_units must be non-negative")
    body = {
        "phase": phase,
        "probe_kind": probe_kind,
        "context_id": str(context_id),
        "carrier_ids": _strings(carrier_ids),
        "target_capabilities": targets,
        "structure_family": str(structure_family),
        "surface_family": str(surface_family),
        "expected_contract": dict(expected_contract),
        "falsification_conditions": _strings(falsification_conditions),
        "burden_units": burden,
    }
    return _build("UP57", UnderstandingProbe57, body, "probe_id", "probe_hash")


def build_interpretation_attestation57(
    *,
    response_carrier_ids: Sequence[str],
    reviewer_id: str,
    reviewer_role: str,
    extraction_method: str,
    assignment_claims: Mapping[str, Any],
    prediction_claims: Mapping[str, Any],
    unknown_handles: Sequence[str] = (),
    exteriority_handles: Sequence[str] = (),
    confidence_interval: Sequence[float] = (0.0, 1.0),
    disagreement_handles: Sequence[str] = (),
    limitations: Sequence[str] = (),
    issued_at: int,
) -> InterpretationAttestation57:
    if not str(reviewer_id).strip() or not str(reviewer_role).strip():
        raise ValueError("reviewer identity and role are required")
    method = str(extraction_method).upper()
    if method not in {"HUMAN_RUBRIC", "AI_ASSISTED_HUMAN_SIGNOFF", "STRUCTURED_DIRECT"}:
        raise ValueError("unsupported extraction method")
    body = {
        "response_carrier_ids": _strings(response_carrier_ids),
        "reviewer_id": str(reviewer_id),
        "reviewer_role": str(reviewer_role),
        "extraction_method": method,
        "assignment_claims": dict(assignment_claims),
        "prediction_claims": dict(prediction_claims),
        "unknown_handles": _strings(unknown_handles),
        "exteriority_handles": _strings(exteriority_handles),
        "confidence_interval": _interval(confidence_interval, "confidence_interval"),
        "disagreement_handles": _strings(disagreement_handles),
        "limitations": _strings(limitations),
        "issued_at": _strict_int(issued_at, "issued_at"),
    }
    return _build("IA57", InterpretationAttestation57, body, "attestation_id", "attestation_hash")


def build_understanding_response57(
    probe_id: str,
    learner_id: str,
    *,
    response_carrier_ids: Sequence[str],
    local_section_ids: Sequence[str],
    world_ids: Sequence[str],
    assignment_claims: Mapping[str, Any],
    prediction_claims: Mapping[str, Any],
    confidence_interval: Sequence[float],
    unknown_handles: Sequence[str] = (),
    exteriority_handles: Sequence[str] = (),
    revision_parent_id: str | None = None,
    submitted_at: int,
) -> UnderstandingResponse57:
    if not str(probe_id).strip() or not str(learner_id).strip():
        raise ValueError("probe_id and learner_id are required")
    body = {
        "probe_id": str(probe_id),
        "learner_id": str(learner_id),
        "response_carrier_ids": _strings(response_carrier_ids),
        "local_section_ids": _strings(local_section_ids),
        "world_ids": _strings(world_ids),
        "assignment_claims": dict(assignment_claims),
        "prediction_claims": dict(prediction_claims),
        "confidence_interval": _interval(confidence_interval, "confidence_interval"),
        "unknown_handles": _strings(unknown_handles),
        "exteriority_handles": _strings(exteriority_handles),
        "revision_parent_id": None if revision_parent_id is None else str(revision_parent_id),
        "submitted_at": _strict_int(submitted_at, "submitted_at"),
    }
    return _build("UR57", UnderstandingResponse57, body, "response_id", "response_hash")


def build_deliberate_error_episode57(
    probe_id: str,
    learner_id: str,
    *,
    generated_wrong_model: Mapping[str, Any],
    predicted_failure: Mapping[str, Any],
    observed_mismatch: Mapping[str, Any],
    correction_handles: Sequence[str],
    transfer_hypothesis: Sequence[str],
    status: str = "CORRECTED-WITH-TRACE",
) -> DeliberateErrorEpisode57:
    if not generated_wrong_model or not observed_mismatch:
        raise ValueError("a deliberate error episode requires both wrong model and observed mismatch")
    body = {
        "probe_id": str(probe_id),
        "learner_id": str(learner_id),
        "generated_wrong_model": dict(generated_wrong_model),
        "predicted_failure": dict(predicted_failure),
        "observed_mismatch": dict(observed_mismatch),
        "correction_handles": _strings(correction_handles),
        "transfer_hypothesis": _strings(transfer_hypothesis),
        "status": str(status),
    }
    return _build("DE57", DeliberateErrorEpisode57, body, "error_id", "error_hash")


def build_misunderstanding_topology57(
    probe_id: str,
    response_id: str,
    *,
    purpose_gaps: Sequence[str] = (),
    semantic_address_gaps: Sequence[str] = (),
    process_gaps: Sequence[str] = (),
    effect_kernel_gaps: Sequence[str] = (),
    boundary_gaps: Sequence[str] = (),
    temporal_gaps: Sequence[str] = (),
    grammar_gaps: Sequence[str] = (),
    calibration_gaps: Sequence[str] = (),
    opacity_violations: Sequence[str] = (),
    gluing_status: str = "UNTESTED",
    legitimate_plurality_handles: Sequence[str] = (),
    repair_modes: Sequence[str] = (),
    scalar_distance_claimed: bool = False,
) -> MisunderstandingTopology57:
    if scalar_distance_claimed:
        raise ValueError("NOESIS does not reduce misunderstanding to one scalar distance")
    body = {
        "probe_id": str(probe_id),
        "response_id": str(response_id),
        "purpose_gaps": _strings(purpose_gaps),
        "semantic_address_gaps": _strings(semantic_address_gaps),
        "process_gaps": _strings(process_gaps),
        "effect_kernel_gaps": _strings(effect_kernel_gaps),
        "boundary_gaps": _strings(boundary_gaps),
        "temporal_gaps": _strings(temporal_gaps),
        "grammar_gaps": _strings(grammar_gaps),
        "calibration_gaps": _strings(calibration_gaps),
        "opacity_violations": _strings(opacity_violations),
        "gluing_status": str(gluing_status),
        "legitimate_plurality_handles": _strings(legitimate_plurality_handles),
        "repair_modes": _strings(repair_modes),
        "scalar_distance_claimed": False,
    }
    return _build("MT57", MisunderstandingTopology57, body, "topology_id", "topology_hash")


def build_understanding_evidence57(
    probe_id: str,
    response_id: str,
    *,
    capability_scores: Mapping[str, float],
    capability_states: Mapping[str, str],
    passed_handles: Sequence[str] = (),
    failed_handles: Sequence[str] = (),
    held_handles: Sequence[str] = (),
    transfer_valid: bool = False,
    retention_valid: bool = False,
    exteriority_preserved: bool = False,
    obstruction_preserved: bool = False,
    global_understanding_claimed: bool = False,
    evidence_grade: str = "E2-LOCAL-EPISODE",
) -> UnderstandingEvidence57:
    if global_understanding_claimed:
        raise ValueError("NOESIS forbids global understanding claims")
    scores = {str(k): round(bounded(float(v)), 6) for k, v in capability_scores.items()}
    if set(scores) - set(UNDERSTANDING_CAPABILITIES):
        raise ValueError("unknown capability in scores")
    states = {str(k): str(v) for k, v in capability_states.items()}
    if set(states) - set(UNDERSTANDING_CAPABILITIES) or set(states.values()) - set(EVIDENCE_STATES):
        raise ValueError("unknown capability or evidence state")
    body = {
        "probe_id": str(probe_id),
        "response_id": str(response_id),
        "capability_scores": scores,
        "capability_states": states,
        "passed_handles": _strings(passed_handles),
        "failed_handles": _strings(failed_handles),
        "held_handles": _strings(held_handles),
        "transfer_valid": bool(transfer_valid),
        "retention_valid": bool(retention_valid),
        "exteriority_preserved": bool(exteriority_preserved),
        "obstruction_preserved": bool(obstruction_preserved),
        "global_understanding_claimed": False,
        "evidence_grade": str(evidence_grade),
    }
    return _build("UE57", UnderstandingEvidence57, body, "evidence_id", "evidence_hash")


def build_understanding_frontier57(
    learner_id: str,
    domain_id: str,
    *,
    capability_states: Mapping[str, str] | None = None,
    capability_evidence_ids: Mapping[str, Sequence[str]] | None = None,
    active_obstruction_ids: Sequence[str] = (),
    protected_exterior_handles: Sequence[str] = (),
    open_questions: Sequence[str] = (),
    invalidated_claims: Sequence[str] = (),
    scalar_rank_claimed: bool = False,
    completion_claimed: bool = False,
    status: str = "OPEN",
) -> UnderstandingFrontier57:
    if scalar_rank_claimed or completion_claimed:
        raise ValueError("frontier cannot claim scalar rank or completion")
    states = {cap: "UNOBSERVED" for cap in UNDERSTANDING_CAPABILITIES}
    states.update({str(k): str(v) for k, v in dict(capability_states or {}).items()})
    if set(states) != set(UNDERSTANDING_CAPABILITIES) or set(states.values()) - set(EVIDENCE_STATES):
        raise ValueError("frontier must provide valid state for every capability")
    evidence_ids = {cap: _strings(dict(capability_evidence_ids or {}).get(cap, ())) for cap in UNDERSTANDING_CAPABILITIES}
    body = {
        "learner_id": str(learner_id),
        "domain_id": str(domain_id),
        "capability_states": states,
        "capability_evidence_ids": evidence_ids,
        "active_obstruction_ids": _strings(active_obstruction_ids),
        "protected_exterior_handles": _strings(protected_exterior_handles),
        "open_questions": _strings(open_questions),
        "invalidated_claims": _strings(invalidated_claims),
        "scalar_rank_claimed": False,
        "completion_claimed": False,
        "status": str(status),
    }
    return _build("UF57", UnderstandingFrontier57, body, "frontier_id", "frontier_hash")


def build_intervention_lease57(
    covenant_id: str,
    learner_id: str,
    *,
    probe_ids: Sequence[str],
    operator_uris: Sequence[str],
    target_capabilities: Sequence[str],
    max_uses: int,
    valid_from: int,
    valid_until: int,
    reversible: bool = True,
    rollback_handles: Sequence[str] = (),
    status: str = "ACTIVE",
) -> InterventionLease57:
    if not reversible:
        raise ValueError("NOESIS interventions must be reversible")
    targets = _strings(target_capabilities)
    if set(targets) - set(UNDERSTANDING_CAPABILITIES):
        raise ValueError("unknown target capability")
    uses = _strict_int(max_uses, "max_uses")
    if uses < 1:
        raise ValueError("max_uses must be positive")
    start, end = _strict_int(valid_from, "valid_from"), _strict_int(valid_until, "valid_until")
    if start >= end:
        raise ValueError("invalid lease interval")
    body = {
        "covenant_id": str(covenant_id),
        "learner_id": str(learner_id),
        "probe_ids": _strings(probe_ids),
        "operator_uris": _strings(operator_uris),
        "target_capabilities": targets,
        "max_uses": uses,
        "valid_from": start,
        "valid_until": end,
        "reversible": True,
        "rollback_handles": _strings(rollback_handles),
        "status": str(status),
    }
    return _build("IL57", InterventionLease57, body, "lease_id", "lease_hash")


def build_intervention_plan57(
    learner_id: str,
    covenant_id: str,
    frontier_id: str,
    *,
    lease_ids: Sequence[str],
    priority_records: Sequence[Mapping[str, Any]],
    purpose_recontract_required: bool = False,
    obstruction_to_preserve: Sequence[str] = (),
    exteriority_constraints: Sequence[str] = (),
    no_persuasion_claimed: bool = True,
    status: str = "PROPOSED-REVERSIBLE",
) -> InterventionPlan57:
    if not no_persuasion_claimed:
        raise ValueError("NOESIS does not authorize persuasion as understanding repair")
    body = {
        "learner_id": str(learner_id),
        "covenant_id": str(covenant_id),
        "frontier_id": str(frontier_id),
        "lease_ids": _strings(lease_ids),
        "priority_records": [dict(x) for x in priority_records],
        "purpose_recontract_required": bool(purpose_recontract_required),
        "obstruction_to_preserve": _strings(obstruction_to_preserve),
        "exteriority_constraints": _strings(exteriority_constraints),
        "no_persuasion_claimed": True,
        "status": str(status),
    }
    return _build("IP57", InterventionPlan57, body, "plan_id", "plan_hash")


def build_episode_summary57(
    episode_id: str,
    learner_id: str,
    domain_id: str,
    covenant_id: str,
    *,
    probe_ids: Sequence[str],
    evidence_ids: Sequence[str],
    frontier_id: str,
    upstream_bundle_id: str,
    upstream_receipt_id: str,
    action_warrant_id: str,
    transindividual_judgment_id: str,
    obstruction_ids: Sequence[str] = (),
    exteriority_ids: Sequence[str] = (),
    status: str = "COMMITTED-OPEN",
    claims_not_made: Sequence[str] = (),
) -> EpisodeSummary57:
    body = {
        "episode_id": str(episode_id),
        "learner_id": str(learner_id),
        "domain_id": str(domain_id),
        "covenant_id": str(covenant_id),
        "probe_ids": _strings(probe_ids),
        "evidence_ids": _strings(evidence_ids),
        "frontier_id": str(frontier_id),
        "upstream_bundle_id": str(upstream_bundle_id),
        "upstream_receipt_id": str(upstream_receipt_id),
        "action_warrant_id": str(action_warrant_id),
        "transindividual_judgment_id": str(transindividual_judgment_id),
        "obstruction_ids": _strings(obstruction_ids),
        "exteriority_ids": _strings(exteriority_ids),
        "status": str(status),
        "claims_not_made": _strings(claims_not_made),
    }
    digest = sha256_obj(body)
    return EpisodeSummary57(**body, episode_hash=digest)


def verify_content_object57(item: Any) -> bool:
    """Verify content identity for a NOESIS dataclass without trusting its supplied hash."""
    data = item.to_dict() if hasattr(item, "to_dict") else dict(item)
    hash_fields = [k for k in data if k.endswith("_hash")]
    id_fields = [k for k in data if k.endswith("_id") and k not in {"learner_id", "domain_id", "context_id", "probe_id", "response_id", "covenant_id", "frontier_id", "episode_id", "upstream_bundle_id", "upstream_receipt_id", "action_warrant_id", "transindividual_judgment_id", "revision_parent_id"}]
    if not hash_fields:
        return False
    supplied = data.pop(hash_fields[-1])
    if id_fields:
        data.pop(id_fields[0], None)
    return supplied == sha256_obj(data)
