from __future__ import annotations

import types
from dataclasses import fields
from pathlib import Path
from typing import Any, get_args, get_origin, get_type_hints

from .canonical import write_json
from .models import (
    EVIDENCE_STATES, PHASES, PROBE_KINDS, UNDERSTANDING_CAPABILITIES,
    DeliberateErrorEpisode57, EpisodeSummary57, InterpretationAttestation57,
    InterventionLease57, InterventionPlan57, MisunderstandingTopology57,
    UnderstandingCovenant57, UnderstandingEvidence57, UnderstandingFrontier57,
    UnderstandingProbe57, UnderstandingResponse57,
)


MODEL_CLASSES = [
    UnderstandingCovenant57,
    UnderstandingProbe57,
    InterpretationAttestation57,
    UnderstandingResponse57,
    DeliberateErrorEpisode57,
    MisunderstandingTopology57,
    UnderstandingEvidence57,
    UnderstandingFrontier57,
    InterventionLease57,
    InterventionPlan57,
    EpisodeSummary57,
]


def _type_schema(tp: Any) -> dict[str, Any]:
    if tp is Any:
        return {}
    origin = get_origin(tp)
    args = get_args(tp)
    if origin in {list, tuple, set}:
        return {"type": "array", "items": _type_schema(args[0] if args else Any)}
    if origin is dict:
        return {"type": "object", "additionalProperties": _type_schema(args[1] if len(args) > 1 else Any)}
    if origin in {types.UnionType, getattr(__import__('typing'), 'Union', object)} or type(None) in args:
        variants = [_type_schema(x) for x in args if x is not type(None)]
        variants.append({"type": "null"})
        return {"anyOf": variants}
    if tp is str:
        return {"type": "string"}
    if tp is int:
        return {"type": "integer"}
    if tp is float:
        return {"type": "number"}
    if tp is bool:
        return {"type": "boolean"}
    return {}


def schema_for_model57(cls: type) -> dict[str, Any]:
    hints = get_type_hints(cls)
    properties: dict[str, Any] = {}
    required = []
    for field in fields(cls):
        name = field.name
        schema = _type_schema(hints.get(name, Any))
        if name.endswith("_hash") or name == "episode_hash":
            schema = {"type": "string", "pattern": "^[0-9a-f]{64}$"}
        elif name.endswith("_id") and name not in {"revision_parent_id"}:
            schema = {"type": "string", "minLength": 1}
        properties[name] = schema
        required.append(name)
    title = cls.__name__
    schema = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": f"urn:noesis57:schema:{title}",
        "title": title,
        "type": "object",
        "required": required,
        "additionalProperties": False,
        "properties": properties,
    }
    p = schema["properties"]
    if cls is UnderstandingCovenant57:
        p["allowed_probe_kinds"]["items"] = {"type": "string", "enum": list(PROBE_KINDS)}
        p["learner_veto"] = {"const": True}
    elif cls is UnderstandingProbe57:
        p["phase"] = {"type": "string", "enum": list(PHASES)}
        p["probe_kind"] = {"type": "string", "enum": list(PROBE_KINDS)}
        p["target_capabilities"]["items"] = {"type": "string", "enum": list(UNDERSTANDING_CAPABILITIES)}
        p["burden_units"] = {"type": "integer", "minimum": 0}
    elif cls is InterpretationAttestation57:
        p["extraction_method"] = {"type": "string", "enum": ["HUMAN_RUBRIC", "AI_ASSISTED_HUMAN_SIGNOFF", "STRUCTURED_DIRECT"]}
        p["confidence_interval"] = {"type": "array", "prefixItems": [{"type": "number", "minimum": 0, "maximum": 1}, {"type": "number", "minimum": 0, "maximum": 1}], "minItems": 2, "maxItems": 2}
    elif cls is UnderstandingResponse57:
        p["confidence_interval"] = {"type": "array", "prefixItems": [{"type": "number", "minimum": 0, "maximum": 1}, {"type": "number", "minimum": 0, "maximum": 1}], "minItems": 2, "maxItems": 2}
    elif cls is MisunderstandingTopology57:
        p["scalar_distance_claimed"] = {"const": False}
    elif cls is UnderstandingEvidence57:
        p["capability_scores"] = {"type": "object", "propertyNames": {"enum": list(UNDERSTANDING_CAPABILITIES)}, "additionalProperties": {"type": "number", "minimum": 0, "maximum": 1}}
        p["capability_states"] = {"type": "object", "propertyNames": {"enum": list(UNDERSTANDING_CAPABILITIES)}, "additionalProperties": {"type": "string", "enum": list(EVIDENCE_STATES)}}
        p["global_understanding_claimed"] = {"const": False}
    elif cls is UnderstandingFrontier57:
        p["capability_states"] = {"type": "object", "required": list(UNDERSTANDING_CAPABILITIES), "additionalProperties": False, "properties": {cap: {"type": "string", "enum": list(EVIDENCE_STATES)} for cap in UNDERSTANDING_CAPABILITIES}}
        p["capability_evidence_ids"] = {"type": "object", "required": list(UNDERSTANDING_CAPABILITIES), "additionalProperties": False, "properties": {cap: {"type": "array", "items": {"type": "string"}} for cap in UNDERSTANDING_CAPABILITIES}}
        p["scalar_rank_claimed"] = {"const": False}
        p["completion_claimed"] = {"const": False}
    elif cls is InterventionLease57:
        p["target_capabilities"]["items"] = {"type": "string", "enum": list(UNDERSTANDING_CAPABILITIES)}
        p["max_uses"] = {"type": "integer", "minimum": 1}
        p["reversible"] = {"const": True}
    elif cls is InterventionPlan57:
        p["no_persuasion_claimed"] = {"const": True}
    return schema


def build_all_schemas57() -> dict[str, dict[str, Any]]:
    schemas: dict[str, dict[str, Any]] = {}
    for cls in MODEL_CLASSES:
        name = cls.__name__ + ".schema.json"
        schemas[name] = schema_for_model57(cls)
    for cls, stem in [
        (UnderstandingProbe57, "probes57"),
        (UnderstandingResponse57, "responses57"),
        (InterpretationAttestation57, "interpretation_attestations57"),
        (MisunderstandingTopology57, "misunderstanding_topologies57"),
        (UnderstandingEvidence57, "understanding_evidence57"),
        (UnderstandingFrontier57, "understanding_frontiers57"),
    ]:
        schemas[f"{stem}.collection.schema.json"] = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "$id": f"urn:noesis57:schema:{stem}-collection",
            "title": f"{cls.__name__} collection",
            "type": "array",
            "minItems": 1,
            "items": schema_for_model57(cls),
        }
    schemas["reference_summary57.schema.json"] = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "urn:noesis57:schema:reference-summary",
        "type": "object",
        "required": ["system", "version", "evidence_grade", "probe_count", "capability_count", "global_understanding_claimed", "scalar_rank_claimed", "completion_claimed", "claims_not_made"],
        "properties": {
            "system": {"const": "DIKWP-MESH 5.7 NOESIS Ξ"},
            "version": {"const": "1.0.0"},
            "evidence_grade": {"type": "string"},
            "probe_count": {"type": "integer", "minimum": 1},
            "capability_count": {"const": 12},
            "global_understanding_claimed": {"const": False},
            "scalar_rank_claimed": {"const": False},
            "completion_claimed": {"const": False},
            "claims_not_made": {"type": "array", "minItems": 1, "items": {"type": "string"}},
        },
        "additionalProperties": True,
    }
    schemas["conformance_report57.schema.json"] = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "urn:noesis57:schema:conformance-report",
        "type": "object",
        "required": ["system", "version", "status", "passed", "failed", "checks", "upstream_mesh57"],
        "properties": {
            "status": {"enum": ["PASS", "FAIL"]},
            "passed": {"type": "integer", "minimum": 0},
            "failed": {"type": "integer", "minimum": 0},
            "checks": {"type": "array", "items": {"type": "object"}},
            "upstream_mesh57": {"type": "object"},
        },
        "additionalProperties": True,
    }
    return schemas


def export_schemas57(path: str | Path) -> list[Path]:
    root = Path(path)
    root.mkdir(parents=True, exist_ok=True)
    paths = []
    for name, schema in sorted(build_all_schemas57().items()):
        target = root / name
        write_json(target, schema)
        paths.append(target)
    return paths
