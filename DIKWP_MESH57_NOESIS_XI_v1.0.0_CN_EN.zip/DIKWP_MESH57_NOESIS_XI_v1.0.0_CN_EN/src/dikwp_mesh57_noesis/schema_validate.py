from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

try:  # Optional standards-complete backend.
    from jsonschema import Draft202012Validator as _Draft202012Validator
except ImportError:  # pragma: no cover - exercised in clean-wheel validation
    _Draft202012Validator = None

from .schema_export import build_all_schemas57


OUTPUT_SCHEMA_MAP = {
    "reference_summary57.json": "reference_summary57.schema.json",
    "understanding_covenant57.json": "UnderstandingCovenant57.schema.json",
    "probes57.json": "probes57.collection.schema.json",
    "responses57.json": "responses57.collection.schema.json",
    "interpretation_attestations57.json": "interpretation_attestations57.collection.schema.json",
    "misunderstanding_topologies57.json": "misunderstanding_topologies57.collection.schema.json",
    "understanding_evidence57.json": "understanding_evidence57.collection.schema.json",
    "understanding_frontiers57.json": "understanding_frontiers57.collection.schema.json",
    "baseline_intervention_plan57.json": "InterventionPlan57.schema.json",
    "final_intervention_plan57.json": "InterventionPlan57.schema.json",
    "episode_summary57.json": "EpisodeSummary57.schema.json",
}


def _is_type(value: Any, expected: str) -> bool:
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    return True


def _fallback_errors(instance: Any, schema: dict[str, Any], path: str = "$") -> list[str]:
    """Validate the deterministic subset of JSON Schema emitted by NOESIS.

    This is intentionally not advertised as a general JSON Schema engine. It
    permits clean offline execution when the optional jsonschema dependency is
    absent, while every release is also checked with Draft202012Validator.
    """
    errors: list[str] = []
    if "anyOf" in schema:
        if not any(not _fallback_errors(instance, candidate, path) for candidate in schema["anyOf"]):
            errors.append(f"{path}: does not match anyOf")
        return errors
    if "const" in schema and instance != schema["const"]:
        errors.append(f"{path}: expected const {schema['const']!r}")
    if "enum" in schema and instance not in schema["enum"]:
        errors.append(f"{path}: {instance!r} not in enum")
    expected_type = schema.get("type")
    if isinstance(expected_type, str) and not _is_type(instance, expected_type):
        errors.append(f"{path}: expected {expected_type}, got {type(instance).__name__}")
        return errors
    if isinstance(instance, str):
        if "minLength" in schema and len(instance) < int(schema["minLength"]):
            errors.append(f"{path}: string shorter than minLength")
        if "pattern" in schema and re.fullmatch(str(schema["pattern"]), instance) is None:
            errors.append(f"{path}: does not match pattern")
    if isinstance(instance, (int, float)) and not isinstance(instance, bool):
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append(f"{path}: below minimum")
        if "maximum" in schema and instance > schema["maximum"]:
            errors.append(f"{path}: above maximum")
    if isinstance(instance, list):
        if "minItems" in schema and len(instance) < int(schema["minItems"]):
            errors.append(f"{path}: fewer than minItems")
        if "maxItems" in schema and len(instance) > int(schema["maxItems"]):
            errors.append(f"{path}: more than maxItems")
        prefix = schema.get("prefixItems", [])
        for index, item_schema in enumerate(prefix):
            if index < len(instance):
                errors.extend(_fallback_errors(instance[index], item_schema, f"{path}[{index}]"))
        if "items" in schema:
            for index, item in enumerate(instance):
                errors.extend(_fallback_errors(item, schema["items"], f"{path}[{index}]"))
    if isinstance(instance, dict):
        for key in schema.get("required", []):
            if key not in instance:
                errors.append(f"{path}: missing required property {key!r}")
        properties = schema.get("properties", {})
        for key, child_schema in properties.items():
            if key in instance:
                errors.extend(_fallback_errors(instance[key], child_schema, f"{path}.{key}"))
        if "propertyNames" in schema:
            for key in instance:
                errors.extend(_fallback_errors(key, schema["propertyNames"], f"{path}.<key:{key}>"))
        additional = schema.get("additionalProperties", True)
        extras = set(instance) - set(properties)
        if additional is False:
            for key in sorted(extras):
                errors.append(f"{path}: unexpected property {key!r}")
        elif isinstance(additional, dict):
            for key in sorted(extras):
                errors.extend(_fallback_errors(instance[key], additional, f"{path}.{key}"))
    return errors


def validate_instance57(instance: Any, schema: dict[str, Any], *, force_fallback: bool = False) -> tuple[list[str], str]:
    if _Draft202012Validator is not None and not force_fallback:
        errors = sorted(_Draft202012Validator(schema).iter_errors(instance), key=lambda e: list(e.path))
        return [f"{list(error.path)}: {error.message}" for error in errors], "jsonschema-draft-2020-12"
    return _fallback_errors(instance, schema), "noesis-deterministic-subset"


def validate_schemas57(output_dir: str | Path, *, force_fallback: bool = False) -> dict[str, Any]:
    root = Path(output_dir)
    schemas = build_all_schemas57()
    checks = []
    backend = "uninitialized"
    for filename, schema_name in OUTPUT_SCHEMA_MAP.items():
        path = root / filename
        if not path.is_file():
            checks.append({"file": filename, "schema": schema_name, "passed": False, "error": "missing"})
            continue
        payload = json.loads(path.read_text(encoding="utf-8"))
        errors, backend = validate_instance57(payload, schemas[schema_name], force_fallback=force_fallback)
        checks.append({
            "file": filename,
            "schema": schema_name,
            "passed": not errors,
            "error": None if not errors else "; ".join(errors[:5]),
        })
    passed = sum(1 for x in checks if x["passed"])
    failed = len(checks) - passed
    return {
        "status": "PASS" if failed == 0 else "FAIL",
        "passed": passed,
        "failed": failed,
        "checks": checks,
        "schema_count": len(schemas),
        "backend": backend,
    }
