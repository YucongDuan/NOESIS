from __future__ import annotations

from collections import defaultdict
from typing import Iterable

from .builders import build_understanding_frontier57
from .models import UNDERSTANDING_CAPABILITIES, UnderstandingEvidence57, UnderstandingFrontier57


STATE_ORDER = {
    "UNOBSERVED": 0,
    "LOCAL-CANDIDATE": 1,
    "INTERVENTION-TESTED": 2,
    "TRANSFER-SUPPORTED": 3,
    "RETENTION-SUPPORTED": 4,
    "HELD-CONTRADICTION": -1,
}


def _merge_state(previous: str, incoming: str, score: float) -> tuple[str, bool]:
    if incoming == "HELD-CONTRADICTION":
        return incoming, True
    if previous in {"TRANSFER-SUPPORTED", "RETENTION-SUPPORTED"} and score < 0.50:
        return "HELD-CONTRADICTION", True
    if previous == "HELD-CONTRADICTION":
        # Contradictions require explicit new transfer/retention evidence to reopen.
        if incoming in {"TRANSFER-SUPPORTED", "RETENTION-SUPPORTED"} and score >= 0.85:
            return incoming, False
        return previous, True
    return (incoming if STATE_ORDER[incoming] >= STATE_ORDER[previous] else previous), False


def advance_frontier57(
    learner_id: str,
    domain_id: str,
    evidence_items: Iterable[UnderstandingEvidence57],
    *,
    previous: UnderstandingFrontier57 | None = None,
    active_obstruction_ids: Iterable[str] = (),
    protected_exterior_handles: Iterable[str] = (),
    open_questions: Iterable[str] = (),
) -> UnderstandingFrontier57:
    states = {cap: "UNOBSERVED" for cap in UNDERSTANDING_CAPABILITIES}
    ids: dict[str, list[str]] = defaultdict(list)
    invalidated = list(previous.invalidated_claims if previous else [])
    if previous:
        states.update(previous.capability_states)
        for cap, values in previous.capability_evidence_ids.items():
            ids[cap].extend(values)
    for evidence in evidence_items:
        for cap, incoming in evidence.capability_states.items():
            score = float(evidence.capability_scores.get(cap, 0.0))
            merged, contradiction = _merge_state(states[cap], incoming, score)
            if contradiction and merged == "HELD-CONTRADICTION":
                invalidated.append(f"{cap}: prior support held by {evidence.evidence_id}")
            states[cap] = merged
            if evidence.evidence_id not in ids[cap]:
                ids[cap].append(evidence.evidence_id)
    obs = set(previous.active_obstruction_ids if previous else []) | set(str(x) for x in active_obstruction_ids)
    ext = set(previous.protected_exterior_handles if previous else []) | set(str(x) for x in protected_exterior_handles)
    questions = set(previous.open_questions if previous else []) | set(str(x) for x in open_questions)
    if any(state == "HELD-CONTRADICTION" for state in states.values()):
        status = "OPEN-WITH-CONTRADICTION"
    elif obs:
        status = "OPEN-THROUGH-OBSTRUCTION"
    else:
        status = "OPEN"
    return build_understanding_frontier57(
        learner_id,
        domain_id,
        capability_states=states,
        capability_evidence_ids=ids,
        active_obstruction_ids=obs,
        protected_exterior_handles=ext,
        open_questions=questions,
        invalidated_claims=invalidated,
        scalar_rank_claimed=False,
        completion_claimed=False,
        status=status,
    )
