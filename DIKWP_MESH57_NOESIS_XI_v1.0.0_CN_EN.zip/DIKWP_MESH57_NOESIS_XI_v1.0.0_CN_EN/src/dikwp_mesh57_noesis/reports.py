from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

from .canonical import read_json
from .models import UNDERSTANDING_CAPABILITIES


LABELS = {
    "purpose_recontracting": "目的重契约",
    "cross_carrier_association": "跨载体关联",
    "process_world_construction": "过程世界生成",
    "predictive_intervention": "预测与干预",
    "counterworld_generation": "反事实世界生成",
    "transfer_invariance": "迁移不变量",
    "boundary_temporal_awareness": "边界—时间觉察",
    "calibration_revision": "校准与修订",
    "gluing_obstruction_literacy": "拼合／阻碍素养",
    "exteriority_integrity": "外部性完整性",
    "metagrammar_plasticity": "元语法可塑性",
    "transindividual_participation": "超个体参与",
}

STATE_LABELS = {
    "UNOBSERVED": "未观测",
    "LOCAL-CANDIDATE": "局部候选",
    "INTERVENTION-TESTED": "干预测试",
    "TRANSFER-SUPPORTED": "迁移支持",
    "RETENTION-SUPPORTED": "保持支持",
    "HELD-CONTRADICTION": "保留矛盾",
}


def _esc(value: Any) -> str:
    return html.escape(str(value), quote=True)


def build_dashboard_html57(summary: dict[str, Any], probes: list[dict[str, Any]], evidences: list[dict[str, Any]], frontiers: list[dict[str, Any]], topologies: list[dict[str, Any]]) -> str:
    final = frontiers[-1]
    rows = []
    for cap in UNDERSTANDING_CAPABILITIES:
        state = final["capability_states"][cap]
        evidence_count = len(final["capability_evidence_ids"].get(cap, []))
        rows.append(f"<tr><td>{_esc(LABELS[cap])}</td><td><span class='pill state-{_esc(state.lower())}'>{_esc(STATE_LABELS[state])}</span></td><td>{evidence_count}</td></tr>")
    timeline = []
    for p, e, f, t in zip(probes, evidences, frontiers, topologies):
        supported = sum(1 for s in e["capability_states"].values() if s in {"INTERVENTION-TESTED", "TRANSFER-SUPPORTED", "RETENTION-SUPPORTED"})
        held = sum(1 for s in e["capability_states"].values() if s == "HELD-CONTRADICTION")
        timeline.append(
            "<article class='phase'>"
            f"<h3>{_esc(p['phase'])} · {_esc(p['probe_kind'])}</h3>"
            f"<p><b>表层：</b>{_esc(p['surface_family'])}<br><b>结构：</b>{_esc(p['structure_family'])}</p>"
            f"<p>支持维度：{supported}；保留矛盾：{held}；失败检查：{len(e['failed_handles'])}</p>"
            f"<p><b>拼合：</b>{_esc(t['gluing_status'])}；<b>修复模式：</b>{_esc(', '.join(t['repair_modes']) or '无')}</p>"
            "</article>"
        )
    claims = "".join(f"<li>{_esc(x)}</li>" for x in summary["claims_not_made"])
    open_questions = "".join(f"<li>{_esc(x)}</li>" for x in final["open_questions"])
    payload = json.dumps({"summary": summary, "final_frontier": final}, ensure_ascii=False).replace("</", "<\\/")
    return f"""<!doctype html>
<html lang='zh-CN'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>DIKWP-MESH 5.7 NOESIS Ξ</title>
<style>
:root{{--bg:#f5f5f2;--panel:#fff;--ink:#171717;--muted:#666;--line:#d9d9d2;--accent:#111;}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,"Noto Sans SC","Microsoft YaHei",system-ui,sans-serif;line-height:1.55}}
header{{padding:48px 5vw 30px;border-bottom:1px solid var(--line);background:#fff}} header h1{{font-size:clamp(28px,5vw,58px);line-height:1.02;margin:0;max-width:1100px}} header p{{max-width:900px;color:var(--muted);font-size:18px}}
main{{max-width:1280px;margin:auto;padding:30px 5vw 70px}} .grid{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}} .card,.panel,.phase{{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:20px}} .card b{{display:block;font-size:28px}} .card span{{color:var(--muted);font-size:13px}} .two{{display:grid;grid-template-columns:1.1fr .9fr;gap:18px;margin-top:18px}} h2{{margin-top:0}} table{{width:100%;border-collapse:collapse}} th,td{{text-align:left;border-bottom:1px solid var(--line);padding:10px 6px}} .pill{{display:inline-block;border:1px solid var(--ink);border-radius:999px;padding:2px 8px;font-size:12px}} .state-held-contradiction{{border-style:dashed}} .timeline{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}} .phase h3{{margin-top:0}} code{{background:#eee;padding:2px 5px;border-radius:4px}} .note{{border-left:4px solid var(--ink);padding-left:16px}} footer{{color:var(--muted);font-size:13px;margin-top:35px}} @media(max-width:900px){{.grid,.timeline{{grid-template-columns:repeat(2,1fr)}}.two{{grid-template-columns:1fr}}}} @media(max-width:560px){{.grid,.timeline{{grid-template-columns:1fr}}}}
</style></head><body>
<header><h1>NOESIS Ξ：不是“知道答案”，而是生成可迁移、可反证且不吞没外部性的过程世界</h1>
<p>DIKWP‑MESH 5.7 外部性保持的人类理解世界生成与超个体提升运行时。该页面展示的是确定性合成参考证据，不是现实人群效果结论。</p></header>
<main>
<section class='grid'>
<div class='card'><b>{summary['probe_count']}</b><span>六阶段理解探针</span></div>
<div class='card'><b>{summary['capability_count']}</b><span>非总分式能力坐标</span></div>
<div class='card'><b>{summary['final_capability_state_counts'].get('RETENTION-SUPPORTED',0)}</b><span>保持支持维度</span></div>
<div class='card'><b>{summary['final_capability_state_counts'].get('HELD-CONTRADICTION',0)}</b><span>被保留而非抹平的矛盾</span></div>
</section>
<section class='two'>
<div class='panel'><h2>最终理解前沿</h2><table><thead><tr><th>能力</th><th>证据状态</th><th>证据链</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div>
<div class='panel'><h2>理解的操作性定义</h2><p class='note'>{_esc(summary['understanding_definition'])}</p><p><b>状态：</b>{_esc(summary['final_frontier_status'])}</p><p><b>阻碍保留：</b>{_esc(summary['obstruction_preserved'])}<br><b>外部性保留：</b>{_esc(summary['exteriority_preserved'])}<br><b>全局理解声明：</b>{_esc(summary['global_understanding_claimed'])}</p><h3>仍然开放的问题</h3><ul>{open_questions}</ul></div>
</section>
<section class='panel' style='margin-top:18px'><h2>理解证据时间线</h2><div class='timeline'>{''.join(timeline)}</div></section>
<section class='two'>
<div class='panel'><h2>关键范式转移</h2><p><b>从：</b>把理解当作发送者语义在接收者内部的复现。</p><p><b>到：</b>在目的约束下生成局部过程世界，经预测、干预、反事实、迁移和延迟复测检验；局部世界不能拼合时输出阻碍证书；拒绝、不透明和未遭遇外部可以约束行动而不被内容化。</p></div>
<div class='panel'><h2>本版本不作出的主张</h2><ul>{claims}</ul></div>
</section>
<footer>Evidence grade: {_esc(summary['evidence_grade'])}. 单文件离线页面，无外部脚本。<script type='application/json' id='noesis-data'>{payload}</script></footer>
</main></body></html>"""


def write_dashboard57(output_dir: str | Path, target: str | Path | None = None) -> Path:
    out = Path(output_dir)
    summary = read_json(out / "reference_summary57.json")
    probes = read_json(out / "probes57.json")
    evidences = read_json(out / "understanding_evidence57.json")
    frontiers = read_json(out / "understanding_frontiers57.json")
    topologies = read_json(out / "misunderstanding_topologies57.json")
    path = Path(target) if target is not None else out / "dashboard.html"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(build_dashboard_html57(summary, probes, evidences, frontiers, topologies), encoding="utf-8")
    return path
