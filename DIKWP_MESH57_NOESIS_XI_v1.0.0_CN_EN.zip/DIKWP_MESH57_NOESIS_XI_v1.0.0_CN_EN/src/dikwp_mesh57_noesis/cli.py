from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import EVIDENCE_GRADE, SYSTEM_NAME, __version__
from .artifacts import validate_output_dir57
from .canonical import write_json
from .conformance import run_conformance_noesis57
from .demo import write_reference_noesis_episode57
from .reports import write_dashboard57
from .pilot import validate_session_template57, write_pilot_kit57


def _print(value) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="noesis57", description="DIKWP-MESH 5.7 NOESIS Xi human understanding evidence runtime")
    parser.add_argument("--version", action="store_true", help="show version")
    sub = parser.add_subparsers(dest="command")
    demo = sub.add_parser("demo", help="run deterministic reference episode")
    demo.add_argument("--out", required=True)
    conf = sub.add_parser("conformance", help="run NOESIS and upstream MESH 5.7 conformance")
    conf.add_argument("--out")
    validate = sub.add_parser("artifacts-validate", help="validate a generated output directory")
    validate.add_argument("--root", required=True)
    dash = sub.add_parser("dashboard", help="generate offline dashboard from an output directory")
    dash.add_argument("--root", required=True)
    dash.add_argument("--out")
    pilot = sub.add_parser("pilot-kit", help="write a non-diagnostic human-pilot scaffold")
    pilot.add_argument("--out", required=True)
    pvalidate = sub.add_parser("pilot-validate", help="validate a NOESIS human-session JSON envelope")
    pvalidate.add_argument("--file", required=True)
    sub.add_parser("definition", help="print the operational definition of understanding")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.version:
        print(f"{SYSTEM_NAME} {__version__} | {EVIDENCE_GRADE}")
        return 0
    if not args.command:
        parser.print_help()
        return 0
    try:
        if args.command == "demo":
            summary = write_reference_noesis_episode57(args.out)
            dashboard = write_dashboard57(args.out)
            result = {**summary, "dashboard": str(dashboard)}
        elif args.command == "conformance":
            result = run_conformance_noesis57()
            if args.out:
                write_json(args.out, result)
        elif args.command == "artifacts-validate":
            result = validate_output_dir57(args.root)
        elif args.command == "dashboard":
            result = {"dashboard": str(write_dashboard57(args.root, args.out))}
        elif args.command == "pilot-kit":
            paths = write_pilot_kit57(args.out)
            result = {"status": "PASS", "file_count": len(paths), "files": [str(x) for x in paths], "claims_human_effectiveness": False}
        elif args.command == "pilot-validate":
            payload = json.loads(Path(args.file).read_text(encoding="utf-8"))
            result = validate_session_template57(payload)
        elif args.command == "definition":
            result = {
                "definition_cn": "理解是在目的约束下，从异质遭遇中生成并修订局部过程世界，使其能支持解释、预测、干预和迁移；局部世界不能拼合时保留阻碍，遇到拒绝、不透明和未遭遇外部时允许其约束行动而不强制同化，并只授权有限、可逆、可复核的行动。",
                "not_equivalent_to": ["复述", "高信心", "发送者意图的机械复现", "一次答对", "单一总分", "全局闭合"],
            }
        else:  # pragma: no cover
            parser.error("unknown command")
            return 2
        _print(result)
        return 0 if result.get("status", "PASS") == "PASS" else 2
    except (OSError, ValueError, TypeError, RuntimeError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "ERROR", "error_type": type(exc).__name__, "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
