from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from .builders import build_misunderstanding_topology57, build_understanding_evidence57
from .canonical import bounded
from .models import (
    DeliberateErrorEpisode57,
    InterpretationAttestation57,
    UnderstandingCovenant57,
    UnderstandingEvidence57,
    UnderstandingProbe57,
    UnderstandingResponse57,
    MisunderstandingTopology57,
)


@dataclass(frozen=True)
class AssessmentResult57:
    topology: MisunderstandingTopology57
    evidence: UnderstandingEvidence57
    diagnostics: dict[str, Any]


def _get(mapping: Mapping[str, Any], dotted: str) -> tuple[bool, Any]:
    current: Any = mapping
    for part in dotted.split("."):
        if not isinstance(current, Mapping) or part not in current:
            return False, None
        current = current[part]
    return True, current


def _match(actual: Any, expected: Any) -> bool:
    if isinstance(expected, Mapping):
        if "one_of" in expected:
            return actual in expected["one_of"]
        if "contains" in expected:
            try:
                return set(expected["contains"]).issubset(set(actual))
            except TypeError:
                return False
        if "min_count" in expected:
            try:
                return len(actual) >= int(expected["min_count"])
            except (TypeError, ValueError):
                return False
        if "range" in expected:
            try:
                lo, hi = [float(x) for x in expected["range"]]
                value = float(actual)
            except (TypeError, ValueError):
                return False
            return lo <= value <= hi
        if "exists" in expected:
            return (actual is not None) is bool(expected["exists"])
        if "not" in expected:
            return not _match(actual, expected["not"])
    return actual == expected


def _coverage(checks: Sequence[bool]) -> float:
    return sum(1.0 for x in checks if x) / len(checks) if checks else 0.0


def _state_for(phase: str, score: float, *, contradiction: bool = False) -> str:
    if contradiction:
        return "HELD-CONTRADICTION"
    if score < 0.50:
        return "UNOBSERVED"
    if score < 0.72:
        return "LOCAL-CANDIDATE"
    if phase == "DELAYED":
        return "RETENTION-SUPPORTED"
    if phase in {"TRANSFER", "COLLECTIVE"}:
        return "TRANSFER-SUPPORTED"
    if phase in {"TRAINING", "EXTERIOR"}:
        return "INTERVENTION-TESTED"
    return "LOCAL-CANDIDATE"


def _record(checks: list[dict[str, Any]], handle: str, passed: bool, category: str, detail: Any = None) -> bool:
    checks.append({"handle": handle, "passed": bool(passed), "category": category, "detail": detail})
    return bool(passed)


def _claims_from_attestation(
    response: UnderstandingResponse57,
    attestation: InterpretationAttestation57 | None,
) -> tuple[dict[str, Any], dict[str, Any], list[str], list[str], list[float], list[str]]:
    if attestation is None:
        return (
            dict(response.assignment_claims),
            dict(response.prediction_claims),
            list(response.unknown_handles),
            list(response.exteriority_handles),
            list(response.confidence_interval),
            ["structured-response-used-without-independent-interpretation-attestation"],
        )
    if not set(response.response_carrier_ids).issubset(set(attestation.response_carrier_ids)):
        raise ValueError("attestation does not cover all response carriers")
    return (
        dict(attestation.assignment_claims),
        dict(attestation.prediction_claims),
        list(attestation.unknown_handles),
        list(attestation.exteriority_handles),
        list(attestation.confidence_interval),
        list(attestation.limitations) + list(attestation.disagreement_handles),
    )


def assess_understanding57(
    probe: UnderstandingProbe57,
    response: UnderstandingResponse57,
    covenant: UnderstandingCovenant57,
    *,
    attestation: InterpretationAttestation57 | None = None,
    deliberate_error: DeliberateErrorEpisode57 | None = None,
) -> AssessmentResult57:
    if response.probe_id != probe.probe_id:
        raise ValueError("response does not bind probe")
    if response.learner_id != covenant.learner_id:
        raise ValueError("response learner does not bind covenant")
    if probe.probe_kind not in covenant.allowed_probe_kinds:
        raise ValueError("probe kind not permitted by covenant")
    if response.submitted_at < covenant.valid_from or response.submitted_at > covenant.valid_until:
        raise ValueError("response lies outside covenant interval")

    assignments, predictions, unknowns, exteriorities, confidence, interpretation_limits = _claims_from_attestation(response, attestation)
    contract = dict(probe.expected_contract)
    checks: list[dict[str, Any]] = []
    by_capability: dict[str, list[bool]] = {cap: [] for cap in probe.target_capabilities}

    def check(capability: str, handle: str, passed: bool, category: str, detail: Any = None) -> bool:
        result = _record(checks, handle, passed, category, detail)
        if capability in by_capability:
            by_capability[capability].append(result)
        return result

    # Purpose is plural and may be renegotiated rather than inferred as one fixed goal.
    purpose_contracts = assignments.get("purpose_contracts", [])
    min_purposes = int(contract.get("min_purpose_contracts", 1))
    check("purpose_recontracting", "purpose.plural-contracts", isinstance(purpose_contracts, list) and len(purpose_contracts) >= min_purposes, "purpose", purpose_contracts)
    if contract.get("requires_affected_party_veto"):
        check("purpose_recontracting", "purpose.affected-party-veto", assignments.get("affected_party_veto") is True, "purpose")
    if contract.get("requires_purpose_recontract"):
        check("purpose_recontracting", "purpose.recontracted", bool(assignments.get("purpose_recontracted")), "purpose")

    required_kinds = set(contract.get("required_carrier_kinds", []))
    integrated_kinds = set(assignments.get("carrier_kinds_integrated", []))
    check("cross_carrier_association", "carrier.required-kinds", required_kinds.issubset(integrated_kinds), "semantic_address", {"required": sorted(required_kinds), "actual": sorted(integrated_kinds)})
    if contract.get("requires_nontext_carrier"):
        check("cross_carrier_association", "carrier.nontext", bool(integrated_kinds - {"TEXT"}), "semantic_address")

    min_worlds = int(contract.get("min_world_count", 1))
    min_sections = int(contract.get("min_section_count", 1))
    check("process_world_construction", "world.minimum", len(response.world_ids) >= min_worlds, "process", len(response.world_ids))
    check("process_world_construction", "section.minimum", len(response.local_section_ids) >= min_sections, "process", len(response.local_section_ids))
    for path, expected in dict(contract.get("required_assignments", {})).items():
        exists, actual = _get(assignments, path)
        capability = str(dict(contract.get("assignment_capability_map", {})).get(path, "process_world_construction"))
        check(capability, f"assignment.{path}", exists and _match(actual, expected), "process", {"expected": expected, "actual": actual})

    for path, expected in dict(contract.get("required_predictions", {})).items():
        exists, actual = _get(predictions, path)
        check("predictive_intervention", f"prediction.{path}", exists and _match(actual, expected), "effect_kernel", {"expected": expected, "actual": actual})
    if contract.get("requires_intervention_contrast"):
        check("predictive_intervention", "prediction.intervention-contrast", bool(assignments.get("intervention_contrast")), "effect_kernel")

    counterworlds = assignments.get("counterworlds", [])
    min_counterworlds = int(contract.get("min_counterworld_count", 0))
    if min_counterworlds:
        check("counterworld_generation", "counterworld.minimum", isinstance(counterworlds, list) and len(counterworlds) >= min_counterworlds, "process", len(counterworlds) if isinstance(counterworlds, list) else None)
    if contract.get("requires_deliberate_error"):
        valid_error = deliberate_error is not None and deliberate_error.probe_id == probe.probe_id and deliberate_error.learner_id == response.learner_id and bool(deliberate_error.correction_handles)
        check("counterworld_generation", "counterworld.deliberate-error-trace", valid_error, "process")

    required_invariants = set(contract.get("required_structure_invariants", []))
    actual_invariants = set(assignments.get("structure_invariants", []))
    if required_invariants:
        check("transfer_invariance", "transfer.invariants", required_invariants.issubset(actual_invariants), "semantic_address", {"required": sorted(required_invariants), "actual": sorted(actual_invariants)})
    source_surface = contract.get("source_surface_family")
    if source_surface is not None:
        check("transfer_invariance", "transfer.surface-shift", probe.surface_family != str(source_surface), "semantic_address", {"source": source_surface, "target": probe.surface_family})
    if probe.phase == "TRANSFER":
        check("transfer_invariance", "transfer.phase", True, "semantic_address")

    required_boundary_states = set(contract.get("required_boundary_states", []))
    if required_boundary_states:
        check("boundary_temporal_awareness", "boundary.states", required_boundary_states.issubset(set(assignments.get("boundary_states", []))), "boundary")
    required_temporal_modes = set(contract.get("required_temporal_modes", []))
    if required_temporal_modes:
        check("boundary_temporal_awareness", "temporal.modes", required_temporal_modes.issubset(set(assignments.get("temporal_modes", []))), "temporal")

    # Calibration is checked against transparent contract coverage, not hidden semantic truth.
    objective_checks = [x["passed"] for x in checks]
    contract_coverage = _coverage(objective_checks)
    midpoint = (float(confidence[0]) + float(confidence[1])) / 2.0
    calibration_tolerance = float(contract.get("calibration_tolerance", 0.22))
    check("calibration_revision", "calibration.interval", abs(midpoint - contract_coverage) <= calibration_tolerance, "calibration", {"midpoint": midpoint, "contract_coverage": contract_coverage, "tolerance": calibration_tolerance})
    if contract.get("requires_revision"):
        check("calibration_revision", "revision.parent", response.revision_parent_id is not None, "calibration")
        check("calibration_revision", "revision.trace", bool(assignments.get("revision_trace")), "calibration")

    expected_gluing = contract.get("expected_gluing")
    actual_gluing = str(assignments.get("gluing_decision", "UNTESTED"))
    if expected_gluing:
        check("gluing_obstruction_literacy", "gluing.decision", actual_gluing == expected_gluing, "gluing", {"expected": expected_gluing, "actual": actual_gluing})
    if expected_gluing == "OBSTRUCTION":
        check("gluing_obstruction_literacy", "gluing.preserve-obstruction", bool(assignments.get("obstruction_preserved")), "gluing")
        check("gluing_obstruction_literacy", "gluing.no-forced-consensus", assignments.get("forced_consensus") is not True, "gluing")

    required_exterior = set(contract.get("required_exteriority_handles", []))
    check("exteriority_integrity", "exterior.required-handles", required_exterior.issubset(set(exteriorities)), "opacity", {"required": sorted(required_exterior), "actual": sorted(exteriorities)})
    forbidden_keys = set(contract.get("forbidden_assignment_keys", [])) | set(covenant.prohibited_inferences)
    present_forbidden = sorted(key for key in forbidden_keys if key in assignments)
    check("exteriority_integrity", "exterior.no-prohibited-inference", not present_forbidden, "opacity", present_forbidden)
    if contract.get("requires_refusal_causal_force"):
        check("exteriority_integrity", "exterior.refusal-causal-force", bool(assignments.get("refusal_constrains_action")), "opacity")

    required_operator_uris = set(contract.get("required_operator_uris", []))
    actual_operator_uris = set(assignments.get("grammar_mutations", []))
    if required_operator_uris:
        check("metagrammar_plasticity", "grammar.required-operator", required_operator_uris.issubset(actual_operator_uris), "grammar", {"required": sorted(required_operator_uris), "actual": sorted(actual_operator_uris)})
    if contract.get("requires_reversible_mutation"):
        check("metagrammar_plasticity", "grammar.reversible", assignments.get("grammar_mutation_reversible") is True, "grammar")

    if contract.get("requires_no_single_owner"):
        check("transindividual_participation", "collective.no-single-owner", assignments.get("no_single_owner") is True, "gluing")
    min_components = int(contract.get("min_irreducible_components", 0))
    if min_components:
        components = assignments.get("irreducible_components", [])
        check("transindividual_participation", "collective.irreducible-components", isinstance(components, list) and len(set(components)) >= min_components, "gluing", components)

    required_unknowns = set(contract.get("required_unknown_handles", []))
    if required_unknowns:
        # Unknown registration supports both world construction and exteriority integrity.
        passed = required_unknowns.issubset(set(unknowns))
        check("process_world_construction", "unknown.required-handles", passed, "process", {"required": sorted(required_unknowns), "actual": sorted(unknowns)})
        check("exteriority_integrity", "unknown.not-filled", passed, "opacity")

    capability_scores: dict[str, float] = {}
    capability_states: dict[str, str] = {}
    contradiction_caps = set(assignments.get("explicitly_contradicted_capabilities", []))
    for capability, capability_checks in by_capability.items():
        score = _coverage(capability_checks)
        contradiction = capability in contradiction_caps
        capability_scores[capability] = score
        capability_states[capability] = _state_for(probe.phase, score, contradiction=contradiction)

    failed = [x for x in checks if not x["passed"]]
    passed_handles = [x["handle"] for x in checks if x["passed"]]
    failed_handles = [x["handle"] for x in failed]
    held_handles = sorted(set(interpretation_limits + list(assignments.get("held_handles", []))))

    purpose_gaps = [x["handle"] for x in failed if x["category"] == "purpose"]
    semantic_gaps = [x["handle"] for x in failed if x["category"] == "semantic_address"]
    process_gaps = [x["handle"] for x in failed if x["category"] == "process"]
    effect_gaps = [x["handle"] for x in failed if x["category"] == "effect_kernel"]
    boundary_gaps = [x["handle"] for x in failed if x["category"] == "boundary"]
    temporal_gaps = [x["handle"] for x in failed if x["category"] == "temporal"]
    grammar_gaps = [x["handle"] for x in failed if x["category"] == "grammar"]
    calibration_gaps = [x["handle"] for x in failed if x["category"] == "calibration"]
    opacity_violations = [x["handle"] for x in failed if x["category"] == "opacity"]

    legitimate_plurality = list(assignments.get("legitimate_plurality_handles", []))
    repair_modes: list[str] = []
    if purpose_gaps:
        repair_modes.append("PURPOSE-RECONTRACT")
    if semantic_gaps:
        repair_modes.append("CROSS-CARRIER-REMAP")
    if process_gaps or effect_gaps:
        repair_modes.append("PROCESS-COUNTERWORLD")
    if boundary_gaps or temporal_gaps:
        repair_modes.append("BOUNDARY-TIME-ROTATION")
    if grammar_gaps:
        repair_modes.append("REVERSIBLE-METAGRAMMAR-MUTATION")
    if calibration_gaps:
        repair_modes.append("PREDICT-BEFORE-FEEDBACK-AND-REVISE")
    if opacity_violations:
        repair_modes.append("STOP-ASSIMILATION-RESTORE-EXTERIORITY")
    if actual_gluing not in {"OBSTRUCTION", "GLOBAL-CANDIDATE", "UNTESTED"}:
        repair_modes.append("GLUING-REVIEW")

    gluing_status = actual_gluing
    obstruction_preserved = expected_gluing != "OBSTRUCTION" or (
        actual_gluing == "OBSTRUCTION" and assignments.get("obstruction_preserved") is True
    )
    exteriority_preserved = not opacity_violations and required_exterior.issubset(set(exteriorities))
    transfer_valid = probe.phase in {"TRANSFER", "COLLECTIVE"} and capability_scores.get("transfer_invariance", 0.0) >= 0.72
    retention_valid = probe.phase == "DELAYED" and all(score >= 0.72 for score in capability_scores.values())

    topology = build_misunderstanding_topology57(
        probe.probe_id,
        response.response_id,
        purpose_gaps=purpose_gaps,
        semantic_address_gaps=semantic_gaps,
        process_gaps=process_gaps,
        effect_kernel_gaps=effect_gaps,
        boundary_gaps=boundary_gaps,
        temporal_gaps=temporal_gaps,
        grammar_gaps=grammar_gaps,
        calibration_gaps=calibration_gaps,
        opacity_violations=opacity_violations,
        gluing_status=gluing_status,
        legitimate_plurality_handles=legitimate_plurality,
        repair_modes=repair_modes,
        scalar_distance_claimed=False,
    )
    evidence = build_understanding_evidence57(
        probe.probe_id,
        response.response_id,
        capability_scores=capability_scores,
        capability_states=capability_states,
        passed_handles=passed_handles,
        failed_handles=failed_handles,
        held_handles=held_handles,
        transfer_valid=transfer_valid,
        retention_valid=retention_valid,
        exteriority_preserved=exteriority_preserved,
        obstruction_preserved=obstruction_preserved,
        global_understanding_claimed=False,
        evidence_grade="E2-LOCAL-STRUCTURED-EPISODE",
    )
    diagnostics = {
        "contract_coverage_before_calibration_check": round(contract_coverage, 6),
        "confidence_interval": confidence,
        "confidence_midpoint": round(midpoint, 6),
        "check_count": len(checks),
        "passed_check_count": len(passed_handles),
        "failed_check_count": len(failed_handles),
        "checks": checks,
        "interpretation_limitations": interpretation_limits,
        "no_total_understanding_score": True,
    }
    return AssessmentResult57(topology=topology, evidence=evidence, diagnostics=diagnostics)
