from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


UNDERSTANDING_CAPABILITIES = (
    "purpose_recontracting",
    "cross_carrier_association",
    "process_world_construction",
    "predictive_intervention",
    "counterworld_generation",
    "transfer_invariance",
    "boundary_temporal_awareness",
    "calibration_revision",
    "gluing_obstruction_literacy",
    "exteriority_integrity",
    "metagrammar_plasticity",
    "transindividual_participation",
)

PHASES = ("BASELINE", "TRAINING", "TRANSFER", "DELAYED", "COLLECTIVE", "EXTERIOR")
PROBE_KINDS = (
    "RECONSTRUCT",
    "PREDICT",
    "INTERVENE",
    "COUNTERWORLD",
    "TRANSFER",
    "BOUNDARY_TIME",
    "CALIBRATE_REVISE",
    "GLUE_OR_OBSTRUCT",
    "PRESERVE_EXTERIOR",
    "MUTATE_GRAMMAR",
    "TRANSINDIVIDUAL",
)
EVIDENCE_STATES = (
    "UNOBSERVED",
    "LOCAL-CANDIDATE",
    "INTERVENTION-TESTED",
    "TRANSFER-SUPPORTED",
    "RETENTION-SUPPORTED",
    "HELD-CONTRADICTION",
)


@dataclass(frozen=True)
class UnderstandingCovenant57:
    covenant_id: str
    learner_id: str
    domain_id: str
    purpose_handles: list[str]
    allowed_probe_kinds: list[str]
    allowed_carrier_kinds: list[str]
    prohibited_inferences: list[str]
    protected_exterior_handles: list[str]
    burden_budget: dict[str, int]
    data_scope: list[str]
    learner_veto: bool
    valid_from: int
    valid_until: int
    status: str
    covenant_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class UnderstandingProbe57:
    probe_id: str
    phase: str
    probe_kind: str
    context_id: str
    carrier_ids: list[str]
    target_capabilities: list[str]
    structure_family: str
    surface_family: str
    expected_contract: dict[str, Any]
    falsification_conditions: list[str]
    burden_units: int
    probe_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class InterpretationAttestation57:
    attestation_id: str
    response_carrier_ids: list[str]
    reviewer_id: str
    reviewer_role: str
    extraction_method: str
    assignment_claims: dict[str, Any]
    prediction_claims: dict[str, Any]
    unknown_handles: list[str]
    exteriority_handles: list[str]
    confidence_interval: list[float]
    disagreement_handles: list[str]
    limitations: list[str]
    issued_at: int
    attestation_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class DeliberateErrorEpisode57:
    error_id: str
    probe_id: str
    learner_id: str
    generated_wrong_model: dict[str, Any]
    predicted_failure: dict[str, Any]
    observed_mismatch: dict[str, Any]
    correction_handles: list[str]
    transfer_hypothesis: list[str]
    status: str
    error_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class UnderstandingResponse57:
    response_id: str
    probe_id: str
    learner_id: str
    response_carrier_ids: list[str]
    local_section_ids: list[str]
    world_ids: list[str]
    assignment_claims: dict[str, Any]
    prediction_claims: dict[str, Any]
    confidence_interval: list[float]
    unknown_handles: list[str]
    exteriority_handles: list[str]
    revision_parent_id: str | None
    submitted_at: int
    response_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class MisunderstandingTopology57:
    topology_id: str
    probe_id: str
    response_id: str
    purpose_gaps: list[str]
    semantic_address_gaps: list[str]
    process_gaps: list[str]
    effect_kernel_gaps: list[str]
    boundary_gaps: list[str]
    temporal_gaps: list[str]
    grammar_gaps: list[str]
    calibration_gaps: list[str]
    opacity_violations: list[str]
    gluing_status: str
    legitimate_plurality_handles: list[str]
    repair_modes: list[str]
    scalar_distance_claimed: bool
    topology_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class UnderstandingEvidence57:
    evidence_id: str
    probe_id: str
    response_id: str
    capability_scores: dict[str, float]
    capability_states: dict[str, str]
    passed_handles: list[str]
    failed_handles: list[str]
    held_handles: list[str]
    transfer_valid: bool
    retention_valid: bool
    exteriority_preserved: bool
    obstruction_preserved: bool
    global_understanding_claimed: bool
    evidence_grade: str
    evidence_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class UnderstandingFrontier57:
    frontier_id: str
    learner_id: str
    domain_id: str
    capability_states: dict[str, str]
    capability_evidence_ids: dict[str, list[str]]
    active_obstruction_ids: list[str]
    protected_exterior_handles: list[str]
    open_questions: list[str]
    invalidated_claims: list[str]
    scalar_rank_claimed: bool
    completion_claimed: bool
    status: str
    frontier_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class InterventionLease57:
    lease_id: str
    covenant_id: str
    learner_id: str
    probe_ids: list[str]
    operator_uris: list[str]
    target_capabilities: list[str]
    max_uses: int
    valid_from: int
    valid_until: int
    reversible: bool
    rollback_handles: list[str]
    status: str
    lease_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class InterventionPlan57:
    plan_id: str
    learner_id: str
    covenant_id: str
    frontier_id: str
    lease_ids: list[str]
    priority_records: list[dict[str, Any]]
    purpose_recontract_required: bool
    obstruction_to_preserve: list[str]
    exteriority_constraints: list[str]
    no_persuasion_claimed: bool
    status: str
    plan_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EpisodeReceipt57:
    receipt_id: str
    idempotency_key: str
    episode_id: str
    decision: str
    event_index: int
    previous_event_hash: str
    event_hash: str
    committed_at: int
    receipt_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EpisodeSummary57:
    episode_id: str
    learner_id: str
    domain_id: str
    covenant_id: str
    probe_ids: list[str]
    evidence_ids: list[str]
    frontier_id: str
    upstream_bundle_id: str
    upstream_receipt_id: str
    action_warrant_id: str
    transindividual_judgment_id: str
    obstruction_ids: list[str]
    exteriority_ids: list[str]
    status: str
    claims_not_made: list[str] = field(default_factory=list)
    episode_hash: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
