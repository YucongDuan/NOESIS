from __future__ import annotations

from typing import Iterable

from .builders import build_intervention_lease57, build_intervention_plan57
from .models import InterventionLease57, InterventionPlan57, UnderstandingCovenant57, UnderstandingFrontier57


OPERATOR_BY_CAPABILITY = {
    "purpose_recontracting": "urn:noesis57:operator:purpose-recontract",
    "cross_carrier_association": "urn:noesis57:operator:cross-carrier-remap",
    "process_world_construction": "urn:noesis57:operator:process-world-rebuild",
    "predictive_intervention": "urn:noesis57:operator:predict-before-intervene",
    "counterworld_generation": "urn:noesis57:operator:deliberate-error-counterworld",
    "transfer_invariance": "urn:noesis57:operator:surface-shift-transfer",
    "boundary_temporal_awareness": "urn:noesis57:operator:boundary-time-rotation",
    "calibration_revision": "urn:noesis57:operator:confidence-revision-loop",
    "gluing_obstruction_literacy": "urn:noesis57:operator:glue-or-preserve-obstruction",
    "exteriority_integrity": "urn:noesis57:operator:opacity-and-refusal-guard",
    "metagrammar_plasticity": "urn:noesis57:operator:reversible-metagrammar-mutation",
    "transindividual_participation": "urn:noesis57:operator:transindividual-deletion-test",
}

STATE_NEED = {
    "UNOBSERVED": 1.0,
    "LOCAL-CANDIDATE": 0.75,
    "INTERVENTION-TESTED": 0.50,
    "TRANSFER-SUPPORTED": 0.25,
    "RETENTION-SUPPORTED": 0.10,
    "HELD-CONTRADICTION": 1.20,
}

HIGH_LEVERAGE = {
    "purpose_recontracting": 1.15,
    "process_world_construction": 1.10,
    "counterworld_generation": 1.12,
    "gluing_obstruction_literacy": 1.18,
    "exteriority_integrity": 1.25,
    "calibration_revision": 1.05,
}


def compile_intervention_plan57(
    frontier: UnderstandingFrontier57,
    covenant: UnderstandingCovenant57,
    *,
    candidate_probe_ids: Iterable[str],
    issued_at: int,
    valid_until: int,
    max_interventions: int = 4,
) -> tuple[InterventionPlan57, list[InterventionLease57]]:
    if covenant.status != "ACTIVE":
        raise ValueError("covenant is not active")
    if issued_at < covenant.valid_from or valid_until > covenant.valid_until or issued_at >= valid_until:
        raise ValueError("plan interval exceeds covenant")
    budget_max = int(covenant.burden_budget.get("max_probe_count", max_interventions))
    count = max(0, min(int(max_interventions), budget_max))
    priorities = []
    for capability, state in frontier.capability_states.items():
        need = STATE_NEED[state]
        leverage = HIGH_LEVERAGE.get(capability, 1.0)
        exterior_bonus = 1.15 if capability == "exteriority_integrity" and frontier.protected_exterior_handles else 1.0
        contradiction_bonus = 1.20 if state == "HELD-CONTRADICTION" else 1.0
        score = round(need * leverage * exterior_bonus * contradiction_bonus, 6)
        priorities.append({
            "capability": capability,
            "state": state,
            "priority": score,
            "operator_uri": OPERATOR_BY_CAPABILITY[capability],
            "rationale": "open-evidence-gap-with-reversibility-and-exteriority-guard",
        })
    priorities.sort(key=lambda item: (-item["priority"], item["capability"]))
    selected = priorities[:count]
    probe_ids = sorted(set(str(x) for x in candidate_probe_ids))
    leases: list[InterventionLease57] = []
    for item in selected:
        leases.append(build_intervention_lease57(
            covenant.covenant_id,
            covenant.learner_id,
            probe_ids=probe_ids,
            operator_uris=[item["operator_uri"]],
            target_capabilities=[item["capability"]],
            max_uses=1,
            valid_from=issued_at,
            valid_until=valid_until,
            reversible=True,
            rollback_handles=[
                "discard-intervention-output",
                "restore-prior-frontier",
                "preserve-local-sections-obstructions-and-refusal",
            ],
            status="ACTIVE",
        ))
    plan = build_intervention_plan57(
        covenant.learner_id,
        covenant.covenant_id,
        frontier.frontier_id,
        lease_ids=[x.lease_id for x in leases],
        priority_records=selected,
        purpose_recontract_required=frontier.capability_states.get("purpose_recontracting") in {"UNOBSERVED", "HELD-CONTRADICTION"},
        obstruction_to_preserve=frontier.active_obstruction_ids,
        exteriority_constraints=frontier.protected_exterior_handles,
        no_persuasion_claimed=True,
        status="PROPOSED-REVERSIBLE",
    )
    return plan, leases
