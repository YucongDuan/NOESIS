from __future__ import annotations

import json
import sqlite3
import tempfile
from dataclasses import replace
from pathlib import Path
from typing import Any, Callable

from dikwp_mesh57.conformance import run_conformance57
from dikwp_mesh57.store import EpistemicEpisodeStore57, build_episode_bundle57

from .assessment import assess_understanding57
from .builders import (
    build_interpretation_attestation57,
    build_understanding_covenant57,
    build_understanding_evidence57,
    build_understanding_frontier57,
    build_understanding_probe57,
    build_understanding_response57,
)
from .canonical import canonical_json, sha256_obj
from .demo import DOMAIN, LEARNER, REFERENCE_TIMESTAMP, build_reference_noesis_episode57
from .frontier import advance_frontier57
from .models import EVIDENCE_STATES, PHASES, PROBE_KINDS, UNDERSTANDING_CAPABILITIES
from .scheduler import OPERATOR_BY_CAPABILITY, compile_intervention_plan57


def _raises(exc: type[BaseException], fn: Callable[[], Any]) -> bool:
    try:
        fn()
    except exc:
        return True
    return False


def _check(name: str, fn: Callable[[], bool], results: list[dict[str, Any]]) -> None:
    try:
        passed = bool(fn())
        error = None
    except Exception as exc:  # pragma: no cover - reported as a failed conformance item
        passed = False
        error = f"{type(exc).__name__}: {exc}"
    results.append({"name": name, "passed": passed, "error": error})


def run_conformance_noesis57() -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    run = build_reference_noesis_episode57()
    upstream = run_conformance57()
    summary = run["summary"]
    covenant = run["covenant"]
    probes = run["probes"]
    responses = run["responses"]
    evidences = run["evidences"]
    frontiers = run["frontiers"]

    _check("upstream MESH 5.7 conformance passes", lambda: upstream["status"] == "PASS" and upstream["failed"] == 0, results)
    _check("twelve understanding capabilities are registered", lambda: len(UNDERSTANDING_CAPABILITIES) == 12 and len(set(UNDERSTANDING_CAPABILITIES)) == 12, results)
    _check("phases include exterior and collective", lambda: {"EXTERIOR", "COLLECTIVE"}.issubset(PHASES), results)
    _check("probe kinds include gluing obstruction and metagrammar mutation", lambda: {"GLUE_OR_OBSTRUCT", "MUTATE_GRAMMAR"}.issubset(PROBE_KINDS), results)
    _check("held contradiction is a first-class evidence state", lambda: "HELD-CONTRADICTION" in EVIDENCE_STATES, results)
    _check("every capability has a reversible operator URI", lambda: set(OPERATOR_BY_CAPABILITY) == set(UNDERSTANDING_CAPABILITIES), results)

    _check("learner covenant has veto", lambda: covenant.learner_veto, results)
    _check("covenant prohibits global personality ranking", lambda: "rank_person_globally" in covenant.prohibited_inferences, results)
    _check("covenant protects refusal exterior", lambda: "opaque:affected-party-refusal" in covenant.protected_exterior_handles, results)
    _check("covenant has finite validity", lambda: covenant.valid_until > covenant.valid_from, results)
    _check("covenant burden is finite", lambda: covenant.burden_budget["max_probe_count"] < 1000, results)
    _check("covenant without learner veto is rejected", lambda: _raises(ValueError, lambda: build_understanding_covenant57("x", "d", purpose_handles=["p"], learner_veto=False, valid_from=1, valid_until=2)), results)
    _check("inverted covenant interval is rejected", lambda: _raises(ValueError, lambda: build_understanding_covenant57("x", "d", purpose_handles=["p"], valid_from=2, valid_until=1)), results)
    _check("unknown probe kind is rejected by covenant", lambda: _raises(ValueError, lambda: build_understanding_covenant57("x", "d", purpose_handles=["p"], allowed_probe_kinds=["ALIEN"], valid_from=1, valid_until=2)), results)

    _check("reference episode has six distinct phases", lambda: len({p.phase for p in probes}) == 6, results)
    _check("all probes bind falsification conditions", lambda: all(p.falsification_conditions for p in probes), results)
    _check("all probes have finite burden", lambda: all(0 <= p.burden_units <= 20 for p in probes), results)
    _check("unknown capability is rejected", lambda: _raises(ValueError, lambda: build_understanding_probe57("BASELINE", "RECONSTRUCT", "c", carrier_ids=[], target_capabilities=["not-real"], structure_family="s", surface_family="t", expected_contract={}, falsification_conditions=["f"])), results)
    _check("negative probe burden is rejected", lambda: _raises(ValueError, lambda: build_understanding_probe57("BASELINE", "RECONSTRUCT", "c", carrier_ids=[], target_capabilities=[UNDERSTANDING_CAPABILITIES[0]], structure_family="s", surface_family="t", expected_contract={}, falsification_conditions=["f"], burden_units=-1)), results)

    _check("all responses bind their probes", lambda: all(r.probe_id == p.probe_id for p, r in zip(probes, responses)), results)
    _check("all responses bind the covenant learner", lambda: all(r.learner_id == covenant.learner_id for r in responses), results)
    _check("refusal response carries no inline semantic text", lambda: run["objects"][-1] is not None and any(getattr(x, "carrier_kind", None) == "REFUSAL" and getattr(x, "inline_text", "sentinel") is None for x in run["objects"]), results)
    _check("invalid confidence interval is rejected", lambda: _raises(ValueError, lambda: build_understanding_response57("p", "l", response_carrier_ids=[], local_section_ids=[], world_ids=[], assignment_claims={}, prediction_claims={}, confidence_interval=[0.8, 0.2], submitted_at=1)), results)
    _check("noninteger response time is rejected", lambda: _raises(TypeError, lambda: build_understanding_response57("p", "l", response_carrier_ids=[], local_section_ids=[], world_ids=[], assignment_claims={}, prediction_claims={}, confidence_interval=[0.1, 0.2], submitted_at=1.5)), results)

    baseline = evidences[0]
    delayed = evidences[-1]
    _check("baseline closed explanation fails multiple checks", lambda: run["diagnostics"][0]["failed_check_count"] >= 10, results)
    _check("baseline motive inference violates opacity", lambda: bool(run["topologies"][0].opacity_violations), results)
    _check("baseline forced consensus fails gluing literacy", lambda: run["topologies"][0].gluing_status == "FORCED-CONSENSUS", results)
    _check("baseline is not misreported as transfer", lambda: not baseline.transfer_valid, results)
    _check("training preserves deliberate error trace", lambda: len(run["deliberate_errors"]) == 1 and run["deliberate_errors"][0].status == "CORRECTED-WITH-TRACE", results)
    _check("training supports counterworld generation", lambda: evidences[1].capability_states["counterworld_generation"] == "INTERVENTION-TESTED", results)
    _check("transfer probe changes surface family", lambda: probes[2].surface_family != probes[2].expected_contract["source_surface_family"], results)
    _check("transfer evidence is explicitly supported", lambda: evidences[2].transfer_valid and evidences[2].capability_states["transfer_invariance"] == "TRANSFER-SUPPORTED", results)
    _check("exterior probe preserves refusal without content extraction", lambda: evidences[3].exteriority_preserved and "no-content-extracted-from-refusal" in evidences[3].held_handles, results)
    _check("collective probe has no single owner", lambda: responses[4].assignment_claims["no_single_owner"] is True, results)
    _check("collective gluing preserves obstruction", lambda: evidences[4].obstruction_preserved, results)
    _check("delayed evidence passes all explicit contract checks", lambda: run["diagnostics"][-1]["failed_check_count"] == 0, results)
    _check("delayed evidence supports retention", lambda: delayed.retention_valid, results)
    _check("delayed evidence preserves exteriority", lambda: delayed.exteriority_preserved, results)
    _check("delayed evidence preserves obstruction", lambda: delayed.obstruction_preserved, results)
    _check("delayed evidence never claims global understanding", lambda: not delayed.global_understanding_claimed, results)
    _check("purpose plurality remains held rather than falsely solved", lambda: delayed.capability_states["purpose_recontracting"] == "HELD-CONTRADICTION", results)

    final = frontiers[-1]
    _check("frontier contains every capability", lambda: set(final.capability_states) == set(UNDERSTANDING_CAPABILITIES), results)
    _check("frontier does not claim scalar rank", lambda: not final.scalar_rank_claimed, results)
    _check("frontier does not claim completion", lambda: not final.completion_claimed, results)
    _check("frontier remains open with contradiction", lambda: final.status == "OPEN-WITH-CONTRADICTION", results)
    _check("frontier retains active obstruction", lambda: bool(final.active_obstruction_ids), results)
    _check("frontier retains protected exterior", lambda: set(covenant.protected_exterior_handles).issubset(final.protected_exterior_handles), results)
    _check("frontier retains open questions", lambda: len(final.open_questions) >= 3, results)
    _check("global scalar rank builder request is rejected", lambda: _raises(ValueError, lambda: build_understanding_frontier57(LEARNER, DOMAIN, scalar_rank_claimed=True)), results)
    _check("completion builder request is rejected", lambda: _raises(ValueError, lambda: build_understanding_frontier57(LEARNER, DOMAIN, completion_claimed=True)), results)

    _check("metagrammar mutation is admitted in parallel", lambda: run["mutation_result"].status == "ADMITTED_PARALLEL", results)
    _check("metagrammar remains nonexhaustive", lambda: not run["mutation_result"].candidate_grammar.exhaustive_claimed, results)
    _check("mutation preserves exterior handles", lambda: bool(run["mutation"].preserved_exterior_handles), results)
    _check("reflection tower retains unreflected handles", lambda: bool(run["reflection_tower"].open_meta_handles), results)
    _check("action warrant is shadow reversible only", lambda: run["warrant"].status == "SHADOW-REVERSIBLE-ONLY", results)
    _check("action warrant prohibits coercive agreement", lambda: "coerce-agreement" in run["warrant"].prohibited_actions, results)
    _check("action warrant prohibits global ranking", lambda: "rank-person-globally" in run["warrant"].prohibited_actions, results)
    _check("action warrant has rollback", lambda: bool(run["warrant"].rollback_plan), results)
    _check("open surface rejects global closure", lambda: not run["surface"].global_closure_claimed, results)
    _check("open surface rejects completion", lambda: not run["surface"].completion_claimed, results)
    _check("open surface preserves unregistered exterior possibility", lambda: run["surface"].unregistered_exterior_remains_possible, results)

    _check("baseline intervention plan is nonpersuasive", lambda: run["baseline_plan"].no_persuasion_claimed, results)
    _check("baseline interventions are reversible", lambda: all(x.reversible for x in run["baseline_leases"]), results)
    _check("final plan preserves obstruction", lambda: bool(run["final_plan"].obstruction_to_preserve), results)
    _check("final plan preserves exteriority constraints", lambda: bool(run["final_plan"].exteriority_constraints), results)
    _check("irreversible lease is rejected", lambda: _raises(ValueError, lambda: compile_intervention_plan57(final, covenant, candidate_probe_ids=[], issued_at=covenant.valid_from - 1, valid_until=covenant.valid_from + 1)), results)

    # Assessment cannot be rebound to another learner or probe.
    bad_response = replace(responses[0], probe_id="different-probe")
    _check("assessment rejects response-probe mismatch", lambda: _raises(ValueError, lambda: assess_understanding57(probes[0], bad_response, covenant, attestation=run["attestations"][0])), results)
    bad_learner = replace(responses[0], learner_id="another-learner")
    _check("assessment rejects response-learner mismatch", lambda: _raises(ValueError, lambda: assess_understanding57(probes[0], bad_learner, covenant, attestation=run["attestations"][0])), results)
    bad_attestation = replace(run["attestations"][0], response_carrier_ids=[])
    _check("assessment rejects attestation that omits response carrier", lambda: _raises(ValueError, lambda: assess_understanding57(probes[0], responses[0], covenant, attestation=bad_attestation)), results)
    _check("evidence builder rejects global understanding claim", lambda: _raises(ValueError, lambda: build_understanding_evidence57("p", "r", capability_scores={}, capability_states={}, global_understanding_claimed=True)), results)

    # Canonicalization and episode-store invariants.
    _check("canonical JSON is deterministic", lambda: canonical_json({"b": 1, "a": 2}) == canonical_json({"a": 2, "b": 1}), results)
    _check("content hash changes on substantive mutation", lambda: sha256_obj(responses[0]) != sha256_obj(replace(responses[0], submitted_at=responses[0].submitted_at + 1)), results)
    with tempfile.TemporaryDirectory(prefix="noesis57-conformance-") as tmp:
        db_path = Path(tmp) / "episode.sqlite"
        store = EpistemicEpisodeStore57(db_path)
        receipt = store.commit(run["bundle"])
        retry = store.commit(run["bundle"])
        verification = store.verify()
        _check("episode store verifies full object bodies", lambda: verification["valid"] and verification["object_count"] >= 150, results)
        _check("idempotent retry returns stable receipt", lambda: receipt.receipt_hash == retry.receipt_hash and verification["event_count"] == 1, results)
        altered = build_episode_bundle57(
            run["bundle"].idempotency_key,
            run["objects"][:-1],
            world_hashes=run["bundle"].world_hashes,
            gluing_federation_hashes=run["bundle"].gluing_federation_hashes,
            obstruction_hashes=run["bundle"].obstruction_hashes,
            judgment_hashes=run["bundle"].judgment_hashes,
            warrant_hashes=run["bundle"].warrant_hashes,
            surface_hash=run["bundle"].surface_hash,
            issued_at=run["bundle"].issued_at,
        )
        _check("same idempotency key cannot bind altered bundle", lambda: _raises(ValueError, lambda: store.commit(altered)), results)

        crash_path = Path(tmp) / "crash.sqlite"
        crash_store = EpistemicEpisodeStore57(crash_path)
        try:
            crash_store.commit(run["bundle"], crash_after_event=True)
        except RuntimeError:
            pass
        crash_verification = crash_store.verify()
        _check("injected crash rolls back objects bundles events and receipts", lambda: crash_verification["object_count"] == 0 and crash_verification["bundle_count"] == 0 and crash_verification["event_count"] == 0 and crash_verification["receipt_count"] == 0, results)

        tamper_path = Path(tmp) / "tamper.sqlite"
        tamper_store = EpistemicEpisodeStore57(tamper_path)
        tamper_store.commit(run["bundle"])
        with sqlite3.connect(tamper_path) as db:
            row = db.execute("SELECT object_hash,body_json FROM objects LIMIT 1").fetchone()
            body = json.loads(row[1])
            body["tampered"] = True
            db.execute("UPDATE objects SET body_json=? WHERE object_hash=?", (json.dumps(body), row[0]))
            db.commit()
        _check("object-body tampering is detected", lambda: not tamper_store.verify()["valid"], results)

    _check("summary explicitly denies human-effectiveness result", lambda: "real-human-understanding-improved" in summary["claims_not_made"], results)
    _check("summary explicitly denies theory validation", lambda: "Duan-understanding-theory-is-empirically-validated-by-this-runtime" in summary["claims_not_made"], results)
    _check("summary does not reduce understanding to sender intent", lambda: "sender-intent-alignment-is-always-correct" in summary["claims_not_made"], results)
    _check("summary does not exhaust understanding by twelve capabilities", lambda: "all-human-understanding-is-exhausted-by-twelve-capabilities" in summary["claims_not_made"], results)

    passed = sum(1 for item in results if item["passed"])
    failed = len(results) - passed
    return {
        "system": "DIKWP-MESH 5.7 NOESIS Ξ",
        "version": "1.0.0",
        "evidence_grade": "E2 — author-side deterministic reference",
        "status": "PASS" if failed == 0 else "FAIL",
        "passed": passed,
        "failed": failed,
        "checks": results,
        "upstream_mesh57": {"status": upstream["status"], "passed": upstream["passed"], "failed": upstream["failed"]},
        "claims_not_made": summary["claims_not_made"],
    }
