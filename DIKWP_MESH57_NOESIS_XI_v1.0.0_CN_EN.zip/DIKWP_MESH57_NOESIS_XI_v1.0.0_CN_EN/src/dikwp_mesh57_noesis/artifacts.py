from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from dikwp_mesh57.store import EpistemicEpisodeStore57

from .canonical import sha256_obj
from .models import UNDERSTANDING_CAPABILITIES
from .schema_validate import validate_schemas57


REQUIRED_FILES = (
    "reference_summary57.json",
    "understanding_covenant57.json",
    "probes57.json",
    "responses57.json",
    "interpretation_attestations57.json",
    "misunderstanding_topologies57.json",
    "understanding_evidence57.json",
    "understanding_frontiers57.json",
    "baseline_intervention_plan57.json",
    "final_intervention_plan57.json",
    "action_warrant57.json",
    "open_exterior_surface57.json",
    "episode_bundle57.json",
    "episode_receipt57.json",
    "episode_summary57.json",
    "store_verification57.json",
    "diagnostics57.json",
    "frontier_timeline57.jsonl",
    "noesis57.sqlite",
)


def validate_output_dir57(path: str | Path) -> dict[str, Any]:
    root = Path(path)
    checks: list[dict[str, Any]] = []

    def check(name: str, passed: bool, detail: Any = None) -> None:
        checks.append({"name": name, "passed": bool(passed), "detail": detail})

    for name in REQUIRED_FILES:
        check(f"required:{name}", (root / name).is_file())
    if any(not x["passed"] for x in checks):
        return {"status": "FAIL", "passed": sum(x["passed"] for x in checks), "failed": sum(not x["passed"] for x in checks), "checks": checks}

    summary = json.loads((root / "reference_summary57.json").read_text(encoding="utf-8"))
    covenant = json.loads((root / "understanding_covenant57.json").read_text(encoding="utf-8"))
    probes = json.loads((root / "probes57.json").read_text(encoding="utf-8"))
    responses = json.loads((root / "responses57.json").read_text(encoding="utf-8"))
    attestations = json.loads((root / "interpretation_attestations57.json").read_text(encoding="utf-8"))
    topologies = json.loads((root / "misunderstanding_topologies57.json").read_text(encoding="utf-8"))
    evidences = json.loads((root / "understanding_evidence57.json").read_text(encoding="utf-8"))
    frontiers = json.loads((root / "understanding_frontiers57.json").read_text(encoding="utf-8"))
    receipt = json.loads((root / "episode_receipt57.json").read_text(encoding="utf-8"))
    episode_summary = json.loads((root / "episode_summary57.json").read_text(encoding="utf-8"))

    probe_ids = [x["probe_id"] for x in probes]
    response_ids = [x["response_id"] for x in responses]
    evidence_ids = [x["evidence_id"] for x in evidences]
    check("probe ids unique", len(probe_ids) == len(set(probe_ids)))
    check("response ids unique", len(response_ids) == len(set(response_ids)))
    check("evidence ids unique", len(evidence_ids) == len(set(evidence_ids)))
    check("response count binds probe count", len(responses) == len(probes))
    check("attestation count binds response count", len(attestations) == len(responses))
    check("topology count binds response count", len(topologies) == len(responses))
    check("evidence count binds response count", len(evidences) == len(responses))
    check("frontier count binds probe count", len(frontiers) == len(probes))
    check("responses bind known probes", all(x["probe_id"] in probe_ids for x in responses))
    check("evidence binds known responses", all(x["response_id"] in response_ids for x in evidences))
    check("covenant learner veto", covenant["learner_veto"] is True)
    check("covenant finite validity", covenant["valid_until"] > covenant["valid_from"])
    check("summary no global claim", summary["global_understanding_claimed"] is False)
    check("summary no scalar rank", summary["scalar_rank_claimed"] is False)
    check("summary no completion", summary["completion_claimed"] is False)
    check("all evidence no global claim", all(x["global_understanding_claimed"] is False for x in evidences))
    check("all frontiers no scalar rank", all(x["scalar_rank_claimed"] is False for x in frontiers))
    check("all frontiers no completion", all(x["completion_claimed"] is False for x in frontiers))
    check("final frontier covers twelve capabilities", set(frontiers[-1]["capability_states"]) == set(UNDERSTANDING_CAPABILITIES))
    check("final frontier preserves obstruction", bool(frontiers[-1]["active_obstruction_ids"]))
    check("final frontier preserves exterior", bool(frontiers[-1]["protected_exterior_handles"]))
    check("delayed evidence preserves exteriority", evidences[-1]["exteriority_preserved"] is True)
    check("delayed evidence preserves obstruction", evidences[-1]["obstruction_preserved"] is True)
    check("receipt committed", receipt["decision"] == "COMMITTED")
    check("episode summary binds receipt", episode_summary["upstream_receipt_id"] == receipt["receipt_id"])
    check("episode summary hash self-consistent", episode_summary["episode_hash"] == sha256_obj({k: v for k, v in episode_summary.items() if k != "episode_hash"}))

    store = EpistemicEpisodeStore57(root / "noesis57.sqlite")
    store_verification = store.verify()
    check("SQLite store verifies", store_verification["valid"], store_verification)
    check("single atomic event", store_verification["event_count"] == 1)
    check("single atomic receipt", store_verification["receipt_count"] == 1)

    jsonl_lines = [x for x in (root / "frontier_timeline57.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
    parsed = [json.loads(x) for x in jsonl_lines]
    check("frontier timeline has one line per probe", len(parsed) == len(probes))
    check("timeline phase order", [x["probe"]["phase"] for x in parsed] == [x["phase"] for x in probes])

    schema_report = validate_schemas57(root)
    for item in schema_report["checks"]:
        check(f"schema:{item['file']}", item["passed"], item.get("error"))

    passed = sum(1 for x in checks if x["passed"])
    failed = len(checks) - passed
    return {
        "system": "DIKWP-MESH 5.7 NOESIS Ξ",
        "status": "PASS" if failed == 0 else "FAIL",
        "passed": passed,
        "failed": failed,
        "checks": checks,
    }
