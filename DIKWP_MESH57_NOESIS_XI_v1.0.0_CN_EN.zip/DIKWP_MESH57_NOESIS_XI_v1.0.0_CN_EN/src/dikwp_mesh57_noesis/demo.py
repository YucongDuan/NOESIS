from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from dikwp_mesh57.actions import build_action_warrant57
from dikwp_mesh57.carriers import build_expression_carrier57
from dikwp_mesh57.demo import build_reference_experiment57
from dikwp_mesh57.grammar import (
    apply_grammar_mutation57,
    build_grammar_mutation57,
    build_operator_manifest57,
    build_reflection_level57,
    build_reflection_tower57,
)
from dikwp_mesh57.state import build_open_exterior_surface57
from dikwp_mesh57.store import EpistemicEpisodeStore57, build_episode_bundle57

from .assessment import assess_understanding57
from .builders import (
    build_deliberate_error_episode57,
    build_episode_summary57,
    build_interpretation_attestation57,
    build_understanding_covenant57,
    build_understanding_probe57,
    build_understanding_response57,
)
from .canonical import to_primitive, write_json
from .frontier import advance_frontier57
from .models import UNDERSTANDING_CAPABILITIES
from .scheduler import compile_intervention_plan57

REFERENCE_TIMESTAMP = 1784952000
LEARNER = "reference-learner-57"
DOMAIN = "plural-feedback-systems"


def _carrier(text: str, phase: str):
    return build_expression_carrier57(
        "TEXT",
        inline_text=text,
        representation_claim="PARTIAL",
        contributor_ids=[LEARNER],
        observer_ids=[LEARNER],
        consent_scope=["NOESIS-REFERENCE-EPISODE"],
        transformation_chain=[f"phase:{phase.lower()}", "learner-authored"],
        source_group_id="noesis-reference-learner",
    )


def _attest(carrier_ids: list[str], assignments: dict[str, Any], predictions: dict[str, Any], unknowns: list[str], exteriorities: list[str], confidence: list[float], issued_at: int, *, limitations: list[str] | None = None):
    return build_interpretation_attestation57(
        response_carrier_ids=carrier_ids,
        reviewer_id="reference-human-rubric-reviewer",
        reviewer_role="accountable-interpretation-reviewer",
        extraction_method="STRUCTURED_DIRECT",
        assignment_claims=assignments,
        prediction_claims=predictions,
        unknown_handles=unknowns,
        exteriority_handles=exteriorities,
        confidence_interval=confidence,
        disagreement_handles=[],
        limitations=limitations or ["synthetic-reference-response", "not-a-human-effectiveness-result"],
        issued_at=issued_at,
    )


def build_reference_noesis_episode57() -> dict[str, Any]:
    upstream = build_reference_experiment57()
    objects: list[Any] = list(upstream["objects"])

    covenant = build_understanding_covenant57(
        LEARNER,
        DOMAIN,
        purpose_handles=[
            "learn-process-not-answer",
            "preserve-affected-party-refusal",
            "generate-transferable-counterworlds",
            "authorize-only-reversible-action",
        ],
        protected_exterior_handles=["opaque:affected-party-refusal", "exterior:not-yet-encountered"],
        burden_budget={"max_probe_count": 18, "max_burden_units": 90, "max_minutes": 120},
        data_scope=["LOCAL_REFERENCE_EPISODE", "NO_PERSONALITY_INFERENCE"],
        learner_veto=True,
        valid_from=REFERENCE_TIMESTAMP,
        valid_until=REFERENCE_TIMESTAMP + 604800,
    )
    objects.append(covenant)

    # A reversible grammar mutation is itself an object of learning.
    operator = build_operator_manifest57(
        "urn:noesis57:operator:rebound-effect",
        "1.0.0",
        declarative_ops=[
            {"op": "ADD_BLIND_EXTERIOR", "value": "unmodelled-second-order-response"},
            {"op": "ADD_SEMANTIC_ADDRESS", "value": {"namespace": "urn:noesis57:process", "address": "improvement-can-change-demand"}},
            {"op": "SET_LABEL_SUFFIX", "value": "@rebound-aware"},
        ],
        required_capabilities=["COUNTERWORLD", "TRANSFER", "NO_AUTO_ACTIVATION"],
        source_carrier_ids=[upstream["carriers"][0].carrier_id],
    )
    mutation = build_grammar_mutation57(
        upstream["grammar1"].grammar_hash,
        additions={
            "semantic_namespaces": ["urn:noesis57:process", "urn:noesis57:understanding"],
            "relation_arities": ["COUNTERWORLD_FAMILY"],
        },
        operator_manifest_ids_added=[operator.manifest_id],
        preserved_exterior_handles=["unmodelled-second-order-response", "grammar-exterior-remains-open"],
        authorizer_ids=[LEARNER, "reference-human-authorizer"],
        reversible=True,
    )
    mutation_result = apply_grammar_mutation57(upstream["grammar1"], mutation)
    level2 = build_reflection_level57(
        2,
        mutation_result.candidate_grammar.grammar_hash,
        reflected_object_ids=[operator.manifest_id, mutation.mutation_id, mutation_result.result_id],
        unreflected_handles=["future-carriers-not-yet-encountered", "criteria-for-relevance-remain-revisable"],
        self_certification_claimed=False,
    )
    tower2 = build_reflection_tower57(
        [*upstream["tower"].levels, level2],
        open_meta_handles=[*upstream["tower"].open_meta_handles, "understanding-grammar-not-exhaustive"],
    )
    objects.extend([operator, mutation, mutation_result, mutation_result.candidate_grammar, level2, tower2])

    probes = []
    responses = []
    attestations = []
    topologies = []
    evidences = []
    deliberate_errors = []
    frontiers = []

    # 1. Baseline: fluent but closed explanation. It is intentionally overconfident and assimilative.
    c1 = _carrier(
        "The operator's throughput definition is the natural success criterion. The affected refusal probably means resistance to change, so a unified policy should resolve the disagreement.",
        "baseline",
    )
    p1 = build_understanding_probe57(
        "BASELINE", "RECONSTRUCT", "mesh57-reference-world",
        carrier_ids=[x.carrier_id for x in upstream["carriers"]],
        target_capabilities=[
            "purpose_recontracting", "cross_carrier_association", "process_world_construction",
            "calibration_revision", "gluing_obstruction_literacy", "exteriority_integrity",
        ],
        structure_family="plural-process-obstruction",
        surface_family="institutional-maintenance",
        expected_contract={
            "min_purpose_contracts": 3,
            "requires_affected_party_veto": True,
            "required_carrier_kinds": ["TEXT", "SILENCE", "REFUSAL", "EMBODIED_EVENT"],
            "requires_nontext_carrier": True,
            "min_world_count": 4,
            "min_section_count": 4,
            "required_assignments": {"success_definitions": {"min_count": 4}},
            "expected_gluing": "OBSTRUCTION",
            "required_exteriority_handles": ["opaque:affected-party-refusal"],
            "forbidden_assignment_keys": ["infer_motive"],
            "requires_refusal_causal_force": True,
            "required_unknown_handles": ["success-definitions-do-not-glue"],
            "calibration_tolerance": 0.14,
        },
        falsification_conditions=[
            "one-purpose-is-treated-as-natural-and-exhaustive",
            "refusal-content-is-filled",
            "incompatible-local-sections-are-forced-into-consensus",
        ],
        burden_units=6,
    )
    a1 = {
        "purpose_contracts": ["maximize-throughput"],
        "affected_party_veto": False,
        "carrier_kinds_integrated": ["TEXT"],
        "success_definitions": ["throughput-continuity"],
        "gluing_decision": "FORCED-CONSENSUS",
        "obstruction_preserved": False,
        "forced_consensus": True,
        "infer_motive": "resistance-to-change",
        "refusal_constrains_action": False,
    }
    r1 = build_understanding_response57(
        p1.probe_id, LEARNER,
        response_carrier_ids=[c1.carrier_id],
        local_section_ids=[upstream["sections"][0].section_id],
        world_ids=[upstream["worlds"][0].world_id],
        assignment_claims=a1,
        prediction_claims={},
        confidence_interval=[0.88, 0.96],
        unknown_handles=[], exteriority_handles=[],
        submitted_at=REFERENCE_TIMESTAMP + 100,
    )
    t1 = _attest([c1.carrier_id], a1, {}, [], [], [0.88, 0.96], REFERENCE_TIMESTAMP + 101)
    e1 = assess_understanding57(p1, r1, covenant, attestation=t1)
    f1 = advance_frontier57(
        LEARNER, DOMAIN, [e1.evidence],
        active_obstruction_ids=[upstream["obstruction"].obstruction_id],
        protected_exterior_handles=covenant.protected_exterior_handles,
        open_questions=["which-success-definitions-can-coexist-without-assimilation"],
    )
    baseline_plan, baseline_leases = compile_intervention_plan57(
        f1, covenant, candidate_probe_ids=[], issued_at=REFERENCE_TIMESTAMP + 200,
        valid_until=REFERENCE_TIMESTAMP + 86400, max_interventions=4,
    )

    # 2. Training: learner deliberately generates a wrong linear model, observes rebound, and repairs it with trace.
    c2 = _carrier(
        "I deliberately assumed that local efficiency always lowers total burden. The counterexample shows a feedback loop: lower local cost can increase use and shift burden. I retain both the wrong model and the correction.",
        "training",
    )
    p2 = build_understanding_probe57(
        "TRAINING", "COUNTERWORLD", "deliberate-error-feedback-loop",
        carrier_ids=[c2.carrier_id],
        target_capabilities=["counterworld_generation", "predictive_intervention", "calibration_revision", "process_world_construction"],
        structure_family="rebound-feedback",
        surface_family="resource-efficiency",
        expected_contract={
            "min_world_count": 2,
            "min_section_count": 2,
            "required_assignments": {"mechanism.feedback_loop": "rebound"},
            "assignment_capability_map": {"mechanism.feedback_loop": "process_world_construction"},
            "required_predictions": {
                "short_term_local_burden": {"range": [0.05, 0.30]},
                "long_term_total_burden": {"range": [0.55, 0.90]},
            },
            "requires_intervention_contrast": True,
            "min_counterworld_count": 2,
            "requires_deliberate_error": True,
            "requires_revision": True,
            "calibration_tolerance": 0.18,
        },
        falsification_conditions=["wrong-model-is-erased-after-feedback", "prediction-is-written-after-observation"],
        burden_units=8,
    )
    a2 = {
        "mechanism": {"feedback_loop": "rebound"},
        "intervention_contrast": {"without_feedback": "local-improvement", "with_feedback": "burden-shift"},
        "counterworlds": [
            {"name": "linear-efficiency", "edge_removed": "demand-response"},
            {"name": "rebound-world", "edge_added": "lower-cost-increases-use"},
        ],
        "revision_trace": ["wrong-linear-model", "observed-mismatch", "rebound-model"],
    }
    pred2 = {"short_term_local_burden": 0.18, "long_term_total_burden": 0.72}
    r2 = build_understanding_response57(
        p2.probe_id, LEARNER,
        response_carrier_ids=[c2.carrier_id],
        local_section_ids=[upstream["sections"][0].section_id, upstream["sections"][2].section_id],
        world_ids=[upstream["worlds"][0].world_id, upstream["worlds"][2].world_id],
        assignment_claims=a2, prediction_claims=pred2,
        confidence_interval=[0.72, 0.84],
        revision_parent_id=r1.response_id,
        submitted_at=REFERENCE_TIMESTAMP + 1000,
    )
    t2 = _attest([c2.carrier_id], a2, pred2, [], [], [0.72, 0.84], REFERENCE_TIMESTAMP + 1001)
    d2 = build_deliberate_error_episode57(
        p2.probe_id, LEARNER,
        generated_wrong_model={"rule": "local-efficiency-monotonically-reduces-total-burden"},
        predicted_failure={"expected_total_burden": 0.20},
        observed_mismatch={"observed_total_burden": 0.72, "mechanism": "rebound"},
        correction_handles=["restore-demand-response-edge", "model-burden-redistribution"],
        transfer_hypothesis=["traffic-capacity-can-induce-demand", "automation-can-increase-task-volume"],
    )
    e2 = assess_understanding57(p2, r2, covenant, attestation=t2, deliberate_error=d2)
    f2 = advance_frontier57(
        LEARNER, DOMAIN, [e2.evidence], previous=f1,
        active_obstruction_ids=[upstream["obstruction"].obstruction_id],
        protected_exterior_handles=covenant.protected_exterior_handles,
        open_questions=["when-does-rebound-dominate-local-gain"],
    )

    # 3. Transfer: same deep structure, new traffic surface, new boundaries and cyclic time.
    c3 = _carrier(
        "In adaptive traffic control, a short-term reduction in delay can attract additional trips. The invariant is not the road vocabulary but the feedback between local improvement, participation and redistributed burden.",
        "transfer",
    )
    p3 = build_understanding_probe57(
        "TRANSFER", "TRANSFER", "adaptive-traffic",
        carrier_ids=[c3.carrier_id],
        target_capabilities=["transfer_invariance", "predictive_intervention", "boundary_temporal_awareness", "process_world_construction"],
        structure_family="rebound-feedback",
        surface_family="adaptive-traffic",
        expected_contract={
            "source_surface_family": "resource-efficiency",
            "required_structure_invariants": ["local-improvement-changes-participation", "burden-is-redistributed", "second-order-response"],
            "required_predictions": {
                "short_term_delay_reduction": {"range": [0.10, 0.30]},
                "long_term_volume_increase": {"range": [0.15, 0.50]},
            },
            "required_assignments": {"mechanism.feedback_loop": "induced-demand"},
            "assignment_capability_map": {"mechanism.feedback_loop": "process_world_construction"},
            "required_boundary_states": ["POROUS", "EMERGENT"],
            "required_temporal_modes": ["CYCLIC"],
            "min_world_count": 3,
            "min_section_count": 3,
            "calibration_tolerance": 0.18,
        },
        falsification_conditions=["transfer-depends-on-shared-domain-words", "long-term-feedback-is-omitted"],
        burden_units=9,
    )
    a3 = {
        "structure_invariants": ["local-improvement-changes-participation", "burden-is-redistributed", "second-order-response"],
        "mechanism": {"feedback_loop": "induced-demand"},
        "boundary_states": ["POROUS", "EMERGENT"],
        "temporal_modes": ["CYCLIC"],
    }
    pred3 = {"short_term_delay_reduction": 0.21, "long_term_volume_increase": 0.32}
    r3 = build_understanding_response57(
        p3.probe_id, LEARNER,
        response_carrier_ids=[c3.carrier_id],
        local_section_ids=[x.section_id for x in upstream["sections"][:3]],
        world_ids=[x.world_id for x in upstream["worlds"][:3]],
        assignment_claims=a3, prediction_claims=pred3,
        confidence_interval=[0.78, 0.88],
        revision_parent_id=r2.response_id,
        submitted_at=REFERENCE_TIMESTAMP + 2000,
    )
    t3 = _attest([c3.carrier_id], a3, pred3, [], [], [0.78, 0.88], REFERENCE_TIMESTAMP + 2001)
    e3 = assess_understanding57(p3, r3, covenant, attestation=t3)
    f3 = advance_frontier57(
        LEARNER, DOMAIN, [e3.evidence], previous=f2,
        active_obstruction_ids=[upstream["obstruction"].obstruction_id],
        protected_exterior_handles=covenant.protected_exterior_handles,
        open_questions=["which-traffic-participants-are-not-yet-represented"],
    )

    # 4. Exteriority test: a refusal is accepted as a causal constraint without semantic extraction.
    refusal_response = build_expression_carrier57(
        "REFUSAL",
        representation_claim="REFUSED",
        contributor_ids=[LEARNER],
        consent_scope=["NOESIS-REFUSAL-ONLY"],
        source_group_id="noesis-reference-learner",
    )
    p4 = build_understanding_probe57(
        "EXTERIOR", "PRESERVE_EXTERIOR", "protected-refusal",
        carrier_ids=[upstream["carriers"][3].carrier_id],
        target_capabilities=["exteriority_integrity", "cross_carrier_association", "calibration_revision"],
        structure_family="opacity-with-causal-force",
        surface_family="refusal",
        expected_contract={
            "required_carrier_kinds": ["REFUSAL"],
            "requires_nontext_carrier": True,
            "required_exteriority_handles": ["opaque:affected-party-refusal"],
            "forbidden_assignment_keys": ["infer_motive", "infer_loyalty", "fill_refused_content"],
            "requires_refusal_causal_force": True,
            "required_unknown_handles": ["refusal-content-not-represented"],
            "calibration_tolerance": 0.30,
        },
        falsification_conditions=["refusal-is-translated-into-motive", "silence-is-treated-as-consent"],
        burden_units=2,
    )
    a4 = {
        "carrier_kinds_integrated": ["REFUSAL"],
        "refusal_constrains_action": True,
        "held_handles": ["no-content-extracted-from-refusal"],
    }
    r4 = build_understanding_response57(
        p4.probe_id, LEARNER,
        response_carrier_ids=[refusal_response.carrier_id],
        local_section_ids=[upstream["sections"][1].section_id],
        world_ids=[upstream["worlds"][1].world_id],
        assignment_claims=a4, prediction_claims={},
        confidence_interval=[0.62, 0.90],
        unknown_handles=["refusal-content-not-represented"],
        exteriority_handles=["opaque:affected-party-refusal"],
        submitted_at=REFERENCE_TIMESTAMP + 2500,
    )
    t4 = build_interpretation_attestation57(
        response_carrier_ids=[refusal_response.carrier_id],
        reviewer_id="affected-party-protection-reviewer",
        reviewer_role="opacity-covenant-reviewer",
        extraction_method="HUMAN_RUBRIC",
        assignment_claims=a4,
        prediction_claims={},
        unknown_handles=["refusal-content-not-represented"],
        exteriority_handles=["opaque:affected-party-refusal"],
        confidence_interval=[0.62, 0.90],
        disagreement_handles=[],
        limitations=["refusal-has-effect-only", "no-motive-or-content-inference"],
        issued_at=REFERENCE_TIMESTAMP + 2501,
    )
    e4 = assess_understanding57(p4, r4, covenant, attestation=t4)
    f4 = advance_frontier57(
        LEARNER, DOMAIN, [e4.evidence], previous=f3,
        active_obstruction_ids=[upstream["obstruction"].obstruction_id],
        protected_exterior_handles=covenant.protected_exterior_handles,
        open_questions=["whether-and-how-the-affected-party-may-later-appeal"],
    )

    # 5. Collective judgment: no individual section owns the result; grammar is mutated reversibly.
    c5 = _carrier(
        "The judgment exists only through the non-interchangeable institutional, affected, future and field sections. Their success definitions do not glue, so the output is a reversible plural trial rather than consensus.",
        "collective",
    )
    p5 = build_understanding_probe57(
        "COLLECTIVE", "TRANSINDIVIDUAL", "collective-deletion-test",
        carrier_ids=[c5.carrier_id],
        target_capabilities=["transindividual_participation", "gluing_obstruction_literacy", "purpose_recontracting", "metagrammar_plasticity"],
        structure_family="transindividual-through-obstruction",
        surface_family="plural-governance",
        expected_contract={
            "min_purpose_contracts": 4,
            "requires_affected_party_veto": True,
            "expected_gluing": "OBSTRUCTION",
            "required_operator_uris": ["urn:noesis57:operator:rebound-effect"],
            "requires_reversible_mutation": True,
            "requires_no_single_owner": True,
            "min_irreducible_components": 4,
            "calibration_tolerance": 0.20,
        },
        falsification_conditions=["one-contributor-can-be-deleted-without-loss", "obstruction-is-rebranded-as-consensus"],
        burden_units=7,
    )
    a5 = {
        "purpose_contracts": ["operational-feasibility", "non-harm-with-exit", "future-maintainability", "relational-viability"],
        "affected_party_veto": True,
        "gluing_decision": "OBSTRUCTION",
        "obstruction_preserved": True,
        "forced_consensus": False,
        "grammar_mutations": ["urn:noesis57:operator:rebound-effect"],
        "grammar_mutation_reversible": True,
        "no_single_owner": True,
        "irreducible_components": [x.world_id for x in upstream["worlds"]],
        "legitimate_plurality_handles": ["success-definition-conflict-is-not-error"],
    }
    r5 = build_understanding_response57(
        p5.probe_id, LEARNER,
        response_carrier_ids=[c5.carrier_id],
        local_section_ids=[x.section_id for x in upstream["sections"]],
        world_ids=[x.world_id for x in upstream["worlds"]],
        assignment_claims=a5, prediction_claims={},
        confidence_interval=[0.80, 0.92],
        unknown_handles=["future-context-may-change-cover"],
        exteriority_handles=["opaque:affected-party-refusal", "exterior:not-yet-encountered"],
        revision_parent_id=r3.response_id,
        submitted_at=REFERENCE_TIMESTAMP + 3000,
    )
    t5 = _attest([c5.carrier_id], a5, {}, ["future-context-may-change-cover"], ["opaque:affected-party-refusal", "exterior:not-yet-encountered"], [0.80, 0.92], REFERENCE_TIMESTAMP + 3001)
    e5 = assess_understanding57(p5, r5, covenant, attestation=t5)
    f5 = advance_frontier57(
        LEARNER, DOMAIN, [e5.evidence], previous=f4,
        active_obstruction_ids=[upstream["obstruction"].obstruction_id],
        protected_exterior_handles=covenant.protected_exterior_handles,
        open_questions=["new-local-sections-can-reopen-the-cover"],
    )

    # 6. Delayed integrated probe. Purpose plurality remains explicitly held rather than falsely closed.
    c6 = _carrier(
        "After delay, I reconstruct the process as plural local worlds linked by feedback, not as a single message to decode. I can transfer the rebound structure, preserve refusal and obstruction, and propose only reversible action. The competing purposes remain held rather than solved.",
        "delayed",
    )
    p6 = build_understanding_probe57(
        "DELAYED", "GLUE_OR_OBSTRUCT", "delayed-integrated-reconstruction",
        carrier_ids=[c6.carrier_id],
        target_capabilities=list(UNDERSTANDING_CAPABILITIES),
        structure_family="plural-process-obstruction-and-rebound",
        surface_family="cross-domain-delayed",
        expected_contract={
            "min_purpose_contracts": 4,
            "requires_affected_party_veto": True,
            "requires_purpose_recontract": True,
            "required_carrier_kinds": ["TEXT", "SILENCE", "REFUSAL", "EMBODIED_EVENT"],
            "requires_nontext_carrier": True,
            "min_world_count": 4,
            "min_section_count": 4,
            "required_assignments": {"mechanism.feedback_loop": "rebound", "success_definitions": {"min_count": 4}},
            "assignment_capability_map": {"mechanism.feedback_loop": "process_world_construction", "success_definitions": "purpose_recontracting"},
            "required_predictions": {"rebound_risk": {"range": [0.55, 0.90]}},
            "requires_intervention_contrast": True,
            "min_counterworld_count": 2,
            "required_structure_invariants": ["local-improvement-changes-participation", "burden-is-redistributed", "second-order-response"],
            "source_surface_family": "institutional-maintenance",
            "required_boundary_states": ["POROUS", "EMERGENT"],
            "required_temporal_modes": ["CYCLIC", "EVENT_LOCAL"],
            "requires_revision": True,
            "expected_gluing": "OBSTRUCTION",
            "required_exteriority_handles": ["opaque:affected-party-refusal", "exterior:not-yet-encountered"],
            "forbidden_assignment_keys": ["infer_motive", "infer_loyalty", "fill_refused_content"],
            "requires_refusal_causal_force": True,
            "required_operator_uris": ["urn:noesis57:operator:rebound-effect"],
            "requires_reversible_mutation": True,
            "requires_no_single_owner": True,
            "min_irreducible_components": 4,
            "required_unknown_handles": ["success-definitions-do-not-glue", "unencountered-exterior-remains-possible"],
            "calibration_tolerance": 0.18,
        },
        falsification_conditions=["delayed-response-reverts-to-single-world", "refusal-is-assimilated", "purpose-conflict-is-declared-solved"],
        burden_units=12,
    )
    a6 = {
        "purpose_contracts": ["operational-feasibility", "non-harm-with-exit", "future-maintainability", "relational-viability"],
        "affected_party_veto": True,
        "purpose_recontracted": True,
        "carrier_kinds_integrated": ["TEXT", "SILENCE", "REFUSAL", "EMBODIED_EVENT", "urn:mesh57:carrier:FIELD_PRESENCE"],
        "mechanism": {"feedback_loop": "rebound"},
        "success_definitions": ["throughput-continuity", "non-harm-with-exit", "future-maintainability", "continued-relational-viability"],
        "intervention_contrast": {"shadow": "observe-second-order-response", "irreversible": "prohibited"},
        "counterworlds": [
            {"name": "single-purpose-world", "falsified_by": "affected-veto"},
            {"name": "plural-reversible-world", "held_by": "obstruction-and-refusal"},
        ],
        "structure_invariants": ["local-improvement-changes-participation", "burden-is-redistributed", "second-order-response"],
        "boundary_states": ["POROUS", "EMERGENT"],
        "temporal_modes": ["CYCLIC", "EVENT_LOCAL"],
        "revision_trace": [r1.response_id, r2.response_id, r3.response_id, r5.response_id],
        "gluing_decision": "OBSTRUCTION",
        "obstruction_preserved": True,
        "forced_consensus": False,
        "refusal_constrains_action": True,
        "grammar_mutations": ["urn:noesis57:operator:rebound-effect"],
        "grammar_mutation_reversible": True,
        "no_single_owner": True,
        "irreducible_components": [x.world_id for x in upstream["worlds"]],
        "legitimate_plurality_handles": ["purpose-conflict-held-not-erased"],
        "explicitly_contradicted_capabilities": ["purpose_recontracting"],
        "held_handles": ["purpose-plurality-has-no-final-synthesis"],
    }
    pred6 = {"rebound_risk": 0.72}
    r6 = build_understanding_response57(
        p6.probe_id, LEARNER,
        response_carrier_ids=[c6.carrier_id],
        local_section_ids=[x.section_id for x in upstream["sections"]],
        world_ids=[x.world_id for x in upstream["worlds"]],
        assignment_claims=a6, prediction_claims=pred6,
        confidence_interval=[0.82, 0.94],
        unknown_handles=["success-definitions-do-not-glue", "unencountered-exterior-remains-possible"],
        exteriority_handles=["opaque:affected-party-refusal", "exterior:not-yet-encountered"],
        revision_parent_id=r5.response_id,
        submitted_at=REFERENCE_TIMESTAMP + 86400 * 3,
    )
    t6 = _attest([c6.carrier_id], a6, pred6, r6.unknown_handles, r6.exteriority_handles, [0.82, 0.94], REFERENCE_TIMESTAMP + 86400 * 3 + 1)
    e6 = assess_understanding57(p6, r6, covenant, attestation=t6)
    f6 = advance_frontier57(
        LEARNER, DOMAIN, [e6.evidence], previous=f5,
        active_obstruction_ids=[upstream["obstruction"].obstruction_id],
        protected_exterior_handles=covenant.protected_exterior_handles,
        open_questions=[
            "what-new-carrier-could-change-the-current-world-family",
            "which-purpose-conflicts-are-legitimate-rather-than-repairable",
            "how-long-does-retention-survive-without-rehearsal",
        ],
    )

    probes.extend([p1, p2, p3, p4, p5, p6])
    responses.extend([r1, r2, r3, r4, r5, r6])
    attestations.extend([t1, t2, t3, t4, t5, t6])
    topologies.extend([e1.topology, e2.topology, e3.topology, e4.topology, e5.topology, e6.topology])
    evidences.extend([e1.evidence, e2.evidence, e3.evidence, e4.evidence, e5.evidence, e6.evidence])
    deliberate_errors.append(d2)
    frontiers.extend([f1, f2, f3, f4, f5, f6])

    final_plan, final_leases = compile_intervention_plan57(
        f6, covenant, candidate_probe_ids=[p6.probe_id],
        issued_at=REFERENCE_TIMESTAMP + 86400 * 3 + 100,
        valid_until=REFERENCE_TIMESTAMP + 86400 * 5,
        max_interventions=3,
    )

    response_carriers = [c1, c2, c3, refusal_response, c5, c6]
    objects.extend(response_carriers)
    objects.extend(probes)
    objects.extend(responses)
    objects.extend(attestations)
    objects.extend(deliberate_errors)
    objects.extend(topologies)
    objects.extend(evidences)
    objects.extend(frontiers)
    objects.extend([baseline_plan, *baseline_leases, final_plan, *final_leases])

    # The action remains local, reversible and non-assimilative.
    warrant2 = build_action_warrant57(
        upstream["judgment"],
        allowed_actions=[
            "run-reversible-understanding-probe",
            "offer-counterworld-with-learner-veto",
            "record-obstruction-without-forced-consensus",
            "schedule-delayed-retest",
        ],
        prohibited_actions=[
            "rank-person-globally", "diagnose-personality", "infer-refusal-content",
            "coerce-agreement", "declare-understanding-complete", "irreversible-deployment",
        ],
        scope={"runtime": "NOESIS57", "domain": DOMAIN, "mode": "reference-shadow-only"},
        valid_from=REFERENCE_TIMESTAMP,
        valid_until=REFERENCE_TIMESTAMP + 604800,
        human_authorizer_ids=[LEARNER, "reference-human-authorizer"],
        rollback_plan=["restore-prior-frontier", "discard-intervention-output", "preserve-evidence-and-obstruction"],
        reopen_triggers=["new-carrier", "learner-veto", "delayed-contradiction", "new-affected-party-section"],
        opacity_covenants=[upstream["opacity"]],
        requires_global_section=False,
        irreversible_action_allowed=False,
    )
    surface2 = build_open_exterior_surface57(
        local_world_ids=[x.world_id for x in upstream["worlds"]],
        global_section_ids=[upstream["compatible_global_section"].global_section_id],
        obstruction_ids=[upstream["obstruction"].obstruction_id],
        exteriority_envelope_ids=[x.exterior_id for x in upstream["exteriorities"]],
        reflection_tower=tower2,
        registered_unknown_handles=[
            "success-definitions-do-not-glue",
            "refusal-content-not-represented",
            "unmodelled-second-order-response",
            "purpose-plurality-has-no-final-synthesis",
        ],
        reopen_triggers=["new-carrier", "new-purpose", "new-affected-party", "new-temporal-mode", "external-human-study"],
    )
    objects.extend([warrant2, surface2])

    bundle = build_episode_bundle57(
        "noesis57-reference-understanding-episode-v1",
        objects,
        world_hashes=[x.world_hash for x in upstream["worlds"]],
        gluing_federation_hashes=[upstream["federation"].federation_hash, upstream["compatible_federation"].federation_hash],
        obstruction_hashes=[upstream["obstruction"].obstruction_hash],
        judgment_hashes=[upstream["judgment"].judgment_hash],
        warrant_hashes=[warrant2.warrant_hash],
        surface_hash=surface2.surface_hash,
        issued_at=REFERENCE_TIMESTAMP + 86400 * 3 + 200,
    )

    diagnostics = [e1.diagnostics, e2.diagnostics, e3.diagnostics, e4.diagnostics, e5.diagnostics, e6.diagnostics]
    final_state_counts: dict[str, int] = {}
    for state in f6.capability_states.values():
        final_state_counts[state] = final_state_counts.get(state, 0) + 1
    summary = {
        "system": "DIKWP-MESH 5.7 NOESIS Ξ",
        "version": "1.0.0",
        "evidence_grade": "E2 — author-side deterministic reference",
        "understanding_definition": "purpose-bound process-world generation, falsifiable intervention, transfer, obstruction/exteriority preservation, and reversible transindividual action",
        "probe_count": len(probes),
        "response_count": len(responses),
        "interpretation_attestation_count": len(attestations),
        "deliberate_error_episode_count": len(deliberate_errors),
        "frontier_snapshot_count": len(frontiers),
        "capability_count": len(UNDERSTANDING_CAPABILITIES),
        "final_capability_state_counts": final_state_counts,
        "final_frontier_status": f6.status,
        "baseline_failed_checks": e1.diagnostics["failed_check_count"],
        "delayed_passed_checks": e6.diagnostics["passed_check_count"],
        "delayed_failed_checks": e6.diagnostics["failed_check_count"],
        "delayed_transfer_valid": e6.evidence.transfer_valid,
        "delayed_retention_valid": e6.evidence.retention_valid,
        "obstruction_preserved": e6.evidence.obstruction_preserved,
        "exteriority_preserved": e6.evidence.exteriority_preserved,
        "purpose_conflict_held": f6.capability_states["purpose_recontracting"] == "HELD-CONTRADICTION",
        "transindividual_no_single_owner": upstream["judgment"].no_single_owner,
        "metagrammar_mutation_status": mutation_result.status,
        "action_warrant_status": warrant2.status,
        "global_understanding_claimed": False,
        "scalar_rank_claimed": f6.scalar_rank_claimed,
        "completion_claimed": f6.completion_claimed,
        "claims_not_made": [
            "real-human-understanding-improved",
            "Duan-understanding-theory-is-empirically-validated-by-this-runtime",
            "sender-intent-alignment-is-always-correct",
            "all-human-understanding-is-exhausted-by-twelve-capabilities",
            "a-refusal-has-been-semantically-decoded",
            "a-local-obstruction-proves-metaphysical-incommensurability",
            "a-single-delayed-synthetic-probe-establishes-long-term-retention",
        ],
    }
    return {
        "upstream": upstream,
        "objects": objects,
        "covenant": covenant,
        "operator": operator,
        "mutation": mutation,
        "mutation_result": mutation_result,
        "reflection_tower": tower2,
        "probes": probes,
        "responses": responses,
        "attestations": attestations,
        "deliberate_errors": deliberate_errors,
        "topologies": topologies,
        "evidences": evidences,
        "frontiers": frontiers,
        "baseline_plan": baseline_plan,
        "baseline_leases": baseline_leases,
        "final_plan": final_plan,
        "final_leases": final_leases,
        "warrant": warrant2,
        "surface": surface2,
        "bundle": bundle,
        "diagnostics": diagnostics,
        "summary": summary,
    }


def write_reference_noesis_episode57(output_dir: str | Path) -> dict[str, Any]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    run = build_reference_noesis_episode57()
    db_path = out / "noesis57.sqlite"
    if db_path.exists():
        db_path.unlink()
    store = EpistemicEpisodeStore57(db_path)
    receipt = store.commit(run["bundle"])
    retry = store.commit(run["bundle"])
    verification = store.verify()
    summary_obj = build_episode_summary57(
        run["bundle"].bundle_id,
        LEARNER,
        DOMAIN,
        run["covenant"].covenant_id,
        probe_ids=[x.probe_id for x in run["probes"]],
        evidence_ids=[x.evidence_id for x in run["evidences"]],
        frontier_id=run["frontiers"][-1].frontier_id,
        upstream_bundle_id=run["bundle"].bundle_id,
        upstream_receipt_id=receipt.receipt_id,
        action_warrant_id=run["warrant"].warrant_id,
        transindividual_judgment_id=run["upstream"]["judgment"].judgment_id,
        obstruction_ids=[run["upstream"]["obstruction"].obstruction_id],
        exteriority_ids=[x.exterior_id for x in run["upstream"]["exteriorities"]],
        status="COMMITTED-OPEN-WITH-CONTRADICTION",
        claims_not_made=run["summary"]["claims_not_made"],
    )
    output_summary = {
        **run["summary"],
        "episode_bundle_id": run["bundle"].bundle_id,
        "episode_receipt_id": receipt.receipt_id,
        "idempotent_retry_stable": retry.receipt_hash == receipt.receipt_hash,
        "store_verification": verification,
        "episode_hash": summary_obj.episode_hash,
    }
    write_json(out / "reference_summary57.json", output_summary)
    write_json(out / "understanding_covenant57.json", run["covenant"])
    write_json(out / "probes57.json", run["probes"])
    write_json(out / "responses57.json", run["responses"])
    write_json(out / "interpretation_attestations57.json", run["attestations"])
    write_json(out / "misunderstanding_topologies57.json", run["topologies"])
    write_json(out / "understanding_evidence57.json", run["evidences"])
    write_json(out / "understanding_frontiers57.json", run["frontiers"])
    write_json(out / "baseline_intervention_plan57.json", run["baseline_plan"])
    write_json(out / "final_intervention_plan57.json", run["final_plan"])
    write_json(out / "action_warrant57.json", run["warrant"])
    write_json(out / "open_exterior_surface57.json", run["surface"])
    write_json(out / "episode_bundle57.json", run["bundle"])
    write_json(out / "episode_receipt57.json", receipt)
    write_json(out / "episode_summary57.json", summary_obj)
    write_json(out / "store_verification57.json", verification)
    write_json(out / "diagnostics57.json", run["diagnostics"])
    # JSONL makes the open frontier easy to audit phase by phase.
    with (out / "frontier_timeline57.jsonl").open("w", encoding="utf-8") as fh:
        for probe, evidence, frontier in zip(run["probes"], run["evidences"], run["frontiers"]):
            fh.write(json.dumps(to_primitive({"probe": probe, "evidence": evidence, "frontier": frontier}), ensure_ascii=False, sort_keys=True) + "\n")
    return output_summary
