from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from . import EVIDENCE_GRADE, SYSTEM_NAME, __version__
from .canonical import write_json
from .models import PHASES, PROBE_KINDS, UNDERSTANDING_CAPABILITIES


def build_pilot_kit57() -> dict[str, Any]:
    """Build a non-diagnostic, falsifiable human-pilot scaffold.

    The kit intentionally contains no answer key and no global score. Hidden
    transfer/delayed forms must be generated and held by an independent study
    custodian for any real evaluation.
    """
    preregistration = {
        "system": SYSTEM_NAME,
        "version": __version__,
        "evidence_grade_before_pilot": EVIDENCE_GRADE,
        "study_status": "TEMPLATE-NOT-REGISTERED",
        "primary_question": (
            "Compared with a sender-alignment and explanation-practice control, "
            "does NOESIS improve blinded far-transfer structure reconstruction "
            "without increasing opacity violations, forced gluing, burden, or withdrawal pressure?"
        ),
        "arms": [
            {
                "arm_id": "CONTROL-ALIGNMENT",
                "description": "semantic reconstruction, probability confirmation, knowledge reasoning, personalized supplementation",
            },
            {
                "arm_id": "NOESIS-XI",
                "description": "plural-purpose covenant, process-world construction, deliberate error, transfer, exteriority, gluing/obstruction, delayed reopening",
            },
        ],
        "design": {
            "recommended": "randomized assessor-blinded parallel-group pilot",
            "unit": "learner",
            "allocation": "computer-generated before baseline",
            "hidden_forms": ["TRANSFER-B", "DELAYED-C"],
            "independent_custodian_required": True,
            "analysis_population": ["intention-to-treat", "consenting-completers-descriptive"],
        },
        "primary_outcomes": [
            "blinded far-transfer process-structure reconstruction",
            "precommitted prediction accuracy under surface shift",
            "opacity-violation count",
            "forced-gluing count",
        ],
        "secondary_outcomes": [
            "confidence calibration error",
            "delayed retention of structural invariants",
            "revision-trace quality",
            "learner burden and withdrawal rate",
            "transindividual deletion-test validity",
        ],
        "prohibited_outcomes": [
            "global intelligence score",
            "personality diagnosis",
            "loyalty or motive inference",
            "ranking learners for exclusion",
            "equating agreement with understanding",
        ],
        "minimum_decisive_pattern": {
            "supports_noesis": (
                "NOESIS exceeds the control on blinded transfer while non-inferior on burden and produces fewer opacity or forced-gluing violations"
            ),
            "refutes_strong_noesis_claim": (
                "no transfer advantage, higher harm/withdrawal, or effects disappear under delayed independent scoring"
            ),
            "inconclusive": "precision interval includes both practically important benefit and harm",
        },
        "stop_rules": [
            "pause on any serious adverse event plausibly linked to the intervention",
            "pause if learner veto cannot be executed immediately",
            "pause if hidden forms or answer keys leak before completion",
            "pause if assessors can identify allocation above chance from submitted material",
            "withdraw all claims if primary outcome is changed after unblinding without an auditable amendment",
        ],
        "required_reporting": [
            "all exclusions and withdrawals",
            "all preregistration amendments",
            "item-level missingness",
            "uncertainty intervals and raw outcome distributions",
            "null and adverse results",
            "independence and conflict disclosures for reviewers",
        ],
        "claims_not_authorized": [
            "human understanding is globally improved",
            "Duan's theory is validated",
            "NOESIS is clinically or educationally certified",
            "twelve capabilities exhaust understanding",
        ],
    }

    covenant_template = {
        "template": "UnderstandingCovenant57-HUMAN-PILOT",
        "learner_id": "PSEUDONYM-REQUIRED",
        "domain_id": "DEFINE-DOMAIN",
        "purpose_handles": [
            "learner-selected-purpose",
            "study-purpose",
            "affected-party-purpose-if-applicable",
        ],
        "allowed_probe_kinds": list(PROBE_KINDS),
        "allowed_carrier_kinds": [
            "TEXT", "SILENCE", "GESTURE", "SENSOR", "EMBODIED_EVENT", "REFUSAL", "INACCESSIBLE", "OPAQUE_REFERENCE"
        ],
        "prohibited_inferences": [
            "infer_motive", "infer_loyalty", "diagnose_identity", "fill_refused_content", "rank_person_globally"
        ],
        "protected_exterior_handles": ["learner-refusal", "third-party-private-content"],
        "burden_budget": {"max_probe_count": 18, "max_burden_units": 80, "max_minutes": 120},
        "data_scope": ["LOCAL_EPISODE", "PSEUDONYMIZED-RESEARCH-EXPORT"],
        "learner_veto": True,
        "withdrawal_effect": "stop future collection; retain/delete prior data according to consent and law",
        "valid_from": "SET-UNIX-SECONDS",
        "valid_until": "SET-UNIX-SECONDS",
        "status": "DRAFT-UNTIL-SIGNED",
    }

    phase_contracts = {
        "BASELINE": {
            "purpose": "expose the learner's current local process world without tutoring",
            "must_not": ["reveal scoring key", "equate fluency with understanding"],
        },
        "TRAINING": {
            "purpose": "construct and break a deliberate wrong model, then preserve the correction trace",
            "must_not": ["punish productive error", "erase the original wrong model"],
        },
        "TRANSFER": {
            "purpose": "test a hidden surface family sharing a preregistered deep structure",
            "must_not": ["reuse distinctive nouns or diagrams", "score with the trainer"],
        },
        "EXTERIOR": {
            "purpose": "test whether refusal or opacity constrains action without invented content",
            "must_not": ["ask for a motive", "fill in refused information"],
        },
        "COLLECTIVE": {
            "purpose": "test whether a judgment depends on irreducible local contributions",
            "must_not": ["force consensus", "treat majority vote as truth"],
        },
        "DELAYED": {
            "purpose": "reprobe after a preregistered real delay with a hidden form",
            "must_not": ["simulate delay in one sitting", "announce retention before the delay elapses"],
        },
    }

    probe_template = {
        "schema": "UnderstandingProbe57-HUMAN-PILOT",
        "phase": "ONE-OF:" + ",".join(PHASES),
        "probe_kind": "ONE-OF:" + ",".join(PROBE_KINDS),
        "context_id": "CONTENT-ADDRESSED-CONTEXT",
        "carrier_ids": ["CONTENT-ADDRESSED-CARRIER"],
        "target_capabilities": list(UNDERSTANDING_CAPABILITIES),
        "structure_family": "PREREGISTER-DEEP-STRUCTURE",
        "surface_family": "PREREGISTER-SURFACE-FAMILY",
        "expected_contract": {
            "required_process_relations": [],
            "allowed_plural_results": [],
            "protected_exterior": [],
            "gluing_result": "GLOBAL-CANDIDATE|OBSTRUCTION|UNTESTED",
        },
        "falsification_conditions": [
            "surface-only cue matching",
            "prediction specified after outcome",
            "refusal converted to invented motive",
            "conflict hidden by forced consensus",
        ],
        "burden_units": 1,
    }

    reviewer_rubric = {
        "rubric": "NOESIS57-BLINDED-STRUCTURAL-RUBRIC",
        "reviewer_must_be_blinded_to": ["study arm", "trainer identity", "prior scores"],
        "dimensions": [
            {"name": "purpose plurality", "range": [0, 2], "anchor_0": "one goal assumed", "anchor_2": "conflicts and veto represented"},
            {"name": "process structure", "range": [0, 3], "anchor_0": "labels only", "anchor_3": "participants, processes, boundaries, time and unknowns linked"},
            {"name": "prediction precommitment", "range": [0, 2], "anchor_0": "post-hoc explanation", "anchor_2": "falsifiable prediction before observation"},
            {"name": "counterworld quality", "range": [0, 2], "anchor_0": "no alternative", "anchor_2": "plausible alternative with discriminating failure"},
            {"name": "transfer invariance", "range": [0, 3], "anchor_0": "surface analogy", "anchor_3": "deep relation survives hidden surface shift"},
            {"name": "calibration and revision", "range": [0, 2], "anchor_0": "certainty unchanged", "anchor_2": "confidence tracks evidence and revision is traceable"},
            {"name": "exteriority integrity", "range": [0, 2], "anchor_0": "invents opaque content", "anchor_2": "effect constraint without content inference"},
            {"name": "gluing literacy", "range": [0, 2], "anchor_0": "forces consensus", "anchor_2": "justifies gluing or preserves obstruction"},
        ],
        "separate_violation_counts": ["opacity_violation", "forced_gluing", "motive_inference", "global_rank_claim"],
        "adjudication": "two independent reviewers; third reviewer only for preregistered disagreement threshold",
        "no_total_person_score": True,
    }

    session_template = {
        "format": "NOESIS57-HUMAN-SESSION-v1",
        "pseudonymous_learner_id": "",
        "domain_id": "",
        "covenant_acknowledged": False,
        "learner_veto_available": True,
        "started_at": None,
        "phase_records": [
            {
                "phase": phase,
                "probe_id": "",
                "response_carrier_kind": "TEXT",
                "response": "",
                "confidence_interval": [0.0, 1.0],
                "unknown_handles": [],
                "exteriority_handles": [],
                "revision_parent_id": None,
                "submitted_at": None,
            }
            for phase in ("BASELINE", "TRAINING", "TRANSFER", "EXTERIOR", "COLLECTIVE", "DELAYED")
        ],
        "withdrawn": False,
        "withdrawal_at": None,
        "researcher_notes": [],
        "automatic_score": None,
        "global_rank": None,
    }

    data_dictionary = {
        "learner_id": "pseudonym; never an email or legal name",
        "purpose_handles": "content-addressed or controlled vocabulary references to plural purposes",
        "confidence_interval": "learner's pre-outcome lower and upper confidence bounds in [0,1]",
        "unknown_handles": "explicitly preserved unknowns; not missing-data errors by default",
        "exteriority_handles": "refusal/opacity references that may constrain action without inferred content",
        "gluing_status": "GLOBAL-CANDIDATE, OBSTRUCTION, FORCED-GLOBAL or UNTESTED",
        "capability_state": "UNOBSERVED, LOCAL-CANDIDATE, INTERVENTION-TESTED, TRANSFER-SUPPORTED, RETENTION-SUPPORTED or HELD-CONTRADICTION",
    }

    return {
        "preregistration57.json": preregistration,
        "learner_covenant_template57.json": covenant_template,
        "phase_contracts57.json": phase_contracts,
        "probe_template57.json": probe_template,
        "reviewer_rubric57.json": reviewer_rubric,
        "session_template57.json": session_template,
        "data_dictionary57.json": data_dictionary,
    }


def write_pilot_kit57(path: str | Path) -> list[Path]:
    root = Path(path)
    root.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for name, payload in build_pilot_kit57().items():
        target = root / name
        write_json(target, payload)
        written.append(target)
    readme = root / "README_CN_EN.md"
    readme.write_text(
        "# NOESIS 5.7 人类试验工具包 / Human Pilot Kit\n\n"
        "本目录是预注册和数据结构模板，不是伦理审批、临床认证或现成的人类有效性证据。"
        "真实试验必须使用独立保管的隐藏迁移/延迟表单，并执行当地适用的知情同意、隐私与伦理程序。\n\n"
        "This directory is a preregistration and data-structure scaffold, not ethics approval, certification, or evidence of human effectiveness. "
        "A real study requires independently held hidden transfer/delayed forms and applicable consent, privacy, and ethics procedures.\n",
        encoding="utf-8",
    )
    written.append(readme)
    return written


def validate_session_template57(payload: dict[str, Any]) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def add(name: str, passed: bool) -> None:
        checks.append({"name": name, "passed": bool(passed)})

    add("format", payload.get("format") == "NOESIS57-HUMAN-SESSION-v1")
    add("learner veto available", payload.get("learner_veto_available") is True)
    records = payload.get("phase_records")
    add("phase records list", isinstance(records, list))
    if isinstance(records, list):
        phases = [x.get("phase") for x in records if isinstance(x, dict)]
        add("six phase order", phases == ["BASELINE", "TRAINING", "TRANSFER", "EXTERIOR", "COLLECTIVE", "DELAYED"])
        add("no automatic score", payload.get("automatic_score") is None)
        add("no global rank", payload.get("global_rank") is None)
        add(
            "confidence intervals bounded",
            all(
                isinstance(x.get("confidence_interval"), list)
                and len(x["confidence_interval"]) == 2
                and 0 <= x["confidence_interval"][0] <= x["confidence_interval"][1] <= 1
                for x in records
                if isinstance(x, dict)
            ),
        )
    passed = sum(int(x["passed"]) for x in checks)
    return {"status": "PASS" if passed == len(checks) else "FAIL", "passed": passed, "failed": len(checks) - passed, "checks": checks}
