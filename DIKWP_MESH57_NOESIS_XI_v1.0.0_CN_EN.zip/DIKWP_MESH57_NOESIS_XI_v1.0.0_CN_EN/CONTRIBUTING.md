# Contributing

Contributions must preserve the following boundaries:

1. no global understanding or person-rank output;
2. learner veto and finite burden;
3. refusal/opacity without content inference;
4. glue-or-obstruct rather than forced consensus;
5. transfer and retention states only from held-out and delayed evidence;
6. reversible, trace-preserving grammar changes;
7. tests and a falsification condition for every new claim.

Run:

```bash
PYTHONPATH=src:<path-to-mesh57-src>/src pytest
PYTHONPATH=src:<path-to-mesh57-src>/src python -m dikwp_mesh57_noesis conformance
```

Documentation-only changes must not silently alter schemas, evidence-state transitions or claims boundaries.
